/**
 * أدوات معالجة الوسائط (FFmpeg / FFprobe) والتحميل الثنائي السريع:
 * - تخزين مؤقت لنتائج ffprobe (فحص واحد فقط لكل ملف بدلاً من 4 مرات).
 * - مسار فوري (0ms) لفيديوهات MP4 H.264 ضمن حد 49MB بدون أي إعادة ترميز.
 * - استخدام -preset veryfast -threads 0 عند الحاجة للضغط لتقليل الزمن 3 أضعاف.
 * - محمّل ثنائي سريع يدعم التحميل المتوازي (Parallel Range Chunks) للملفات الكبيرة.
 */

import { execFile } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { promisify } from "node:util";
import { DOWNLOAD_DIR, TELEGRAM_MAX_UPLOAD_MB } from "./config.js";
import { DEFAULT_UA, SimpleCookieJar, fetchWithTimeout, logger } from "./network.js";

const execFileAsync = promisify(execFile);

let _ffmpegInstalled: boolean | null = null;
let _ffprobeInstalled: boolean | null = null;

export interface VideoStreamInfo {
  has_video: boolean;
  codec: string;
  width: number;
  height: number;
  duration: number;
}

const probeCache = new Map<string, { mtimeMs: number; size: number; info: VideoStreamInfo }>();

export async function checkCommandExists(cmd: string): Promise<boolean> {
  try {
    await execFileAsync(cmd, ["-version"], { timeout: 4000 });
    return true;
  } catch {
    return false;
  }
}

export async function checkFfmpegInstalled(): Promise<boolean> {
  if (_ffmpegInstalled !== null) return _ffmpegInstalled;
  _ffmpegInstalled = await checkCommandExists("ffmpeg");
  return _ffmpegInstalled;
}

export async function checkFfprobeInstalled(): Promise<boolean> {
  if (_ffprobeInstalled !== null) return _ffprobeInstalled;
  _ffprobeInstalled = await checkCommandExists("ffprobe");
  return _ffprobeInstalled;
}

export async function getVideoStreamInfo(filePath: string): Promise<VideoStreamInfo> {
  const info: VideoStreamInfo = { has_video: false, codec: "", width: 0, height: 0, duration: 0 };
  if (!filePath || !fs.existsSync(filePath)) return info;

  const stat = fs.statSync(filePath);
  const cached = probeCache.get(filePath);
  if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) {
    return { ...cached.info };
  }

  const hasProbe = await checkFfprobeInstalled();
  if (!hasProbe) {
    const ext = path.extname(filePath).toLowerCase();
    info.has_video = [".mp4", ".mkv", ".mov", ".webm", ".avi", ".flv", ".ts", ".m4v", ".3gp"].includes(ext);
    return info;
  }

  try {
    const { stdout } = await execFileAsync(
      "ffprobe",
      [
        "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=codec_name,width,height:format=duration",
        "-of", "json",
        filePath,
      ],
      { timeout: 10000 }
    );
    const data = JSON.parse(stdout || "{}");
    const streams = Array.isArray(data.streams) ? data.streams : [];
    if (streams.length > 0) {
      const st = streams[0];
      const codec = String(st.codec_name || "").toLowerCase();
      if (codec && !["png", "mjpeg", "webp", "gif", "bmp"].includes(codec)) {
        info.has_video = true;
        info.codec = codec;
        info.width = Number(st.width || 0);
        info.height = Number(st.height || 0);
      }
    }
    const dur = data.format?.duration;
    if (dur) {
      info.duration = Number(dur) || 0;
    }
  } catch {
    // fallback false
  }

  if (probeCache.size > 300) probeCache.clear();
  probeCache.set(filePath, { mtimeMs: stat.mtimeMs, size: stat.size, info: { ...info } });
  return info;
}

export async function probeHasVideoStream(filePath: string): Promise<boolean> {
  const info = await getVideoStreamInfo(filePath);
  return info.has_video;
}

export async function prepareHighQualityVideo(
  inputPath: string,
  workDir: string,
  prefix = "video"
): Promise<string> {
  if (!inputPath || !fs.existsSync(inputPath)) return inputPath;
  if (!(await checkFfmpegInstalled())) return inputPath;

  const sizeMb = fs.statSync(inputPath).size / (1024 * 1024);
  const vInfo = await getVideoStreamInfo(inputPath);
  const codec = vInfo.codec || "";
  const isMp4 = inputPath.toLowerCase().endsWith(".mp4");
  const isH264 = codec === "h264" || codec === "avc1" || codec === "";

  // حالة 1: ملف MP4 جاهز بكودك H.264 وضمن حد تيليجرام -> إرسال فوري بـ 0ms إعادة ترميز
  if (isMp4 && isH264 && sizeMb <= TELEGRAM_MAX_UPLOAD_MB) {
    return inputPath;
  }

  const outPath = path.join(workDir, `${prefix}_hq.mp4`);

  // حالة 2: حاوية غير MP4 لكن الكودك H.264 وضمن الحد -> نسخ خام فوري (-c:v copy)
  if (!isMp4 && isH264 && sizeMb <= TELEGRAM_MAX_UPLOAD_MB) {
    try {
      await execFileAsync(
        "ffmpeg",
        [
          "-y",
          "-i", inputPath,
          "-c:v", "copy",
          "-c:a", "aac",
          "-b:a", "192k",
          "-movflags", "+faststart",
          outPath,
        ],
        { timeout: 120000 }
      );
      if (fs.existsSync(outPath) && fs.statSync(outPath).size > 4096) {
        if (path.resolve(inputPath) !== path.resolve(outPath)) {
          cleanupFiles(inputPath);
        }
        return outPath;
      }
    } catch {
      return inputPath;
    }
  }

  // حالة 3: تجاوز 49MB أو كودك غير H.264 (مثل HEVC/AV1/VP9) -> ترميز سريع وعالي الجودة
  const duration = vInfo.duration || 0;
  let extraArgs: string[];
  if (sizeMb > TELEGRAM_MAX_UPLOAD_MB && duration > 2) {
    const targetTotalKbps = Math.floor((47.0 * 1024 * 8) / duration);
    const audioKbps = targetTotalKbps > 600 ? 128 : 96;
    const videoKbps = Math.max(400, targetTotalKbps - audioKbps);
    extraArgs = [
      "-b:v", `${videoKbps}k`,
      "-maxrate", `${Math.floor(videoKbps * 1.15)}k`,
      "-bufsize", `${videoKbps * 2}k`,
      "-c:a", "aac",
      "-b:a", `${audioKbps}k`,
    ];
  } else {
    extraArgs = ["-crf", "20", "-c:a", "aac", "-b:a", "192k"];
  }

  const vfArgs = vInfo.height > 1080 && sizeMb > TELEGRAM_MAX_UPLOAD_MB ? ["-vf", "scale=-2:1080"] : [];

  try {
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-i", inputPath,
        ...vfArgs,
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-threads", "0",
        "-pix_fmt", "yuv420p",
        ...extraArgs,
        "-movflags", "+faststart",
        outPath,
      ],
      { timeout: 240000 }
    );
    if (fs.existsSync(outPath) && fs.statSync(outPath).size > 4096) {
      if (path.resolve(inputPath) !== path.resolve(outPath)) {
        cleanupFiles(inputPath);
      }
      return outPath;
    }
  } catch (err) {
    logger.debug(`FFmpeg encode note: ${String(err)}`);
  }

  return inputPath;
}

export async function convertToVoiceOgg(inputPath: string, outputPath: string): Promise<string> {
  if (!(await checkFfmpegInstalled())) return inputPath;
  try {
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-i", inputPath,
        "-vn",
        "-c:a", "libopus",
        "-b:a", "96k",
        "-vbr", "on",
        "-compression_level", "8",
        outputPath,
      ],
      { timeout: 120000 }
    );
    if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
      return outputPath;
    }
  } catch (err) {
    logger.debug(`FFmpeg voice convert note: ${String(err)}`);
  }
  return inputPath;
}

export async function convertToMp3(inputPath: string, outputPath: string): Promise<string> {
  if (!(await checkFfmpegInstalled())) return inputPath;
  try {
    await execFileAsync(
      "ffmpeg",
      ["-y", "-i", inputPath, "-vn", "-c:a", "libmp3lame", "-b:a", "256k", outputPath],
      { timeout: 120000 }
    );
    if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
      return outputPath;
    }
  } catch (err) {
    logger.debug(`FFmpeg mp3 convert note: ${String(err)}`);
  }
  return inputPath;
}

export function isValidMediaBinaryHeader(
  headBytes: Buffer | Uint8Array,
  expectedType?: "video" | "audio" | "image" | null
): boolean {
  if (!headBytes || headBytes.length < 12) return false;
  const buf = Buffer.isBuffer(headBytes) ? headBytes : Buffer.from(headBytes);
  const stripped = buf.subarray(0, 256).toString("latin1").trimStart().toLowerCase();

  const badPrefixes = [
    "<!doctype",
    "<html",
    "<head",
    "<script",
    "<body",
    "<?xml",
    '{"error',
    '{"status":"error',
    '{"success":false',
    '{"success":0',
    "error:",
    "access denied",
    "403 forbidden",
    "404 not found",
  ];
  if (badPrefixes.some((p) => stripped.startsWith(p))) {
    return false;
  }

  if (expectedType === "video") {
    const head32 = buf.subarray(0, 32);
    return (
      head32.includes(Buffer.from("ftyp")) ||
      head32.includes(Buffer.from("moov")) ||
      (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) ||
      buf.subarray(0, 3).toString("ascii") === "FLV" ||
      buf.subarray(0, 4).toString("ascii") === "RIFF" ||
      buf.subarray(0, 4).toString("ascii") === "OggS" ||
      buf[0] === 0x47
    );
  }

  if (expectedType === "audio") {
    const head32 = buf.subarray(0, 32);
    const b0 = buf[0];
    const b1 = buf[1];
    return (
      buf.subarray(0, 3).toString("ascii") === "ID3" ||
      (b0 === 0xff && (b1 === 0xfb || b1 === 0xf3 || b1 === 0xf2 || b1 === 0xf1 || b1 === 0xe3)) ||
      head32.includes(Buffer.from("ftyp")) ||
      buf.subarray(0, 4).toString("ascii") === "OggS" ||
      buf.subarray(0, 4).toString("ascii") === "RIFF" ||
      buf.subarray(0, 4).toString("ascii") === "fLaC" ||
      (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3)
    );
  }

  return true;
}

export interface BinaryDownloadOptions {
  headers?: Record<string, string>;
  minSize?: number;
  expectedType?: "video" | "audio" | "image";
  cookieJar?: SimpleCookieJar;
  timeoutMs?: number;
  signal?: AbortSignal;
  enableParallelRanges?: boolean;
}

/**
 * تحميل متوازي سريع (4 اتصالات Range متزامنة) للملفات الأكبر من 3MB عند دعم الخادم،
 * أو بث مباشر سريع بـ Buffer كبير (256KB) للملفات الأصغر.
 */
async function downloadParallelRanges(
  url: string,
  totalSize: number,
  destPath: string,
  headers: Record<string, string>,
  cookieJar?: SimpleCookieJar,
  signal?: AbortSignal,
  concurrency = 4
): Promise<boolean> {
  const chunkSize = Math.ceil(totalSize / concurrency);
  const ranges: Array<{ start: number; end: number; idx: number }> = [];
  for (let i = 0; i < concurrency; i++) {
    const start = i * chunkSize;
    const end = Math.min(totalSize - 1, (i + 1) * chunkSize - 1);
    if (start <= end) ranges.push({ start, end, idx: i });
  }

  const buffers = new Array<Buffer>(ranges.length);
  await Promise.all(
    ranges.map(async ({ start, end, idx }) => {
      const resp = await fetchWithTimeout(url, {
        headers: { ...headers, Range: `bytes=${start}-${end}` },
        cookieJar,
        externalSignal: signal,
        timeoutMs: 25000,
      });
      if (resp.status !== 206 && resp.status !== 200) {
        throw new Error(`Range chunk ${idx} failed with status ${resp.status}`);
      }
      const arrBuf = await resp.arrayBuffer();
      buffers[idx] = Buffer.from(arrBuf);
    })
  );

  const combined = Buffer.concat(buffers);
  if (combined.length < totalSize * 0.98) {
    return false;
  }
  fs.writeFileSync(destPath, combined);
  return true;
}

export async function downloadBinaryFile(
  mediaUrl: string,
  destPath: string,
  opts: BinaryDownloadOptions = {}
): Promise<boolean> {
  if (!mediaUrl || !/^https?:\/\//i.test(mediaUrl)) return false;

  const {
    headers = {},
    minSize = 2048,
    expectedType,
    cookieJar,
    timeoutMs = 28000,
    signal,
    enableParallelRanges = true,
  } = opts;

  const reqHeaders: Record<string, string> = {
    "User-Agent": DEFAULT_UA,
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
    ...headers,
  };

  const effectiveMin = Math.max(
    minSize,
    expectedType === "video" ? 16384 : expectedType === "audio" ? 4096 : minSize
  );
  const tmpPath = `${destPath}.part`;

  try {
    // محاولة التحميل المتوازي السريع للفيديو/الصوت إذا كان الحجم بين 3MB و 50MB
    if (enableParallelRanges && expectedType === "video") {
      try {
        const headResp = await fetchWithTimeout(mediaUrl, {
          method: "HEAD",
          headers: reqHeaders,
          cookieJar,
          externalSignal: signal,
          timeoutMs: 4500,
        });
        const acceptRanges = (headResp.headers.get("accept-ranges") || "").toLowerCase();
        const contentLen = Number(headResp.headers.get("content-length") || "0");
        const ctype = (headResp.headers.get("content-type") || "").toLowerCase();
        if (
          headResp.ok &&
          acceptRanges.includes("bytes") &&
          contentLen >= 3 * 1024 * 1024 &&
          contentLen <= 52 * 1024 * 1024 &&
          !ctype.includes("text/html") &&
          !ctype.includes("application/json")
        ) {
          const ok = await downloadParallelRanges(
            mediaUrl,
            contentLen,
            tmpPath,
            reqHeaders,
            cookieJar,
            signal,
            4
          );
          if (ok && fs.existsSync(tmpPath)) {
            const fd = fs.openSync(tmpPath, "r");
            const headBuf = Buffer.alloc(512);
            fs.readSync(fd, headBuf, 0, 512, 0);
            fs.closeSync(fd);
            if (isValidMediaBinaryHeader(headBuf, expectedType)) {
              fs.renameSync(tmpPath, destPath);
              if (expectedType === "video" && !(await probeHasVideoStream(destPath))) {
                cleanupFiles(destPath);
                return false;
              }
              return true;
            }
          }
          cleanupFiles(tmpPath);
        }
      } catch {
        // Fallback smoothly to streaming GET
        cleanupFiles(tmpPath);
      }
    }

    const resp = await fetchWithTimeout(mediaUrl, {
      headers: reqHeaders,
      cookieJar,
      externalSignal: signal,
      timeoutMs,
      redirect: "follow",
    });

    if (resp.status !== 200 && resp.status !== 206) return false;

    const ctype = (resp.headers.get("content-type") || "").toLowerCase();
    if (ctype.includes("text/html") || ctype.includes("application/json") || ctype.includes("text/plain")) {
      return false;
    }
    if (expectedType === "image" && ctype.includes("video/")) return false;
    if (expectedType === "video" && (ctype.includes("image/") || ctype.includes("audio/mpeg"))) return false;
    if (!resp.body) return false;

    const writeStream = fs.createWriteStream(tmpPath, { highWaterMark: 256 * 1024 });
    const nodeStream = Readable.fromWeb(resp.body as unknown as import("node:stream/web").ReadableStream);

    let firstChunk: Buffer | null = null;
    let totalWritten = 0;

    nodeStream.on("data", (chunk: Buffer) => {
      totalWritten += chunk.length;
      if (!firstChunk) {
        firstChunk = Buffer.from(chunk.subarray(0, 512));
        if (!isValidMediaBinaryHeader(firstChunk, expectedType)) {
          nodeStream.destroy(new Error("Invalid binary header"));
        }
      }
    });

    await pipeline(nodeStream, writeStream);

    if (
      totalWritten >= effectiveMin &&
      firstChunk &&
      isValidMediaBinaryHeader(firstChunk, expectedType)
    ) {
      fs.renameSync(tmpPath, destPath);
      if (expectedType === "video" && (await checkFfprobeInstalled())) {
        if (!(await probeHasVideoStream(destPath))) {
          cleanupFiles(destPath);
          return false;
        }
      }
      return true;
    }
  } catch (err) {
    logger.debug(`Binary download note: ${String(err)}`);
  } finally {
    cleanupFiles(tmpPath);
  }
  return false;
}

export function getImageDimensionsFast(filePath: string): [number, number] {
  try {
    const data = fs.readFileSync(filePath);
    if (data.length < 24) return [0, 0];

    // PNG
    if (
      data.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) &&
      data.subarray(12, 16).toString("ascii") === "IHDR"
    ) {
      return [data.readUInt32BE(16), data.readUInt32BE(20)];
    }

    // GIF
    const gifSig = data.subarray(0, 6).toString("ascii");
    if (gifSig === "GIF87a" || gifSig === "GIF89a") {
      return [data.readUInt16LE(6), data.readUInt16LE(8)];
    }

    // WEBP
    if (
      data.subarray(0, 4).toString("ascii") === "RIFF" &&
      data.subarray(8, 12).toString("ascii") === "WEBP"
    ) {
      const chunk = data.subarray(12, 16).toString("ascii");
      if (chunk === "VP8 " && data.length >= 30) {
        return [data.readUInt16LE(26) & 0x3fff, data.readUInt16LE(28) & 0x3fff];
      }
      if (chunk === "VP8L" && data.length >= 25) {
        const b0 = data[21];
        const b1 = data[22];
        const b2 = data[23];
        const b3 = data[24];
        const w = 1 + (((b1 & 0x3f) << 8) | b0);
        const h = 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6));
        return [w, h];
      }
      if (chunk === "VP8X" && data.length >= 30) {
        const w = 1 + (data[24] | (data[25] << 8) | (data[26] << 16));
        const h = 1 + (data[27] | (data[28] << 8) | (data[29] << 16));
        return [w, h];
      }
    }

    // JPEG
    if (data[0] === 0xff && data[1] === 0xd8) {
      let pos = 2;
      while (pos + 4 < data.length) {
        if (data[pos] !== 0xff) break;
        let mtype = data[pos + 1];
        pos += 2;
        while (mtype === 0xff && pos < data.length) {
          mtype = data[pos];
          pos += 1;
        }
        if (mtype === 0xd8 || mtype === 0xd9 || (mtype >= 0xd0 && mtype <= 0xd7)) continue;
        if (pos + 2 > data.length) break;
        const segLen = data.readUInt16BE(pos);
        if (
          [0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(
            mtype
          )
        ) {
          if (pos + 7 <= data.length) {
            const h = data.readUInt16BE(pos + 3);
            const w = data.readUInt16BE(pos + 5);
            return [w, h];
          }
          break;
        }
        if (segLen < 2) break;
        pos += segLen;
      }
    }
  } catch {
    // ignore
  }
  return [0, 0];
}

export function validateAndFilterImages(imagePaths: string[]): string[] {
  const validItems: Array<{
    path: string;
    size: number;
    w: number;
    h: number;
    isSquare: boolean;
    isPng: boolean;
  }> = [];
  const seenHashes = new Set<string>();

  for (const p of imagePaths) {
    if (!p || !fs.existsSync(p)) continue;
    const fsize = fs.statSync(p).size;
    if (fsize < 2500) continue;

    try {
      const data = fs.readFileSync(p);
      const headStrip = data.subarray(0, 64).toString("latin1").trimStart().toLowerCase();
      if (["<!doctype", "<html", "<?xml", '{"error'].some((bad) => headStrip.startsWith(bad))) {
        continue;
      }
      const fileHash = crypto.createHash("sha256").update(data).digest("hex");
      if (seenHashes.has(fileHash)) continue;
      seenHashes.add(fileHash);

      const [w, h] = getImageDimensionsFast(p);
      if (w > 0 && h > 0 && (w < 220 || h < 220)) continue;

      const isPng = data
        .subarray(0, 8)
        .equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));

      validItems.push({
        path: p,
        size: fsize,
        w,
        h,
        isSquare: w > 0 && h > 0 && Math.abs(w - h) <= 4,
        isPng,
      });
    } catch {
      continue;
    }
  }

  let finalItems = validItems;
  if (validItems.length > 1) {
    const hasLargePhoto = validItems.some((it) => (!it.isPng && it.size > 25000) || it.w >= 600);
    if (hasLargePhoto) {
      const filtered = validItems.filter(
        (it) =>
          !(
            it.isSquare &&
            (it.isPng || [192, 256, 300, 512].includes(it.w) || it.size < 18000)
          )
      );
      if (filtered.length > 0) finalItems = filtered;
    }
  }

  return finalItems.map((it) => it.path);
}

export function cleanupFiles(...paths: Array<string | null | undefined>): void {
  for (const p of paths) {
    if (!p) continue;
    try {
      if (fs.existsSync(p)) {
        const st = fs.lstatSync(p);
        if (st.isDirectory()) {
          fs.rmSync(p, { recursive: true, force: true });
        } else {
          fs.unlinkSync(p);
        }
      }
    } catch {
      // ignore
    }
  }
}

export function purgeStaleTempFiles(maxAgeSeconds = 600): void {
  try {
    if (!fs.existsSync(DOWNLOAD_DIR)) return;
    const now = Date.now();
    for (const name of fs.readdirSync(DOWNLOAD_DIR)) {
      const fullP = path.join(DOWNLOAD_DIR, name);
      try {
        const st = fs.statSync(fullP);
        if ((now - st.mtimeMs) / 1000 > maxAgeSeconds) {
          cleanupFiles(fullP);
        }
      } catch {
        continue;
      }
    }
  } catch {
    // ignore
  }
}
