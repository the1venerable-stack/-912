/**
 * بناء واجهات البوت (مطابقة تماماً للنسخة الأصلية):
 * - رسالة الترحيب (/start)
 * - لوحة تحكم الأدمن (/admin) وقوائم تخصيص الأزرار
 * - تنسيق الكابتشن الطبيعي للفيديو والوسائط مع الوصف الكامل
 */

import {
  bot,
  escapeHtml,
  formatPremiumBadge,
  getActiveCustomEmoji,
  InlineKeyboardMarkup,
  makeBtn,
  safeSendMessage,
  SmartInlineButton,
  TgMessageEntity,
  TgUser,
} from "./botClient.js";
import {
  CUSTOMIZABLE_UI_KEYS,
  DEFAULT_WELCOME_TEXT,
  PLACEMENT_LABELS,
  THEME_LABELS,
} from "./config.js";
import { db, hasCookiesFile } from "./database.js";
import { logger } from "./network.js";

export function convertTextAndEntitiesToHtml(
  rawText: string,
  entitiesData: TgMessageEntity[]
): string {
  if (!entitiesData || !entitiesData.length) return escapeHtml(rawText);

  try {
    const totalUnits = rawText.length; // JS strings are UTF-16 code units — matches Telegram offsets natively!
    const sortedEnts = [...entitiesData].sort((a, b) => (a.offset || 0) - (b.offset || 0));
    const outParts: string[] = [];
    let cursorUnit = 0;

    for (const ent of sortedEnts) {
      const off = ent.offset || 0;
      const length = ent.length || 0;
      const etype = ent.type || "";
      if (off < cursorUnit || off + length > totalUnits) continue;

      if (off > cursorUnit) {
        outParts.push(escapeHtml(rawText.slice(cursorUnit, off)));
      }

      const escSeg = escapeHtml(rawText.slice(off, off + length));
      if (etype === "custom_emoji" && ent.custom_emoji_id) {
        outParts.push(`<tg-emoji emoji-id="${escapeHtml(ent.custom_emoji_id)}">${escSeg}</tg-emoji>`);
      } else if (etype === "bold") {
        outParts.push(`<b>${escSeg}</b>`);
      } else if (etype === "italic") {
        outParts.push(`<i>${escSeg}</i>`);
      } else if (etype === "underline") {
        outParts.push(`<u>${escSeg}</u>`);
      } else if (etype === "strikethrough") {
        outParts.push(`<s>${escSeg}</s>`);
      } else if (etype === "code") {
        outParts.push(`<code>${escSeg}</code>`);
      } else if (etype === "pre") {
        outParts.push(`<pre>${escSeg}</pre>`);
      } else if (etype === "blockquote") {
        outParts.push(`<blockquote>${escSeg}</blockquote>`);
      } else if (etype === "text_link" && ent.url) {
        outParts.push(`<a href="${escapeHtml(ent.url)}">${escSeg}</a>`);
      } else {
        outParts.push(escSeg);
      }

      cursorUnit = off + length;
    }

    if (cursorUnit < totalUnits) {
      outParts.push(escapeHtml(rawText.slice(cursorUnit)));
    }
    return outParts.join("");
  } catch {
    return escapeHtml(rawText);
  }
}

export async function buildWelcomeMessageHtml(): Promise<string> {
  const rawText = db.getSetting("welcome_text", DEFAULT_WELCOME_TEXT);
  const rawEntitiesJson = db.getSetting("welcome_entities", "[]");
  const botUname = `@${await bot.getBotUsername()}`;

  let entitiesData: TgMessageEntity[] = [];
  try {
    const parsed = JSON.parse(rawEntitiesJson);
    if (Array.isArray(parsed)) entitiesData = parsed;
  } catch {
    entitiesData = [];
  }

  const placement = db.getSetting("premium_placement", "off");
  const allowStartPremium = placement === "both" || placement === "start_only";

  let htmlText =
    entitiesData.length && allowStartPremium
      ? convertTextAndEntitiesToHtml(rawText, entitiesData)
      : escapeHtml(rawText);

  htmlText = htmlText
    .replaceAll("@البوت", escapeHtml(botUname))
    .replaceAll("{bot}", escapeHtml(botUname));

  if (allowStartPremium && !entitiesData.length) {
    const [ceId, ceChar] = getActiveCustomEmoji("start");
    if (ceId) {
      const badgeHtml = `<tg-emoji emoji-id="${escapeHtml(ceId)}">${escapeHtml(ceChar || "•")}</tg-emoji>`;
      htmlText = `${badgeHtml} ${htmlText}`;
    }
  }

  return htmlText;
}

export async function sendWelcomeScreen(
  chatId: number | string,
  user: TgUser,
  replyToMessageId?: number
): Promise<void> {
  const stickerId = db.getSetting("welcome_sticker_id", "").trim();
  if (stickerId) {
    try {
      await bot.sendSticker(chatId, stickerId);
    } catch (e) {
      logger.debug(`تعذر إرسال الملصق الترحيبي: ${String(e)}`);
    }
  }

  const welcomeText = await buildWelcomeMessageHtml();
  const botUname = await bot.getBotUsername();

  const rows: SmartInlineButton[][] = [
    [
      makeBtn({ callback_data: "user_help_guide", style: "success", scope: "start", ui_key: "btn_help_guide" }),
      makeBtn({ callback_data: "user_smart_search_hint", style: "primary", scope: "start", ui_key: "btn_smart_search" }),
    ],
    [
      makeBtn({
        url: `https://t.me/${botUname}?startgroup=true`,
        style: "success",
        scope: "start",
        ui_key: "btn_add_group",
      }),
    ],
  ];

  if (db.isAdmin(user.id)) {
    rows.push([
      makeBtn({ callback_data: "admin_home", style: "danger", scope: "sections", ui_key: "btn_admin_panel" }),
    ]);
  }

  await safeSendMessage(chatId, welcomeText, {
    reply_markup: { inline_keyboard: rows },
    parse_mode: "HTML",
    reply_to_message_id: replyToMessageId,
  });
}

export function cleanGeneralDescription(rawDesc: unknown): string {
  if (!rawDesc || typeof rawDesc !== "string") return "";
  let desc = rawDesc.trim();
  if (!desc) return "";
  const badPhrases = [
    "login • instagram",
    "create an account or log in to instagram",
    "enjoy the videos and music you love, upload original content",
  ];
  const dLow = desc.toLowerCase();
  if (badPhrases.some((bp) => dLow.includes(bp))) return "";
  desc = desc.replace(/\n{3,}/g, "\n\n").trim();
  return desc.slice(0, 2500);
}

export function formatMediaCaptionWithDescription(params: {
  badge: string;
  title: string;
  description: string;
  platformName: string;
  authorDisplay: string;
  botUname: string;
}): { fullCaption: string; cleanCaption: string; overflowDesc: string } {
  const safeTitle = escapeHtml(String(params.title || "منشور محمل").replace(/\s+/g, " ").trim().slice(0, 140));
  const safeUname = escapeHtml(params.botUname);
  const cleanDesc = cleanGeneralDescription(params.description);

  const authorPart = params.authorDisplay
    ? `<code>${escapeHtml(params.authorDisplay.slice(0, 30))}</code> | `
    : "";
  const footerHtml = `<blockquote><b>${escapeHtml(params.platformName)}</b> | ${authorPart}@${safeUname}</blockquote>`;

  let effectiveDesc = cleanDesc || String(params.title || "").replace(/\s+/g, " ").trim();
  if (
    effectiveDesc === "منشور محمل" ||
    effectiveDesc === "" ||
    effectiveDesc.startsWith("منشور انستغرام (") ||
    effectiveDesc.startsWith("فيديو يوتيوب (")
  ) {
    effectiveDesc = "";
  }

  let overflowDesc = "";
  let descBlockHtml = "";
  if (effectiveDesc) {
    const maxDescChars = 620;
    let inCapDesc = effectiveDesc;
    if (effectiveDesc.length > maxDescChars) {
      inCapDesc = `${effectiveDesc.slice(0, maxDescChars).trimEnd()}...`;
      overflowDesc = effectiveDesc;
    }
    descBlockHtml = `\n<b>الوصف:</b>\n<blockquote>${escapeHtml(inCapDesc)}</blockquote>`;
  }

  const fullCaption = `${params.badge}<b>${safeTitle}</b>${descBlockHtml}\n${footerHtml}`;
  const cleanCaption = fullCaption.replace(/<\/?tg-emoji[^>]*>/g, "");
  return { fullCaption, cleanCaption, overflowDesc };
}

export function buildAdminMainKeyboard(): InlineKeyboardMarkup {
  const forceOn = db.getSetting("force_sub_enabled", "1") === "1";
  const botOn = db.getSetting("bot_enabled", "1") === "1";
  const cookiesOk = hasCookiesFile();

  const botLbl = db.getUiConfig("adm_btn_bot").btn_label;
  const fsubLbl = db.getUiConfig("adm_btn_fsub").btn_label;
  const cookiesLbl = db.getUiConfig("adm_btn_cookies").btn_label;

  return {
    inline_keyboard: [
      [
        makeBtn({
          text: `${botLbl}: ${botOn ? "مفعل" : "معطل"}`,
          callback_data: "adm_toggle_bot",
          style: botOn ? "success" : "danger",
          scope: "sections",
          ui_key: "adm_btn_bot",
        }),
        makeBtn({
          text: `${fsubLbl}: ${forceOn ? "مفعل" : "معطل"}`,
          callback_data: "adm_toggle_fsub",
          style: forceOn ? "success" : "danger",
          scope: "sections",
          ui_key: "adm_btn_fsub",
        }),
      ],
      [
        makeBtn({ callback_data: "adm_ui_custom_menu", style: "success", scope: "sections", ui_key: "adm_btn_ui_custom" }),
      ],
      [
        makeBtn({ callback_data: "adm_premium_menu", style: "primary", scope: "sections", ui_key: "adm_btn_premium" }),
        makeBtn({ callback_data: "adm_colors_menu", style: "success", scope: "sections", ui_key: "adm_btn_colors" }),
        makeBtn({ callback_data: "adm_welcome_menu", style: "primary", scope: "sections", ui_key: "adm_btn_welcome" }),
      ],
      [
        makeBtn({ callback_data: "adm_fsub_menu", style: "danger", scope: "sections", ui_key: "adm_btn_channels" }),
        makeBtn({ callback_data: "adm_stats", style: "primary", scope: "sections", ui_key: "adm_btn_users" }),
        makeBtn({ callback_data: "adm_broadcast_menu", style: "success", scope: "sections", ui_key: "adm_btn_broadcast" }),
      ],
      [
        makeBtn({
          text: `${cookiesLbl}: ${cookiesOk ? "مفعل" : "إضافة"}`,
          callback_data: "adm_cookies_menu",
          style: cookiesOk ? "success" : "primary",
          scope: "sections",
          ui_key: "adm_btn_cookies",
        }),
        makeBtn({ callback_data: "adm_ban_menu", style: "danger", scope: "sections", ui_key: "adm_btn_ban" }),
        makeBtn({ callback_data: "adm_admins_menu", style: "success", scope: "sections", ui_key: "adm_btn_admins" }),
      ],
      [
        makeBtn({ callback_data: "adm_clear_cache", style: "primary", scope: "sections", ui_key: "adm_btn_clear_cache" }),
        makeBtn({ callback_data: "adm_close", style: "danger", scope: "sections", ui_key: "btn_cancel" }),
      ],
    ],
  };
}

export function getAdminDashboardText(): string {
  const stats = db.getDashboardStats();
  const placement = db.getSetting("premium_placement", "off");
  const placementStr = PLACEMENT_LABELS[placement] || placement;
  const theme = db.getSetting("color_theme", "mixed");
  const themeStr = THEME_LABELS[theme] || theme;
  const badge = formatPremiumBadge("sections", "");

  return (
    `${badge}<b>لوحة التحكم (/admin)</b>\n` +
    "<blockquote>" +
    `المشتركين: <code>${stats.total_users}</code> | الكاش: <code>${stats.cached_items}</code>\n` +
    `القنوات: <code>${stats.total_channels}</code> | المشرفين: <code>${stats.total_admins}</code> | المحظورين: <code>${stats.banned_users}</code>\n` +
    `المميز العام: ${escapeHtml(placementStr)} | الثيم: ${escapeHtml(themeStr)}\n` +
    `كوكيز انستا/يوتيوب: <code>${hasCookiesFile() ? "مفعل" : "تلقائي بدون كوكيز"}</code>` +
    "</blockquote>\n" +
    "<b>اختر القسم المطلوب للتعديل أو الإدارة:</b>"
  );
}

export function buildUiCustomizationListKeyboard(): InlineKeyboardMarkup {
  const btns: SmartInlineButton[] = [];
  for (const uKey of Object.keys(CUSTOMIZABLE_UI_KEYS)) {
    const cfg = db.getUiConfig(uKey);
    const hasExtra = Boolean(cfg.sticker_id || cfg.custom_emoji_id);
    const suffix = hasExtra ? " [ملصق/مميز]" : "";
    btns.push(
      makeBtn({
        text: `${cfg.btn_label.slice(0, 22)}${suffix}`,
        callback_data: `adm_uikey|${uKey}`,
        style: hasExtra ? "success" : "primary",
        scope: "sections",
      })
    );
  }

  const rows: SmartInlineButton[][] = [];
  for (let i = 0; i < btns.length; i += 2) {
    rows.push(btns.slice(i, i + 2));
  }
  rows.push([
    makeBtn({ text: "استعادة جميع الأزرار للافتراضي", callback_data: "adm_ui_reset_all", style: "danger", scope: "sections" }),
  ]);
  rows.push([
    makeBtn({ text: "رجوع للوحة التحكم", callback_data: "admin_home", style: "primary", scope: "sections" }),
  ]);
  return { inline_keyboard: rows };
}

export function buildSingleUiKeyEditor(uiKey: string): { text: string; markup: InlineKeyboardMarkup } {
  const cfg = db.getUiConfig(uiKey);
  const stStatus = cfg.sticker_id ? "مضاف (اختياري)" : "غير مضاف (بدون ملصق)";
  const ceStatus = cfg.custom_emoji_id ? `مضاف (${cfg.custom_emoji_id})` : "غير مضاف (بدون إيموجي)";
  const contentPreview = (cfg.inner_content || "لا يوجد نص داخلي مخصص لهذا الزر").slice(0, 250);

  const text =
    `<b>تخصيص: ${escapeHtml(cfg.title)}</b>\n` +
    "<blockquote>" +
    `<b>اسم الزر الحالي:</b> <code>${escapeHtml(cfg.btn_label)}</code>\n` +
    `<b>الملصق المرفق (اختياري):</b> <code>${escapeHtml(stStatus)}</code>\n` +
    `<b>أيقونة الزر المميزة (اختياري):</b> <code>${escapeHtml(ceStatus)}</code>\n` +
    "</blockquote>\n" +
    `<b>النص/المحتوى بداخل الزر أو القسم:</b>\n` +
    `<blockquote>${escapeHtml(contentPreview)}</blockquote>\n` +
    "<b>اختر ما تريد تعديله:</b>";

  const rows: SmartInlineButton[][] = [
    [
      makeBtn({ text: "تعديل اسم الزر فقط", callback_data: `adm_uiedit_lbl|${uiKey}`, style: "primary", scope: "sections" }),
      makeBtn({ text: "تعديل اسم الزر + ملصق/مميز", callback_data: `adm_uiedit_both|${uiKey}`, style: "success", scope: "sections" }),
    ],
  ];

  if (cfg.has_content) {
    rows.push([
      makeBtn({ text: "تعديل النص بداخل الزر/القسم", callback_data: `adm_uiedit_cnt|${uiKey}`, style: "primary", scope: "sections" }),
    ]);
  }

  rows.push([
    makeBtn({ text: "إضافة/تغيير الملصق أو الإيموجي", callback_data: `adm_uiedit_stk|${uiKey}`, style: "success", scope: "sections" }),
    makeBtn({ text: "حذف الملصق/الإيموجي (بدون)", callback_data: `adm_uidel_stk|${uiKey}`, style: "danger", scope: "sections" }),
  ]);
  rows.push([
    makeBtn({ text: "استعادة افتراضي هذا الزر", callback_data: `adm_uireset_one|${uiKey}`, style: "danger", scope: "sections" }),
    makeBtn({ text: "رجوع لقائمة الأزرار", callback_data: "adm_ui_custom_menu", style: "primary", scope: "sections" }),
  ]);

  return { text, markup: { inline_keyboard: rows } };
}
