/**
 * إدارة قاعدة البيانات (SQLite) المتوافقة 100% مع downloader_bot_pro.db
 * مع كاش L1 في الذاكرة لتصفير زمن الاستجابة (0ms) بدلاً من فتح/إغلاق الاتصال عند كل زر.
 *
 * يدعم التشغيل الفوري على جميع إصدارات Node.js:
 * - يستخدم node:sqlite المدمج في Node 22.5+ (أداء أصلي فائق مع WAL).
 * - يتحول تلقائياً إلى sql.js (بدون الحاجة لأي أدوات تجميع C++) في Node 18/20.
 */

import crypto from "node:crypto";
import fs from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import {
  COOKIES_FILE_PATH,
  CUSTOMIZABLE_UI_KEYS,
  DB_PATH,
  DEFAULT_FORCE_SUB_TEXT,
  DEFAULT_WELCOME_TEXT,
  OWNER_ID,
} from "./config.js";
import { logger } from "./network.js";

const require = createRequire(import.meta.url);

export interface TelegramUserLite {
  id: number;
  is_bot?: boolean;
  username?: string;
  first_name?: string;
}

export interface UiConfigRecord {
  ui_key: string;
  title: string;
  btn_label: string;
  inner_content: string;
  sticker_id: string;
  custom_emoji_id: string;
  custom_emoji_char: string;
  has_content: boolean;
}

export interface ForceChannelRecord {
  chat_id: string;
  title: string;
  invite_link: string;
  added_at: string;
}

export interface CachedMediaRecord {
  cache_key: string;
  file_type: string;
  file_id: string;
  title: string;
  description: string;
  author: string;
  created_at: number;
}

export interface EphemeralRequestRecord {
  req_id: string;
  user_id: number;
  chat_id: number;
  url: string;
  is_search: number;
  meta: Record<string, unknown>;
  created_at: number;
}

export interface DashboardStats {
  total_users: number;
  banned_users: number;
  total_channels: number;
  total_admins: number;
  cached_items: number;
}

export interface RecentUserRow {
  first_name: string;
  username: string;
  joined_at: string;
}

type SqlParam = string | number | null | Uint8Array;

interface SqliteDriver {
  exec(sql: string): void;
  run(sql: string, params?: SqlParam[]): void;
  get<T = Record<string, unknown>>(sql: string, params?: SqlParam[]): T | undefined;
  all<T = Record<string, unknown>>(sql: string, params?: SqlParam[]): T[];
  close(): void;
}

function nowFormatted(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

async function openSqliteDriver(dbPath: string): Promise<SqliteDriver> {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  // 1) Node 22.5+ built-in node:sqlite (zero external compilation, native C++ SQLite)
  try {
    const nodeSqlite = await import("node:sqlite");
    if (nodeSqlite && typeof nodeSqlite.DatabaseSync === "function") {
      const db = new nodeSqlite.DatabaseSync(dbPath);
      db.exec("PRAGMA journal_mode=WAL;");
      db.exec("PRAGMA synchronous=NORMAL;");
      db.exec("PRAGMA temp_store=MEMORY;");
      db.exec("PRAGMA cache_size=-16000;");
      return {
        exec: (sql: string) => {
          db.exec(sql);
        },
        run: (sql: string, params: SqlParam[] = []) => {
          db.prepare(sql).run(...params);
        },
        get: <T = Record<string, unknown>>(sql: string, params: SqlParam[] = []) => {
          const row = db.prepare(sql).get(...params);
          return row ? ({ ...row } as T) : undefined;
        },
        all: <T = Record<string, unknown>>(sql: string, params: SqlParam[] = []) => {
          const rows = db.prepare(sql).all(...params);
          return rows.map((r) => ({ ...r }) as T);
        },
        close: () => {
          db.close();
        },
      };
    }
  } catch {
    // Fallback to sql.js on Node 18 / 20
  }

  // 2) Pure-WASM sql.js fallback (works on every Node version & host with zero native builds)
  const initSqlJs = require("sql.js");
  const SQL = await initSqlJs();
  const initialBuf = fs.existsSync(dbPath) ? fs.readFileSync(dbPath) : undefined;
  const db = new SQL.Database(initialBuf);

  let flushTimer: NodeJS.Timeout | null = null;
  const flushNow = () => {
    try {
      const data = db.export();
      const tmp = `${dbPath}.tmp`;
      fs.writeFileSync(tmp, Buffer.from(data));
      fs.renameSync(tmp, dbPath);
    } catch (err) {
      logger.debug(`SQLite flush note: ${String(err)}`);
    }
  };
  const scheduleFlush = () => {
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      flushNow();
    }, 150);
  };

  return {
    exec: (sql: string) => {
      db.run(sql);
      scheduleFlush();
    },
    run: (sql: string, params: SqlParam[] = []) => {
      db.run(sql, params);
      scheduleFlush();
    },
    get: <T = Record<string, unknown>>(sql: string, params: SqlParam[] = []) => {
      const stmt = db.prepare(sql);
      stmt.bind(params);
      let row: T | undefined;
      if (stmt.step()) {
        row = stmt.getAsObject() as T;
      }
      stmt.free();
      return row;
    },
    all: <T = Record<string, unknown>>(sql: string, params: SqlParam[] = []) => {
      const stmt = db.prepare(sql);
      stmt.bind(params);
      const rows: T[] = [];
      while (stmt.step()) {
        rows.push(stmt.getAsObject() as T);
      }
      stmt.free();
      return rows;
    },
    close: () => {
      if (flushTimer) {
        clearTimeout(flushTimer);
        flushTimer = null;
      }
      flushNow();
      db.close();
    },
  };
}

export class BotDatabase {
  private driver!: SqliteDriver;
  private initialized = false;

  // L1 in-memory caches for instant 0ms UI rendering
  private settingsCache = new Map<string, string>();
  private uiCache = new Map<string, UiConfigRecord>();
  private adminSet = new Set<number>([OWNER_ID]);
  private bannedCache = new Map<number, boolean>();
  private forceChannelsCache: ForceChannelRecord[] | null = null;

  // Ephemeral request & inaccessible channel caches
  private ephemeralRequests = new Map<string, EphemeralRequestRecord>();
  private inaccessibleChannels = new Map<string, number>();

  constructor(private readonly dbPath: string = DB_PATH) {}

  async init(): Promise<void> {
    if (this.initialized) return;
    this.driver = await openSqliteDriver(this.dbPath);

    this.driver.exec(`
      CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        joined_at TEXT,
        is_banned INTEGER DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY,
        added_by INTEGER,
        added_at TEXT
      );
      CREATE TABLE IF NOT EXISTS force_channels (
        chat_id TEXT PRIMARY KEY,
        title TEXT,
        invite_link TEXT,
        added_at TEXT
      );
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
      );
      CREATE TABLE IF NOT EXISTS premium_assets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_scope TEXT,
        asset_type TEXT,
        file_id TEXT,
        custom_emoji_id TEXT,
        emoji_char TEXT,
        added_at TEXT
      );
      CREATE TABLE IF NOT EXISTS media_cache (
        cache_key TEXT PRIMARY KEY,
        file_type TEXT,
        file_id TEXT,
        title TEXT,
        description TEXT DEFAULT '',
        author TEXT,
        created_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS custom_ui (
        ui_key TEXT PRIMARY KEY,
        btn_label TEXT,
        inner_content TEXT,
        sticker_id TEXT DEFAULT '',
        custom_emoji_id TEXT DEFAULT '',
        custom_emoji_char TEXT DEFAULT ''
      );
    `);

    try {
      this.driver.exec("ALTER TABLE media_cache ADD COLUMN description TEXT DEFAULT ''");
    } catch {
      // Column already exists
    }

    const defaultSettings: Record<string, string> = {
      welcome_text: DEFAULT_WELCOME_TEXT,
      welcome_entities: "[]",
      welcome_sticker_id: "",
      force_sub_enabled: "1",
      force_sub_text: DEFAULT_FORCE_SUB_TEXT,
      bot_enabled: "1",
      premium_placement: "off",
      premium_start_emoji_id: "",
      premium_start_emoji_char: "",
      premium_sections_emoji_id: "",
      premium_sections_emoji_char: "",
      color_theme: "mixed",
    };

    for (const [k, v] of Object.entries(defaultSettings)) {
      this.driver.run("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", [k, v]);
    }

    for (const [uKey, uInfo] of Object.entries(CUSTOMIZABLE_UI_KEYS)) {
      this.driver.run(
        `INSERT OR IGNORE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
         VALUES (?, ?, ?, '', '', '')`,
        [uKey, uInfo.default_label, uInfo.default_content]
      );
    }

    try {
      const rowHelp = this.driver.get<{ inner_content?: string }>(
        "SELECT inner_content FROM custom_ui WHERE ui_key = 'btn_help_guide'"
      );
      if (
        rowHelp?.inner_content &&
        ["مضغوط", "جودة قويه", "جوده قويه"].some((w) => rowHelp.inner_content!.includes(w))
      ) {
        this.driver.run("UPDATE custom_ui SET inner_content = ? WHERE ui_key = 'btn_help_guide'", [
          CUSTOMIZABLE_UI_KEYS.btn_help_guide.default_content,
        ]);
      }
    } catch {
      // ignore
    }

    this.driver.run(
      "INSERT OR IGNORE INTO admins (user_id, added_by, added_at) VALUES (?, ?, ?)",
      [OWNER_ID, OWNER_ID, nowFormatted()]
    );

    try {
      this.driver.run(
        "DELETE FROM media_cache WHERE lower(author) IN ('vxinstagram', 'ddinstagram', 'instafix', 'kkinstagram')"
      );
    } catch {
      // ignore
    }

    this.warmCaches();
    this.initialized = true;
  }

  private warmCaches(): void {
    this.settingsCache.clear();
    for (const row of this.driver.all<{ key: string; value: string }>("SELECT key, value FROM settings")) {
      this.settingsCache.set(row.key, row.value ?? "");
    }

    this.adminSet = new Set<number>([OWNER_ID]);
    for (const row of this.driver.all<{ user_id: number }>("SELECT user_id FROM admins")) {
      this.adminSet.add(Number(row.user_id));
    }

    this.uiCache.clear();
    this.forceChannelsCache = null;
  }

  close(): void {
    if (this.initialized) {
      this.driver.close();
      this.initialized = false;
    }
  }

  getSetting(key: string, defaultVal = ""): string {
    if (this.settingsCache.has(key)) {
      return this.settingsCache.get(key)!;
    }
    const row = this.driver.get<{ value: string }>("SELECT value FROM settings WHERE key = ?", [key]);
    if (row) {
      this.settingsCache.set(key, row.value ?? "");
      return row.value ?? defaultVal;
    }
    return defaultVal;
  }

  setSetting(key: string, value: string): void {
    const strVal = String(value);
    this.driver.run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, strVal]);
    this.settingsCache.set(key, strVal);
  }

  getUiConfig(uiKey: string): UiConfigRecord {
    const cached = this.uiCache.get(uiKey);
    if (cached) return { ...cached };

    const defaults = CUSTOMIZABLE_UI_KEYS[uiKey] || {
      title: uiKey,
      default_label: uiKey,
      default_content: "",
      has_content: false,
    };

    const row = this.driver.get<Record<string, string>>(
      "SELECT * FROM custom_ui WHERE ui_key = ?",
      [uiKey]
    );

    const record: UiConfigRecord = row
      ? {
          ui_key: uiKey,
          title: defaults.title,
          btn_label: row.btn_label || defaults.default_label,
          inner_content: row.inner_content !== undefined && row.inner_content !== null ? row.inner_content : defaults.default_content,
          sticker_id: row.sticker_id || "",
          custom_emoji_id: row.custom_emoji_id || "",
          custom_emoji_char: row.custom_emoji_char || "",
          has_content: defaults.has_content,
        }
      : {
          ui_key: uiKey,
          title: defaults.title,
          btn_label: defaults.default_label,
          inner_content: defaults.default_content,
          sticker_id: "",
          custom_emoji_id: "",
          custom_emoji_char: "",
          has_content: defaults.has_content,
        };

    this.uiCache.set(uiKey, record);
    return { ...record };
  }

  updateUiConfig(
    uiKey: string,
    updates: Partial<{
      btn_label: string;
      inner_content: string;
      sticker_id: string;
      custom_emoji_id: string;
      custom_emoji_char: string;
    }>
  ): void {
    const curr = this.getUiConfig(uiKey);
    const next: UiConfigRecord = {
      ...curr,
      btn_label: updates.btn_label !== undefined ? updates.btn_label : curr.btn_label,
      inner_content: updates.inner_content !== undefined ? updates.inner_content : curr.inner_content,
      sticker_id: updates.sticker_id !== undefined ? updates.sticker_id : curr.sticker_id,
      custom_emoji_id: updates.custom_emoji_id !== undefined ? updates.custom_emoji_id : curr.custom_emoji_id,
      custom_emoji_char: updates.custom_emoji_char !== undefined ? updates.custom_emoji_char : curr.custom_emoji_char,
    };

    this.driver.run(
      `INSERT OR REPLACE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        uiKey,
        next.btn_label,
        next.inner_content,
        next.sticker_id,
        next.custom_emoji_id,
        next.custom_emoji_char,
      ]
    );
    this.uiCache.set(uiKey, next);
  }

  resetAllUiConfigs(): void {
    for (const [uKey, uInfo] of Object.entries(CUSTOMIZABLE_UI_KEYS)) {
      this.driver.run(
        `INSERT OR REPLACE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
         VALUES (?, ?, ?, '', '', '')`,
        [uKey, uInfo.default_label, uInfo.default_content]
      );
    }
    this.uiCache.clear();
  }

  registerUser(user?: TelegramUserLite | null): void {
    if (!user || user.is_bot) return;
    const existing = this.driver.get<{ user_id: number }>(
      "SELECT user_id FROM users WHERE user_id = ?",
      [user.id]
    );
    if (!existing) {
      this.driver.run(
        "INSERT INTO users (user_id, username, first_name, joined_at) VALUES (?, ?, ?, ?)",
        [user.id, user.username || "", user.first_name || "مستخدم", nowFormatted()]
      );
    } else {
      this.driver.run("UPDATE users SET username = ?, first_name = ? WHERE user_id = ?", [
        user.username || "",
        user.first_name || "مستخدم",
        user.id,
      ]);
    }
  }

  isAdmin(userId: number): boolean {
    if (userId === OWNER_ID) return true;
    return this.adminSet.has(userId);
  }

  getAdmins(): Array<{ user_id: number; added_by: number; added_at: string }> {
    return this.driver.all("SELECT * FROM admins");
  }

  addAdmin(newAdminId: number, addedBy: number): void {
    this.driver.run(
      "INSERT OR REPLACE INTO admins (user_id, added_by, added_at) VALUES (?, ?, ?)",
      [newAdminId, addedBy, nowFormatted()]
    );
    this.adminSet.add(newAdminId);
  }

  removeAdmin(targetAdminId: number): void {
    this.driver.run("DELETE FROM admins WHERE user_id = ?", [targetAdminId]);
    if (targetAdminId !== OWNER_ID) {
      this.adminSet.delete(targetAdminId);
    }
  }

  isUserBanned(userId: number): boolean {
    if (this.isAdmin(userId)) return false;
    if (this.bannedCache.has(userId)) {
      return this.bannedCache.get(userId)!;
    }
    const row = this.driver.get<{ is_banned: number }>(
      "SELECT is_banned FROM users WHERE user_id = ?",
      [userId]
    );
    const banned = Boolean(row && Number(row.is_banned) === 1);
    this.bannedCache.set(userId, banned);
    return banned;
  }

  setUserBanned(userId: number, banned: boolean): void {
    this.driver.run("UPDATE users SET is_banned = ? WHERE user_id = ?", [banned ? 1 : 0, userId]);
    this.bannedCache.set(userId, banned);
  }

  getAllUserIds(): number[] {
    return this.driver.all<{ user_id: number }>("SELECT user_id FROM users").map((r) => Number(r.user_id));
  }

  getRecentUsers(limit = 5): RecentUserRow[] {
    return this.driver.all<RecentUserRow>(
      "SELECT first_name, username, joined_at FROM users ORDER BY rowid DESC LIMIT ?",
      [limit]
    );
  }

  getDashboardStats(): DashboardStats {
    const total_users = Number(this.driver.get<{ c: number }>("SELECT COUNT(*) as c FROM users")?.c || 0);
    const banned_users = Number(
      this.driver.get<{ c: number }>("SELECT COUNT(*) as c FROM users WHERE is_banned = 1")?.c || 0
    );
    const total_channels = Number(
      this.driver.get<{ c: number }>("SELECT COUNT(*) as c FROM force_channels")?.c || 0
    );
    const total_admins = Number(this.driver.get<{ c: number }>("SELECT COUNT(*) as c FROM admins")?.c || 0);
    const cached_items = Number(
      this.driver.get<{ c: number }>("SELECT COUNT(*) as c FROM media_cache")?.c || 0
    );
    return { total_users, banned_users, total_channels, total_admins, cached_items };
  }

  getForceChannels(): ForceChannelRecord[] {
    if (this.forceChannelsCache) {
      return this.forceChannelsCache.map((c) => ({ ...c }));
    }
    const rows = this.driver.all<ForceChannelRecord>("SELECT * FROM force_channels");
    this.forceChannelsCache = rows;
    return rows.map((c) => ({ ...c }));
  }

  upsertForceChannel(chatId: string, title: string, inviteLink: string): void {
    this.driver.run(
      "INSERT OR REPLACE INTO force_channels (chat_id, title, invite_link, added_at) VALUES (?, ?, ?, ?)",
      [chatId, title, inviteLink, nowFormatted()]
    );
    this.forceChannelsCache = null;
  }

  deleteForceChannel(chatId: string): void {
    this.driver.run("DELETE FROM force_channels WHERE chat_id = ?", [chatId]);
    this.forceChannelsCache = null;
  }

  clearForceChannels(): void {
    this.driver.run("DELETE FROM force_channels");
    this.forceChannelsCache = null;
  }

  saveUrlRequest(
    userId: number,
    chatId: number,
    url: string,
    isSearch = 0,
    meta: Record<string, unknown> = {}
  ): string {
    const reqId = crypto.randomBytes(5).toString("hex");
    const now = Math.floor(Date.now() / 1000);
    for (const [k, v] of this.ephemeralRequests.entries()) {
      if (now - v.created_at > 7200) {
        this.ephemeralRequests.delete(k);
      }
    }
    this.ephemeralRequests.set(reqId, {
      req_id: reqId,
      user_id: userId,
      chat_id: chatId,
      url,
      is_search: isSearch ? 1 : 0,
      meta: { ...meta },
      created_at: now,
    });
    return reqId;
  }

  getUrlRequest(reqId: string): EphemeralRequestRecord | null {
    const item = this.ephemeralRequests.get(reqId);
    return item ? { ...item, meta: { ...item.meta } } : null;
  }

  makeCacheKey(normalizedUrl: string, mode: string): string {
    const raw = `v10_hd|${(normalizedUrl || "").trim()}|${mode}`;
    return crypto.createHash("sha256").update(raw, "utf8").digest("hex").slice(0, 32);
  }

  getCachedMedia(normalizedUrl: string, mode: string): CachedMediaRecord | null {
    const key = this.makeCacheKey(normalizedUrl, mode);
    const row = this.driver.get<CachedMediaRecord>("SELECT * FROM media_cache WHERE cache_key = ?", [key]);
    return row ? { ...row } : null;
  }

  saveCachedMedia(
    normalizedUrl: string,
    mode: string,
    fileType: string,
    fileId: string,
    title = "",
    description = "",
    author = ""
  ): void {
    if (!fileId) return;
    const key = this.makeCacheKey(normalizedUrl, mode);
    this.driver.run(
      "INSERT OR REPLACE INTO media_cache (cache_key, file_type, file_id, title, description, author, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [
        key,
        fileType,
        fileId,
        String(title || "").slice(0, 200),
        String(description || "").slice(0, 2500),
        String(author || "").slice(0, 80),
        Math.floor(Date.now() / 1000),
      ]
    );
  }

  clearAllMediaCache(): void {
    this.driver.run("DELETE FROM media_cache");
  }

  markChannelInaccessible(chatId: string, durationSec = 3600): void {
    this.inaccessibleChannels.set(String(chatId), Date.now() + durationSec * 1000);
  }

  clearInaccessibleChannel(chatId?: string | null): void {
    if (!chatId) {
      this.inaccessibleChannels.clear();
    } else {
      this.inaccessibleChannels.delete(String(chatId));
    }
  }

  isChannelTemporarilySkipped(chatId: string): boolean {
    const exp = this.inaccessibleChannels.get(String(chatId)) || 0;
    return Date.now() < exp;
  }
}

export function hasCookiesFile(): boolean {
  try {
    return fs.existsSync(COOKIES_FILE_PATH) && fs.statSync(COOKIES_FILE_PATH).size > 20;
  } catch {
    return false;
  }
}

export const db = new BotDatabase(DB_PATH);
