/**
 * نقطة تشغيل البوت الرئيسية (src/main.ts):
 * - تهيئة قاعدة البيانات (SQLite + L1 Cache).
 * - تشغيل المحدث التلقائي لـ yt-dlp في الخلفية (تحديث فوري عند التشغيل وكل 12 ساعة).
 * - توجيه التحديثات (الأوامر، لوحة الأدمن، الروابط، البحث، المجموعات، الوضع الضمني).
 * - حلقة Polling مقاومة للأخطاء (502 / 503 / 504 / 429 / 409 / انقطاع الشبكة).
 */

import { bot, TgUpdate } from "./botClient.js";
import { BOT_TOKEN } from "./config.js";
import { db } from "./database.js";
import { startYtDlpAutoUpdater } from "./downloaders/ytdlp.js";
import { handleAdminStateInput } from "./handlers/admin.js";
import { handleAdminCommand, handleStartCommand } from "./handlers/commands.js";
import {
  handleCallbackQuery,
  handleIncomingMediaMessage,
  handleInlineQuery,
} from "./handlers/media.js";
import { logger } from "./network.js";

function extractCommand(text?: string): string | null {
  if (!text) return null;
  const trimmed = text.trim();
  if (!trimmed.startsWith("/")) return null;
  const firstToken = trimmed.split(/\s+/)[0] || "";
  return firstToken.split("@")[0].toLowerCase();
}

async function routeUpdate(update: TgUpdate): Promise<void> {
  if (update.callback_query) {
    await handleCallbackQuery(update.callback_query);
    return;
  }

  if (update.inline_query) {
    await handleInlineQuery(update.inline_query);
    return;
  }

  const message = update.message;
  if (!message) return;

  // 1) التحقق أولاً إذا كان الأدمن في وضع إدخال نص/ملصق/كوكيز
  if (await handleAdminStateInput(message)) {
    return;
  }

  // 2) أوامر البوت (/start، /admin، /panel)
  const cmd = extractCommand(message.text);
  if (cmd === "/start") {
    await handleStartCommand(message);
    return;
  }
  if (cmd === "/admin" || cmd === "/panel") {
    await handleAdminCommand(message);
    return;
  }

  // 3) الروابط، البحث في يوتيوب، والمجموعات
  await handleIncomingMediaMessage(message);
}

async function main(): Promise<void> {
  await db.init();
  startYtDlpAutoUpdater();

  if (!BOT_TOKEN || BOT_TOKEN === "PUT_YOUR_BOT_TOKEN_HERE") {
    logger.error("يرجى وضع توكن البوت في src/config.ts أو في متغير البيئة BOT_TOKEN قبل التشغيل.");
    process.exit(1);
  }

  process.on("SIGINT", () => {
    logger.info("تم إيقاف البوت يدوياً.");
    db.close();
    process.exit(0);
  });
  process.on("SIGTERM", () => {
    logger.info("تم إيقاف البوت.");
    db.close();
    process.exit(0);
  });

  logger.info("تم تشغيل بوت سلوم العراقي المطور (Node.js/TypeScript + تيك توك متعدد المسارات + yt-dlp محدّث تلقائياً).");
  await bot.runPolling(routeUpdate);
}

main().catch((err) => {
  logger.error(`خطأ فادح عند تشغيل البوت: ${String(err)}`);
  process.exit(1);
});
