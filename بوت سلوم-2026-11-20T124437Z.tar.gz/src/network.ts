/**
 * طبقة الشبكة والأداء العالي:
 * - محرك fetch غير متزامن مع Keep-Alive و AbortController لإلغاء المسارات البطيئة فوراً.
 * - أداة السباق المتوازي (raceFirstSuccess) لتشغيل مسارات التحميل بالتوازي واختيار الأسرع.
 * - إدارة الكوكيز (SimpleCookieJar) لحفظ كوكيز الجلسة مثل tt_chain_token و ttwid و csrftoken.
 * - Semaphore لإدارة التزامن بدون استهلاك الذاكرة.
 */

export const DEFAULT_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36";

export const MOBILE_ANDROID_UA =
  "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) " +
  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36";

export const MOBILE_IOS_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) " +
  "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1";

const LOG_DEBUG = process.env.BOT_DEBUG === "1";

export const logger = {
  info(msg: string) {
    console.log(`${new Date().toISOString()} [INFO] ${msg}`);
  },
  warn(msg: string) {
    console.warn(`${new Date().toISOString()} [WARN] ${msg}`);
  },
  error(msg: string) {
    console.error(`${new Date().toISOString()} [ERROR] ${msg}`);
  },
  debug(msg: string) {
    if (LOG_DEBUG) {
      console.debug(`${new Date().toISOString()} [DEBUG] ${msg}`);
    }
  },
};

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * مخزن كوكيز خفيف وسريع لجلسات تيك توك وانستغرام (ttwid, tt_chain_token, csrftoken).
 */
export class SimpleCookieJar {
  private cookies = new Map<string, string>();

  absorbFromResponse(resp: Response): void {
    const rawSetCookies: string[] =
      typeof (resp.headers as unknown as { getSetCookie?: () => string[] }).getSetCookie === "function"
        ? (resp.headers as unknown as { getSetCookie: () => string[] }).getSetCookie()
        : (resp.headers.get("set-cookie") || "").split(/,(?=\s*[^;=]+=[^;]+)/);

    for (const line of rawSetCookies) {
      if (!line) continue;
      const firstPart = line.split(";")[0]?.trim();
      if (!firstPart) continue;
      const eqIdx = firstPart.indexOf("=");
      if (eqIdx <= 0) continue;
      const name = firstPart.slice(0, eqIdx).trim();
      const val = firstPart.slice(eqIdx + 1).trim();
      if (name && val) {
        this.cookies.set(name, val);
      }
    }
  }

  get(name: string): string | undefined {
    return this.cookies.get(name);
  }

  set(name: string, value: string): void {
    this.cookies.set(name, value);
  }

  toHeader(): string {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }

  get size(): number {
    return this.cookies.size;
  }
}

export interface FetchTimeoutOptions extends RequestInit {
  timeoutMs?: number;
  cookieJar?: SimpleCookieJar;
  externalSignal?: AbortSignal;
}

/**
 * طلب HTTP سريع مع مهلة زمنية وإلغاء تلقائي عبر AbortSignal وجمع الكوكيز.
 */
export async function fetchWithTimeout(
  url: string,
  options: FetchTimeoutOptions = {}
): Promise<Response> {
  const { timeoutMs = 10000, cookieJar, externalSignal, headers, ...rest } = options;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error("Request timeout")), timeoutMs);

  const onExternalAbort = () => controller.abort(externalSignal?.reason);
  if (externalSignal) {
    if (externalSignal.aborted) {
      clearTimeout(timer);
      controller.abort(externalSignal.reason);
    } else {
      externalSignal.addEventListener("abort", onExternalAbort, { once: true });
    }
  }

  const mergedHeaders = new Headers({
    "User-Agent": DEFAULT_UA,
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
  });
  if (headers) {
    new Headers(headers).forEach((v, k) => mergedHeaders.set(k, v));
  }
  if (cookieJar && cookieJar.size > 0 && !mergedHeaders.has("Cookie")) {
    mergedHeaders.set("Cookie", cookieJar.toHeader());
  }

  try {
    const resp = await fetch(url, {
      ...rest,
      headers: mergedHeaders,
      signal: controller.signal,
    });
    if (cookieJar) {
      cookieJar.absorbFromResponse(resp);
    }
    return resp;
  } finally {
    clearTimeout(timer);
    if (externalSignal) {
      externalSignal.removeEventListener("abort", onExternalAbort);
    }
  }
}

/**
 * سباق متوازي بين عدة مسارات تحميل:
 * أول مسار يُعيد قيمة صالحة (غير null/undefined) يفوز فوراً، ويتم إلغاء بقية المسارات عبر AbortController!
 */
export async function raceFirstSuccess<T>(
  tasks: Array<(signal: AbortSignal) => Promise<T | null | undefined>>,
  overallTimeoutMs = 20000
): Promise<T | null> {
  if (!tasks.length) return null;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error("Race timeout")), overallTimeoutMs);

  return new Promise<T | null>((resolve) => {
    let settled = false;
    let remaining = tasks.length;

    const finish = (val: T | null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      controller.abort();
      resolve(val);
    };

    const onTimeout = () => finish(null);
    controller.signal.addEventListener("abort", () => {
      if (!settled) finish(null);
    }, { once: true });

    for (const task of tasks) {
      Promise.resolve()
        .then(() => task(controller.signal))
        .then((res) => {
          if (res !== null && res !== undefined) {
            finish(res);
          } else {
            remaining -= 1;
            if (remaining === 0) finish(null);
          }
        })
        .catch(() => {
          remaining -= 1;
          if (remaining === 0) finish(null);
        });
    }

    // Keep reference so TypeScript knows timeout is active
    void onTimeout;
  });
}

/**
 * Semaphore للتحكم في التزامن بدون حجب Event Loop.
 */
export class AsyncSemaphore {
  private active = 0;
  private queue: Array<() => void> = [];

  constructor(private readonly maxConcurrency: number) {}

  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.maxConcurrency) {
      await new Promise<void>((resolve) => this.queue.push(resolve));
    }
    this.active += 1;
    try {
      return await fn();
    } finally {
      this.active -= 1;
      const next = this.queue.shift();
      if (next) next();
    }
  }
}

/**
 * تنفيذ مصفوفة مهام بالتوازي مع حد أقصى للتزامن (مثلاً لتحميل صور الألبوم بسرعة فائقة).
 */
export async function mapConcurrent<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;

  async function next(): Promise<void> {
    while (cursor < items.length) {
      const idx = cursor;
      cursor += 1;
      results[idx] = await worker(items[idx], idx);
    }
  }

  const workers = Array.from({ length: Math.min(concurrency, items.length) }, () => next());
  await Promise.all(workers);
  return results;
}
