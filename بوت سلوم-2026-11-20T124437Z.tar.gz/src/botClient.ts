/**
 * عميل Telegram Bot API غير متزامن ومحصن (Native Node.js Fetch + Keep-Alive):
 * - يدعم أزرار تيليجرام الملونة (style) والأيقونات المميزة (icon_custom_emoji_id) مع fallback تلقائي.
 * - رفع مباشر سريع للملفات (multipart/form-data) بدون تجميد الحلقة الرئيسية.
 * - نظام الاشتراك الإجباري المحصن ضد خطأ (member list is inaccessible).
 * - حلقة Polling مقاومة لأخطاء 502 / 503 / 504 / 429 / 409 وانقطاع الشبكة.
 */

import fs from "node:fs";
import path from "node:path";
import { BOT_TOKEN, DEFAULT_FORCE_SUB_TEXT } from "./config.js";
import { db } from "./database.js";
import { fetchWithTimeout, logger, sleep } from "./network.js";

export interface TgUser {
  id: number;
  is_bot?: boolean;
  first_name?: string;
  username?: string;
}

export interface TgChat {
  id: number;
  type: "private" | "group" | "supergroup" | "channel";
  title?: string;
  username?: string;
  invite_link?: string;
}

export interface TgMessageEntity {
  type: string;
  offset: number;
  length: number;
  url?: string;
  language?: string;
  custom_emoji_id?: string;
}

export interface TgMessage {
  message_id: number;
  from?: TgUser;
  chat: TgChat;
  text?: string;
  caption?: string;
  entities?: TgMessageEntity[];
  reply_to_message?: TgMessage;
  forward_from_chat?: TgChat;
  document?: { file_id: string; file_name?: string };
  sticker?: { file_id: string; custom_emoji_id?: string; emoji?: string };
  photo?: Array<{ file_id: string }>;
  video?: { file_id: string };
  audio?: { file_id: string };
  voice?: { file_id: string };
  animation?: { file_id: string };
}

export interface TgCallbackQuery {
  id: string;
  from: TgUser;
  message?: TgMessage;
  data?: string;
}

export interface TgInlineQuery {
  id: string;
  from: TgUser;
  query: string;
}

export interface TgUpdate {
  update_id: number;
  message?: TgMessage;
  callback_query?: TgCallbackQuery;
  inline_query?: TgInlineQuery;
}

export interface SmartInlineButton {
  text: string;
  callback_data?: string;
  url?: string;
  style?: "primary" | "success" | "danger";
  icon_custom_emoji_id?: string;
}

export interface InlineKeyboardMarkup {
  inline_keyboard: SmartInlineButton[][];
}

export interface AdminState {
  action: string;
  ui_key?: string;
  temp_label_saved?: boolean;
}

export const adminStates = new Map<number, AdminState>();

export function escapeHtml(text: unknown): string {
  return String(text ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function utf16Slice(text: string, offset: number, length: number): string {
  try {
    return text.slice(offset, offset + length);
  } catch {
    return "";
  }
}

export function stripAdvancedButtonFields(
  markup?: InlineKeyboardMarkup | null
): InlineKeyboardMarkup | undefined {
  if (!markup || !Array.isArray(markup.inline_keyboard)) return undefined;
  return {
    inline_keyboard: markup.inline_keyboard.map((row) =>
      row.map((btn) => {
        const clean: SmartInlineButton = { text: btn.text };
        if (btn.callback_data !== undefined) clean.callback_data = btn.callback_data;
        if (btn.url !== undefined) clean.url = btn.url;
        return clean;
      })
    ),
  };
}

export class TelegramApiError extends Error {
  constructor(
    public readonly errorCode: number,
    public readonly description: string,
    public readonly parameters?: { retry_after?: number }
  ) {
    super(`Telegram API Error (${errorCode}): ${description}`);
  }
}

class TelegramBotClient {
  private readonly apiBase = `https://api.telegram.org/bot${BOT_TOKEN}`;
  private readonly fileBase = `https://api.telegram.org/file/bot${BOT_TOKEN}`;
  private cachedUsername: string | null = null;
  private cachedBotId: number | null = null;

  async callApi<T = unknown>(
    method: string,
    payload: Record<string, unknown> = {},
    timeoutMs = 45000
  ): Promise<T> {
    const cleanPayload: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(payload)) {
      if (v !== undefined && v !== null) cleanPayload[k] = v;
    }

    const resp = await fetchWithTimeout(`${this.apiBase}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cleanPayload),
      timeoutMs,
    });

    if (resp.status >= 500) {
      throw new TelegramApiError(resp.status, `HTTP ${resp.status}`);
    }

    const json = (await resp.json()) as {
      ok: boolean;
      result?: T;
      error_code?: number;
      description?: string;
      parameters?: { retry_after?: number };
    };

    if (!json.ok) {
      throw new TelegramApiError(
        json.error_code || resp.status,
        json.description || "Unknown Telegram API error",
        json.parameters
      );
    }

    return json.result as T;
  }

  async callMultipart<T = unknown>(
    method: string,
    fields: Record<string, unknown>,
    files: Record<string, string>,
    timeoutMs = 180000
  ): Promise<T> {
    const form = new FormData();

    for (const [k, v] of Object.entries(fields)) {
      if (v === undefined || v === null) continue;
      form.append(k, typeof v === "object" ? JSON.stringify(v) : String(v));
    }

    for (const [fieldName, filePath] of Object.entries(files)) {
      const buf = fs.readFileSync(filePath);
      const blob = new Blob([buf]);
      form.append(fieldName, blob, path.basename(filePath));
    }

    const resp = await fetchWithTimeout(`${this.apiBase}/${method}`, {
      method: "POST",
      body: form,
      timeoutMs,
    });

    if (resp.status >= 500) {
      throw new TelegramApiError(resp.status, `HTTP ${resp.status}`);
    }

    const json = (await resp.json()) as {
      ok: boolean;
      result?: T;
      error_code?: number;
      description?: string;
      parameters?: { retry_after?: number };
    };

    if (!json.ok) {
      throw new TelegramApiError(
        json.error_code || resp.status,
        json.description || "Multipart API error",
        json.parameters
      );
    }

    return json.result as T;
  }

  async getMe(): Promise<TgUser> {
    return this.callApi<TgUser>("getMe", {}, 15000);
  }

  async getBotUsername(): Promise<string> {
    if (this.cachedUsername) return this.cachedUsername;
    try {
      const me = await this.getMe();
      this.cachedUsername = me.username || "البوت";
      this.cachedBotId = me.id;
      return this.cachedUsername;
    } catch {
      return "البوت";
    }
  }

  async getBotId(): Promise<number | null> {
    if (this.cachedBotId) return this.cachedBotId;
    try {
      const me = await this.getMe();
      this.cachedBotId = me.id;
      return this.cachedBotId;
    } catch {
      const prefix = Number.parseInt(BOT_TOKEN.split(":")[0] || "", 10);
      return Number.isFinite(prefix) ? prefix : null;
    }
  }

  async getUpdates(offset: number, timeoutSec = 20): Promise<TgUpdate[]> {
    return this.callApi<TgUpdate[]>(
      "getUpdates",
      {
        offset,
        timeout: timeoutSec,
        allowed_updates: ["message", "callback_query", "inline_query"],
      },
      (timeoutSec + 20) * 1000
    );
  }

  async sendMessage(
    chatId: number | string,
    text: string,
    opts: {
      parse_mode?: string;
      entities?: TgMessageEntity[];
      reply_markup?: InlineKeyboardMarkup;
      reply_to_message_id?: number;
      disable_web_page_preview?: boolean;
    } = {}
  ): Promise<TgMessage> {
    return this.callApi<TgMessage>("sendMessage", {
      chat_id: chatId,
      text,
      ...opts,
    });
  }

  async editMessageText(
    chatId: number | string,
    messageId: number,
    text: string,
    opts: {
      parse_mode?: string;
      reply_markup?: InlineKeyboardMarkup;
      disable_web_page_preview?: boolean;
    } = {}
  ): Promise<TgMessage | boolean> {
    return this.callApi("editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text,
      ...opts,
    });
  }

  async deleteMessage(chatId: number | string, messageId: number): Promise<void> {
    try {
      await this.callApi("deleteMessage", { chat_id: chatId, message_id: messageId }, 10000);
    } catch {
      // ignore
    }
  }

  async sendChatAction(chatId: number | string, action: string): Promise<void> {
    try {
      await this.callApi("sendChatAction", { chat_id: chatId, action }, 8000);
    } catch {
      // ignore
    }
  }

  async sendSticker(chatId: number | string, sticker: string): Promise<void> {
    await this.callApi("sendSticker", { chat_id: chatId, sticker }, 15000);
  }

  async sendVideo(
    chatId: number | string,
    videoPathOrFileId: string,
    opts: {
      caption?: string;
      parse_mode?: string;
      supports_streaming?: boolean;
      width?: number;
      height?: number;
      duration?: number;
      reply_to_message_id?: number;
      reply_markup?: InlineKeyboardMarkup;
    } = {}
  ): Promise<TgMessage> {
    if (fs.existsSync(videoPathOrFileId)) {
      return this.callMultipart<TgMessage>(
        "sendVideo",
        { chat_id: chatId, ...opts },
        { video: videoPathOrFileId }
      );
    }
    return this.callApi<TgMessage>("sendVideo", {
      chat_id: chatId,
      video: videoPathOrFileId,
      ...opts,
    });
  }

  async sendPhoto(
    chatId: number | string,
    photoPathOrFileId: string,
    opts: {
      caption?: string;
      parse_mode?: string;
      reply_to_message_id?: number;
      reply_markup?: InlineKeyboardMarkup;
    } = {}
  ): Promise<TgMessage> {
    if (fs.existsSync(photoPathOrFileId)) {
      return this.callMultipart<TgMessage>(
        "sendPhoto",
        { chat_id: chatId, ...opts },
        { photo: photoPathOrFileId }
      );
    }
    return this.callApi<TgMessage>("sendPhoto", {
      chat_id: chatId,
      photo: photoPathOrFileId,
      ...opts,
    });
  }

  async sendMediaGroupPhotos(
    chatId: number | string,
    imagePaths: string[],
    caption: string,
    replyToMessageId?: number
  ): Promise<TgMessage[]> {
    const files: Record<string, string> = {};
    const media = imagePaths.map((imgPath, idx) => {
      const attachName = `photo_${idx}`;
      files[attachName] = imgPath;
      return idx === 0
        ? { type: "photo", media: `attach://${attachName}`, caption, parse_mode: "HTML" }
        : { type: "photo", media: `attach://${attachName}` };
    });

    return this.callMultipart<TgMessage[]>(
      "sendMediaGroup",
      { chat_id: chatId, media, reply_to_message_id: replyToMessageId },
      files
    );
  }

  async sendVoice(
    chatId: number | string,
    voicePathOrFileId: string,
    opts: { caption?: string; parse_mode?: string; reply_to_message_id?: number } = {}
  ): Promise<TgMessage> {
    if (fs.existsSync(voicePathOrFileId)) {
      return this.callMultipart<TgMessage>(
        "sendVoice",
        { chat_id: chatId, ...opts },
        { voice: voicePathOrFileId }
      );
    }
    return this.callApi<TgMessage>("sendVoice", {
      chat_id: chatId,
      voice: voicePathOrFileId,
      ...opts,
    });
  }

  async sendAudio(
    chatId: number | string,
    audioPathOrFileId: string,
    opts: {
      caption?: string;
      title?: string;
      performer?: string;
      parse_mode?: string;
      reply_to_message_id?: number;
    } = {}
  ): Promise<TgMessage> {
    if (fs.existsSync(audioPathOrFileId)) {
      return this.callMultipart<TgMessage>(
        "sendAudio",
        { chat_id: chatId, ...opts },
        { audio: audioPathOrFileId }
      );
    }
    return this.callApi<TgMessage>("sendAudio", {
      chat_id: chatId,
      audio: audioPathOrFileId,
      ...opts,
    });
  }

  async answerCallbackQuery(
    callbackQueryId: string,
    text?: string,
    showAlert = false
  ): Promise<void> {
    try {
      await this.callApi(
        "answerCallbackQuery",
        { callback_query_id: callbackQueryId, text, show_alert: showAlert },
        10000
      );
    } catch {
      // ignore
    }
  }

  async answerInlineQuery(
    inlineQueryId: string,
    results: Array<Record<string, unknown>>,
    cacheTime = 5
  ): Promise<void> {
    await this.callApi("answerInlineQuery", {
      inline_query_id: inlineQueryId,
      results,
      cache_time: cacheTime,
    });
  }

  async getChat(chatId: string | number): Promise<TgChat> {
    return this.callApi<TgChat>("getChat", { chat_id: chatId }, 12000);
  }

  async getChatMember(
    chatId: string | number,
    userId: number
  ): Promise<{ status: string; is_member?: boolean }> {
    return this.callApi("getChatMember", { chat_id: chatId, user_id: userId }, 12000);
  }

  async exportChatInviteLink(chatId: string | number): Promise<string> {
    return this.callApi<string>("exportChatInviteLink", { chat_id: chatId }, 12000);
  }

  async copyMessage(
    chatId: number | string,
    fromChatId: number | string,
    messageId: number
  ): Promise<void> {
    await this.callApi("copyMessage", {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
    });
  }

  async forwardMessage(
    chatId: number | string,
    fromChatId: number | string,
    messageId: number
  ): Promise<void> {
    await this.callApi("forwardMessage", {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
    });
  }

  async downloadTelegramFile(fileId: string): Promise<Buffer> {
    const fileInfo = await this.callApi<{ file_path: string }>("getFile", { file_id: fileId }, 15000);
    const resp = await fetchWithTimeout(`${this.fileBase}/${fileInfo.file_path}`, { timeoutMs: 25000 });
    if (!resp.ok) throw new Error(`Failed to download Telegram file (${resp.status})`);
    return Buffer.from(await resp.arrayBuffer());
  }

  async runPolling(onUpdate: (update: TgUpdate) => Promise<void>): Promise<void> {
    let offset = 0;
    let backoff = 2000;

    // تجاهل التحديثات القديمة العالقة عند بدء التشغيل (skip_pending=True)
    try {
      const pending = await this.getUpdates(-1, 1);
      if (pending.length > 0) {
        offset = pending[pending.length - 1].update_id + 1;
      }
    } catch {
      // continue smoothly
    }

    while (true) {
      try {
        const updates = await this.getUpdates(offset, 20);
        backoff = 2000;
        for (const upd of updates) {
          offset = Math.max(offset, upd.update_id + 1);
          // تشغيل كل تحديث بشكل غير متزامن حتى لا يعطّل مستخدم آخر
          onUpdate(upd).catch((err) => logger.warn(`Update handler note: ${String(err)}`));
        }
      } catch (err) {
        if (err instanceof TelegramApiError) {
          const code = err.errorCode;
          if (code === 502 || code === 503 || code === 504) {
            logger.info(`استجابة مؤقتة من خادم تيليجرام (${code}) — إعادة الاتصال خلال ${backoff / 1000} ثوانٍ...`);
            await sleep(backoff);
            backoff = Math.min(backoff * 2, 15000);
          } else if (code === 429) {
            const waitSec = Math.max(err.parameters?.retry_after || 5, 3);
            logger.info(`حد الطلبات من تيليجرام (429) — انتظار ${waitSec} ثوانٍ...`);
            await sleep(waitSec * 1000);
          } else if (code === 409) {
            logger.warn("يوجد نسخة أخرى من البوت تعمل بنفس التوكن (409) — إعادة المحاولة بعد 10 ثوانٍ...");
            await sleep(10000);
          } else {
            logger.warn(`خطأ من Telegram API (${code}): ${err.description}`);
            await sleep(backoff);
            backoff = Math.min(backoff * 2, 15000);
          }
        } else {
          await sleep(backoff);
          backoff = Math.min(backoff + 2000, 10000);
        }
      }
    }
  }
}

export const bot = new TelegramBotClient();

export function getActiveCustomEmoji(
  scope: "start" | "sections",
  uiKey?: string
): [string | null, string] {
  if (uiKey) {
    const cfg = db.getUiConfig(uiKey);
    if (cfg.custom_emoji_id) {
      return [cfg.custom_emoji_id, cfg.custom_emoji_char || ""];
    }
  }

  const placement = db.getSetting("premium_placement", "off");
  if (placement === "off") return [null, ""];
  if (scope === "start" && placement !== "both" && placement !== "start_only") return [null, ""];
  if (scope === "sections" && placement !== "both" && placement !== "sections_only") return [null, ""];

  if (scope === "start") {
    let ceId = db.getSetting("premium_start_emoji_id", "").trim();
    let ceChar = db.getSetting("premium_start_emoji_char", "").trim();
    if (!ceId) {
      ceId = db.getSetting("premium_sections_emoji_id", "").trim();
      ceChar = db.getSetting("premium_sections_emoji_char", "").trim();
    }
    return [ceId || null, ceChar];
  }

  let ceId = db.getSetting("premium_sections_emoji_id", "").trim();
  let ceChar = db.getSetting("premium_sections_emoji_char", "").trim();
  if (!ceId) {
    ceId = db.getSetting("premium_start_emoji_id", "").trim();
    ceChar = db.getSetting("premium_start_emoji_char", "").trim();
  }
  return [ceId || null, ceChar];
}

export function formatPremiumBadge(
  scope: "start" | "sections" = "sections",
  fallbackEmoji = "",
  uiKey?: string
): string {
  const [ceId, ceChar] = getActiveCustomEmoji(scope, uiKey);
  if (ceId) {
    const ch = ceChar || fallbackEmoji || "•";
    return `<tg-emoji emoji-id="${escapeHtml(ceId)}">${escapeHtml(ch)}</tg-emoji> `;
  }
  return "";
}

export function resolveButtonStyle(
  preferredStyle: "primary" | "success" | "danger" = "primary"
): "primary" | "success" | "danger" | undefined {
  const theme = db.getSetting("color_theme", "mixed");
  if (theme === "default") return undefined;
  if (theme === "primary" || theme === "success" || theme === "danger") return theme;
  return preferredStyle;
}

export function makeBtn(opts: {
  text?: string;
  callback_data?: string;
  url?: string;
  style?: "primary" | "success" | "danger";
  scope?: "start" | "sections";
  ui_key?: string;
  format_vars?: Record<string, string | number>;
}): SmartInlineButton {
  let finalText = opts.text;
  if (opts.ui_key) {
    const cfg = db.getUiConfig(opts.ui_key);
    if (finalText === undefined) finalText = cfg.btn_label;
    if (opts.format_vars) {
      for (const [k, v] of Object.entries(opts.format_vars)) {
        finalText = finalText.replaceAll(`{${k}}`, String(v));
      }
    }
  }

  const btn: SmartInlineButton = { text: String(finalText || "") };
  if (opts.callback_data !== undefined) btn.callback_data = opts.callback_data;
  if (opts.url !== undefined) btn.url = opts.url;

  const finalStyle = resolveButtonStyle(opts.style || "primary");
  if (finalStyle) btn.style = finalStyle;

  const [ceId] = getActiveCustomEmoji(opts.scope || "sections", opts.ui_key);
  if (ceId) btn.icon_custom_emoji_id = String(ceId);

  return btn;
}

export async function sendUiOptionalSticker(chatId: number | string, uiKey: string): Promise<void> {
  const cfg = db.getUiConfig(uiKey);
  const stId = (cfg.sticker_id || "").trim();
  if (!stId) return;
  try {
    await bot.sendSticker(chatId, stId);
  } catch (e) {
    logger.debug(`Optional UI sticker note for ${uiKey}: ${String(e)}`);
  }
}

export async function safeSendMessage(
  chatId: number | string,
  text: string,
  opts: {
    reply_markup?: InlineKeyboardMarkup;
    parse_mode?: string;
    entities?: TgMessageEntity[];
    reply_to_message_id?: number;
    disable_web_page_preview?: boolean;
  } = {}
): Promise<TgMessage | null> {
  const disablePreview = opts.disable_web_page_preview ?? true;
  const parseMode = opts.entities ? undefined : (opts.parse_mode ?? "HTML");

  try {
    return await bot.sendMessage(chatId, text, {
      parse_mode: parseMode,
      entities: opts.entities,
      reply_markup: opts.reply_markup,
      reply_to_message_id: opts.reply_to_message_id,
      disable_web_page_preview: disablePreview,
    });
  } catch (e) {
    const errStr = String(e).toUpperCase();
    if (opts.reply_markup && ["BUTTON_", "CUSTOM_EMOJI", "STYLE", "400"].some((k) => errStr.includes(k))) {
      try {
        return await bot.sendMessage(chatId, text.replace(/<\/?tg-emoji[^>]*>/g, ""), {
          parse_mode: parseMode,
          reply_markup: stripAdvancedButtonFields(opts.reply_markup),
          reply_to_message_id: opts.reply_to_message_id,
          disable_web_page_preview: disablePreview,
        });
      } catch {
        // continue to plain fallback
      }
    }
    try {
      const plain = text.replace(/<[^>]+>/g, "");
      return await bot.sendMessage(chatId, plain, {
        reply_markup: stripAdvancedButtonFields(opts.reply_markup),
        reply_to_message_id: opts.reply_to_message_id,
      });
    } catch {
      return null;
    }
  }
}

export async function safeEditMessage(
  chatId: number | string,
  messageId: number,
  text: string,
  opts: { reply_markup?: InlineKeyboardMarkup; parse_mode?: string } = {}
): Promise<TgMessage | boolean | null> {
  const parseMode = opts.parse_mode ?? "HTML";
  try {
    return await bot.editMessageText(chatId, messageId, text, {
      parse_mode: parseMode,
      reply_markup: opts.reply_markup,
      disable_web_page_preview: true,
    });
  } catch (e) {
    const errL = String(e).toLowerCase();
    if (errL.includes("message is not modified")) return null;
    if (errL.includes("message to edit not found")) {
      return safeSendMessage(chatId, text, { reply_markup: opts.reply_markup, parse_mode: parseMode });
    }
    try {
      return await bot.editMessageText(chatId, messageId, text.replace(/<\/?tg-emoji[^>]*>/g, ""), {
        parse_mode: parseMode,
        reply_markup: stripAdvancedButtonFields(opts.reply_markup),
        disable_web_page_preview: true,
      });
    } catch {
      return null;
    }
  }
}

export async function checkUserSubscription(userId: number) {
  if (db.isAdmin(userId)) return [];
  if (db.getSetting("force_sub_enabled", "1") !== "1") return [];

  const channels = db.getForceChannels();
  if (!channels.length) return [];

  const unsubscribed = [];
  for (const ch of channels) {
    const chatId = String(ch.chat_id);
    if (db.isChannelTemporarilySkipped(chatId)) continue;
    try {
      const member = await bot.getChatMember(chatId, userId);
      if (member.status === "left" || member.status === "kicked") {
        unsubscribed.push(ch);
      } else if (member.status === "restricted" && member.is_member === false) {
        unsubscribed.push(ch);
      }
    } catch (e) {
      const errL = String(e).toLowerCase();
      if (
        [
          "member list is inaccessible",
          "chat not found",
          "bot is not a member",
          "bot was kicked",
          "forbidden",
          "have no rights",
          "not enough rights",
          "channel_private",
        ].some((k) => errL.includes(k))
      ) {
        db.markChannelInaccessible(chatId, 3600);
      }
    }
  }
  return unsubscribed;
}

export async function sendForceSubPrompt(
  chatId: number | string,
  user: TgUser,
  replyToMessageId?: number
): Promise<boolean> {
  const unsubscribed = await checkUserSubscription(user.id);
  if (!unsubscribed.length) return true;

  await sendUiOptionalSticker(chatId, "btn_verify_sub");

  const rows: SmartInlineButton[][] = [];
  const chButtons = unsubscribed.map((ch, idx) =>
    makeBtn({
      text: (ch.title || `قناة ${idx + 1}`).slice(0, 20),
      url: ch.invite_link || "https://t.me/",
      style: "primary",
      scope: "sections",
    })
  );
  for (let i = 0; i < chButtons.length; i += 2) {
    rows.push(chButtons.slice(i, i + 2));
  }
  rows.push([
    makeBtn({
      callback_data: "verify_subscription",
      style: "success",
      scope: "sections",
      ui_key: "btn_verify_sub",
    }),
  ]);

  const verifyCfg = db.getUiConfig("btn_verify_sub");
  const rawText = verifyCfg.inner_content || db.getSetting("force_sub_text", DEFAULT_FORCE_SUB_TEXT);
  const safeName = escapeHtml(user.first_name || "المستخدم");
  const badge = formatPremiumBadge("sections", "", "btn_verify_sub");
  const text = `${badge}<b>الاشتراك الإجباري</b>\n<blockquote>${escapeHtml(rawText).replaceAll("{name}", safeName)}</blockquote>`;

  await safeSendMessage(chatId, text, {
    reply_markup: { inline_keyboard: rows },
    parse_mode: "HTML",
    reply_to_message_id: replyToMessageId,
  });
  return false;
}
