/**
 * مدير مكتبة yt-dlp المستقل ذو التحديث التلقائي الفوري والأداء العالي:
 * - يتحقق من وجود أحدث إصدار رسمي من yt-dlp ويقوم بتنزيله أو تحديثه تلقائياً (`yt-dlp -U`)
 *   عند تشغيل البوت وكل 12 ساعة، ويعمل التحديث فوراً على التحميل التالي بدون إعادة تشغيل!
 * - يفعّل التحميل المتوازي للمقاطع (--concurrent-fragments 12) وتقسيم HTTP (--http-chunk-size 10485760)
 *   ودعم aria2c تلقائياً عند توفره على السيرفر.
 * - يزيل مضيف تيك توك المعطل (api16-normal-c-useast1a.tiktokv.com) ويعتمد على محرك yt-dlp الحديث.
 */

import { execFile } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { BIN_DIR, COOKIES_FILE_PATH } from "../config.js";
import { hasCookiesFile } from "../database.js";
import { checkCommandExists, checkFfmpegInstalled } from "../mediaUtils.js";
import { DEFAULT_UA, fetchWithTimeout, logger } from "../network.js";

const execFileAsync = promisify(execFile);

const IS_WIN = process.platform === "win32";
const LOCAL_YTDLP_PATH = path.join(BIN_DIR, IS_WIN ? "yt-dlp.exe" : "yt-dlp");

let cachedBinaryPath: string | null = null;
let cachedAria2Available: boolean | null = null;
let autoUpdateInterval: NodeJS.Timeout | null = null;

function getOfficialYtDlpDownloadUrl(): string {
  const platform = process.platform;
  const arch = os.arch();
  if (platform === "win32") {
    return "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe";
  }
  if (platform === "darwin") {
    return "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos";
  }
  if (platform === "linux" && arch === "arm64") {
    return "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64";
  }
  if (platform === "linux" && arch === "x64") {
    return "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux";
  }
  return "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp";
}

export async function isAria2Available(): Promise<boolean> {
  if (cachedAria2Available !== null) return cachedAria2Available;
  cachedAria2Available = await checkCommandExists("aria2c");
  return cachedAria2Available;
}

/**
 * تنزيل أو تحديث النسخة المستقلة الأحدث من yt-dlp تلقائياً.
 */
export async function ensureYtDlpBinary(forceUpdate = false): Promise<string> {
  if (cachedBinaryPath && !forceUpdate && fs.existsSync(cachedBinaryPath)) {
    return cachedBinaryPath;
  }

  // 1) إذا كانت النسخة المحلية موجودة، نحدثها بـ -U
  if (fs.existsSync(LOCAL_YTDLP_PATH)) {
    cachedBinaryPath = LOCAL_YTDLP_PATH;
    if (forceUpdate) {
      try {
        const { stdout } = await execFileAsync(LOCAL_YTDLP_PATH, ["-U"], { timeout: 60000 });
        logger.info(`[yt-dlp] حالة التحديث: ${(stdout || "").trim().split("\n")[0] || "محدّث"}`);
      } catch (err) {
        logger.debug(`[yt-dlp] update note: ${String(err)}`);
      }
    }
    return LOCAL_YTDLP_PATH;
  }

  // 2) محاولة تنزيل أحدث نسخة رسمية مستقلة مباشرة إلى ./bin/yt-dlp (أسرع وأحدث دائماً من نسخ النظام)
  try {
    const dlUrl = getOfficialYtDlpDownloadUrl();
    logger.info(`[yt-dlp] جاري تنزيل أحدث إصدار رسمي من yt-dlp...`);
    const resp = await fetchWithTimeout(dlUrl, { timeoutMs: 45000, redirect: "follow" });
    if (resp.ok) {
      const buf = Buffer.from(await resp.arrayBuffer());
      if (buf.length > 500_000) {
        fs.mkdirSync(BIN_DIR, { recursive: true });
        const tmpPath = `${LOCAL_YTDLP_PATH}.tmp`;
        fs.writeFileSync(tmpPath, buf);
        if (!IS_WIN) fs.chmodSync(tmpPath, 0o755);
        fs.renameSync(tmpPath, LOCAL_YTDLP_PATH);
        cachedBinaryPath = LOCAL_YTDLP_PATH;
        try {
          const { stdout } = await execFileAsync(LOCAL_YTDLP_PATH, ["--version"], { timeout: 5000 });
          logger.info(`[yt-dlp] تم تثبيت أحدث إصدار بنجاح: ${stdout.trim()}`);
        } catch {
          logger.info("[yt-dlp] تم تنزيل أحدث إصدار بنجاح.");
        }
        return LOCAL_YTDLP_PATH;
      }
    }
  } catch (err) {
    logger.debug(`[yt-dlp] download binary note: ${String(err)}`);
  }

  // 3) الاعتماد على yt-dlp المثبت في النظام إن تعذر التنزيل
  if (await checkCommandExists("yt-dlp")) {
    cachedBinaryPath = "yt-dlp";
    if (forceUpdate) {
      try {
        await execFileAsync("yt-dlp", ["-U"], { timeout: 45000 });
      } catch {
        // ignore if managed by OS package manager
      }
    }
    return "yt-dlp";
  }

  return "yt-dlp";
}

/**
 * تشغيل التحديث التلقائي لـ yt-dlp في الخلفية عند الإقلاع وكل 12 ساعة.
 */
export function startYtDlpAutoUpdater(): void {
  ensureYtDlpBinary(true).catch((e) => logger.debug(`[yt-dlp] startup check: ${String(e)}`));
  if (!autoUpdateInterval) {
    autoUpdateInterval = setInterval(() => {
      ensureYtDlpBinary(true).catch(() => {});
    }, 12 * 60 * 60 * 1000);
    autoUpdateInterval.unref();
  }
}

export interface YtDlpArgOptions {
  targetUrl: string;
  outTemplate: string;
  mode: "video" | "voice" | "mp3";
  platform: "tiktok" | "youtube" | "instagram" | "generic";
  hasFfmpeg: boolean;
  hasAria2?: boolean;
  hasCookies?: boolean;
  cookiesPath?: string;
  extractorArgs?: string;
  proxy?: string;
  fallbackSimpleFormat?: boolean;
}

/**
 * بناء أوامر yt-dlp المحسّنة للسرعة القصوى وأعلى توافق مع تيليجرام (H.264 MP4).
 */
export function buildYtDlpArgs(opts: YtDlpArgOptions): string[] {
  const {
    targetUrl,
    outTemplate,
    mode,
    platform,
    hasFfmpeg,
    hasAria2 = false,
    hasCookies = false,
    cookiesPath = COOKIES_FILE_PATH,
    extractorArgs,
    proxy,
    fallbackSimpleFormat = false,
  } = opts;

  let formatSelector: string;
  if (mode === "voice" || mode === "mp3") {
    formatSelector = "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio/best[ext=mp4]/best";
  } else if (platform === "tiktok") {
    // يفضّل H.264 بدون علامة مائية (تجنباً لـ HEVC الذي يجبر FFmpeg على إعادة الترميز البطيئة)
    formatSelector = "best[vcodec^=avc1][ext=mp4]/best[vcodec^=h264][ext=mp4]/best[ext=mp4]/best";
  } else if (fallbackSimpleFormat || !hasFfmpeg) {
    formatSelector = "best[height<=1080][ext=mp4]/best[ext=mp4]/best";
  } else {
    formatSelector =
      "bestvideo*[height<=1080][vcodec^=avc1]+bestaudio[ext=m4a]/" +
      "bestvideo*[height<=1080][ext=mp4]+bestaudio[ext=m4a]/" +
      "bestvideo*[height<=1080]+bestaudio/" +
      "best[height<=1080][ext=mp4]/" +
      "bestvideo*+bestaudio/best";
  }

  const args: string[] = [
    "--no-warnings",
    "--quiet",
    "--print-json",
    "--no-cache-dir",
    "--force-ipv4",
    "--no-check-certificates",
    "--geo-bypass",
    "--socket-timeout", "18",
    "--retries", "2",
    "--fragment-retries", "2",
    "--concurrent-fragments", "12",
    "--http-chunk-size", "10485760",
    "--buffer-size", "16K",
    "-o", outTemplate,
    "-f", formatSelector,
  ];

  if (platform !== "instagram") {
    args.push("--no-playlist");
  }

  if (mode === "video" && hasFfmpeg && platform !== "tiktok" && !fallbackSimpleFormat) {
    args.push("--merge-output-format", "mp4");
  }

  if (mode === "video") {
    if (platform === "tiktok") {
      args.push("-S", "vcodec:h264,res:1080,ext:mp4");
    } else {
      args.push("-S", "res:1080,vcodec:h264,ext:mp4:m4a");
    }
  }

  if (platform !== "tiktok") {
    args.push("--user-agent", DEFAULT_UA);
    args.push("--add-header", "Accept-Language:en-US,en;q=0.9,ar;q=0.8");
  }

  if (extractorArgs) {
    args.push("--extractor-args", extractorArgs);
  }

  if (hasAria2 && mode === "video") {
    args.push("--downloader", "aria2c");
    args.push("--downloader-args", "aria2c:-x 8 -s 8 -k 1M --summary-interval=0");
  }

  if (hasCookies && cookiesPath) {
    args.push("--cookies", cookiesPath);
  }

  if (proxy) {
    args.push("--proxy", proxy);
  }

  args.push(targetUrl);
  return args;
}

export interface YtDlpRunResult {
  success: boolean;
  title: string;
  description: string;
  author: string;
  error?: string;
}

export async function runYtDlpDownload(params: {
  targetUrl: string;
  workDir: string;
  mode: "video" | "voice" | "mp3";
  platform: "tiktok" | "youtube" | "instagram" | "generic";
  extractorArgs?: string;
  proxy?: string;
  fallbackSimpleFormat?: boolean;
  timeoutMs?: number;
  signal?: AbortSignal;
}): Promise<YtDlpRunResult> {
  const binary = await ensureYtDlpBinary(false);
  const hasFfmpeg = await checkFfmpegInstalled();
  const hasAria2 = await isAria2Available();

  const outTemplate = path.join(params.workDir, "media_%(id)s_%(autonumber)s.%(ext)s");
  const args = buildYtDlpArgs({
    targetUrl: params.targetUrl,
    outTemplate,
    mode: params.mode,
    platform: params.platform,
    hasFfmpeg,
    hasAria2,
    hasCookies: hasCookiesFile(),
    cookiesPath: COOKIES_FILE_PATH,
    extractorArgs: params.extractorArgs,
    proxy: params.proxy,
    fallbackSimpleFormat: params.fallbackSimpleFormat,
  });

  try {
    const { stdout } = await execFileAsync(binary, args, {
      timeout: params.timeoutMs || 65000,
      maxBuffer: 10 * 1024 * 1024,
      signal: params.signal,
    });

    let title = "";
    let description = "";
    let author = "";

    const lines = (stdout || "")
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l.startsWith("{"));

    if (lines.length > 0) {
      try {
        const info = JSON.parse(lines[0]);
        title = String(info.title || "").trim();
        description = String(info.description || "").trim();
        author = String(info.uploader || info.channel || info.uploader_id || "").trim();
      } catch {
        // ignore JSON parse issues
      }
    }

    return { success: true, title, description, author };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    logger.debug(`[yt-dlp] run note (${params.platform}): ${errMsg.slice(0, 220)}`);
    return { success: false, title: "", description: "", author: "", error: errMsg };
  }
}

/**
 * استخراج سريع للنتائج من yt-dlp بدون تنزيل (للبحث الاحتياطي في يوتيوب).
 */
export async function runYtDlpFlatSearch(query: string, limit = 5): Promise<Array<{
  id: string;
  url: string;
  title: string;
  channel: string;
  durationSec: number;
}>> {
  const binary = await ensureYtDlpBinary(false);
  const args = [
    "--quiet",
    "--no-warnings",
    "--flat-playlist",
    "--skip-download",
    "--dump-json",
    "--force-ipv4",
    "--socket-timeout", "10",
  ];
  if (hasCookiesFile()) {
    args.push("--cookies", COOKIES_FILE_PATH);
  }
  args.push(`ytsearch${limit}:${query}`);

  try {
    const { stdout } = await execFileAsync(binary, args, { timeout: 15000, maxBuffer: 4 * 1024 * 1024 });
    const items: Array<{ id: string; url: string; title: string; channel: string; durationSec: number }> = [];
    for (const line of (stdout || "").split("\n")) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("{")) continue;
      try {
        const e = JSON.parse(trimmed);
        const id = String(e.id || "");
        const rawUrl = String(e.url || (id ? `https://www.youtube.com/watch?v=${id}` : ""));
        if (!rawUrl) continue;
        items.push({
          id,
          url: rawUrl.startsWith("http") ? rawUrl : `https://www.youtube.com/watch?v=${rawUrl}`,
          title: String(e.title || "فيديو يوتيوب").slice(0, 95),
          channel: String(e.uploader || e.channel || "YouTube").slice(0, 40),
          durationSec: Number(e.duration || 0),
        });
        if (items.length >= limit) break;
      } catch {
        continue;
      }
    }
    return items;
  } catch {
    return [];
  }
}
