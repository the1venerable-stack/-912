/**
 * خط التحميل الموحّد (Unified Download Pipeline) لجميع المنصات بأعلى دقة وأسرع مسار.
 */

import fs from "node:fs";
import path from "node:path";
import {
  cleanupFiles,
  convertToMp3,
  convertToVoiceOgg,
  prepareHighQualityVideo,
  probeHasVideoStream,
  validateAndFilterImages,
} from "../mediaUtils.js";
import { DEFAULT_UA, fetchWithTimeout } from "../network.js";
import {
  cleanInstagramAuthor,
  cleanInstagramCaptionAndTitle,
  downloadInstagramFast,
  extractInstagramShortcode,
  normalizeInstagramUrl,
} from "./instagram.js";
import { downloadTelegramPublicPost, scrapeGoogleAndWebpageMedia } from "./platforms.js";
import { downloadTikTokFast, isTikTokUrl } from "./tiktok.js";
import {
  downloadYouTubeMultiApiFallback,
  extractYouTubeVideoId,
  fetchYouTubeMetadataAndDescription,
  fetchYouTubeVisitorData,
  normalizeYouTubeUrl,
  searchYouTubeTop5,
} from "./youtube.js";
import { runYtDlpDownload } from "./ytdlp.js";

const URL_REGEX = /(https?:\/\/[^\s<>"']+)/gi;

export interface PlatformInfo {
  name: string;
  badge: string;
  key: string;
}

export interface DownloadPipelineOutput {
  status: boolean;
  title: string;
  description: string;
  author: string;
  video_path: string | null;
  extra_videos: string[];
  voice_path: string | null;
  audio_path: string | null;
  images: string[];
  error: string | null;
}

export function extractAllUrls(text: string): string[] {
  if (!text) return [];
  const cleaned: string[] = [];
  const matches = text.match(URL_REGEX) || [];
  for (const m of matches) {
    const u = m.trim().replace(/[).,!?;:'"]+$/, "");
    if (u && !cleaned.includes(u)) cleaned.push(u);
  }
  return cleaned;
}

export function extractFirstUrl(text: string): string | null {
  const urls = extractAllUrls(text);
  return urls[0] || null;
}

export async function normalizeCacheUrl(url: string): Promise<string> {
  const uClean = (url || "").trim();
  const uLow = uClean.toLowerCase();
  if (uLow.includes("instagram.com") || uLow.includes("instagr.am")) {
    return normalizeInstagramUrl(uClean);
  }
  if (uLow.includes("youtube.com") || uLow.includes("youtu.be")) {
    return normalizeYouTubeUrl(uClean);
  }
  return uClean;
}

export function detectPlatformInfo(url: string): PlatformInfo {
  const u = (url || "").toLowerCase();
  if (u.includes("instagram.com") || u.includes("instagr.am")) {
    const sub = u.includes("/reel/") || u.includes("/reels/") ? "ريلز" : u.includes("/stories/") ? "قصة" : "منشور";
    return { name: "انستغرام", badge: `انستغرام • ${sub}`, key: "instagram" };
  }
  if (isTikTokUrl(u)) return { name: "تيك توك", badge: "تيك توك", key: "tiktok" };
  if (u.includes("youtube.com") || u.includes("youtu.be")) {
    const sub = u.includes("/shorts/") ? "Shorts" : "فيديو";
    return { name: "يوتيوب", badge: `يوتيوب • ${sub}`, key: "youtube" };
  }
  if (u.includes("twitter.com") || u.includes("x.com")) return { name: "منصة X", badge: "منصة X", key: "twitter" };
  if (u.includes("facebook.com") || u.includes("fb.watch") || u.includes("fb.com")) {
    return { name: "فيسبوك", badge: "فيسبوك", key: "facebook" };
  }
  if (u.includes("snapchat.com")) return { name: "سناب شات", badge: "سناب شات", key: "snapchat" };
  if (u.includes("pinterest.") || u.includes("pin.it")) return { name: "بنترست", badge: "بنترست", key: "pinterest" };
  if (u.includes("soundcloud.com")) return { name: "ساوند كلاود", badge: "ساوند كلاود", key: "soundcloud" };
  if (u.includes("threads.net") || u.includes("threads.com")) return { name: "ثريدز", badge: "ثريدز", key: "threads" };
  if (u.includes("t.me/") || u.includes("telegram.me/")) return { name: "تيليجرام", badge: "تيليجرام", key: "telegram" };
  if (u.includes("reddit.com") || u.includes("redd.it")) return { name: "ريديت", badge: "ريديت", key: "reddit" };
  if (u.includes("kwai.com") || u.includes("likee.")) return { name: "كواي / لايكي", badge: "كواي / لايكي", key: "kwai" };
  if (u.includes("google.") || u.includes("goo.gl") || u.includes("share.google")) {
    return { name: "جوجل", badge: "جوجل", key: "google" };
  }
  return { name: "رابط ويب", badge: "رابط ويب", key: "web" };
}

export async function analyzeAndResolveUrl(url: string): Promise<[string, string | null]> {
  let currentUrl = (url || "").trim();
  const uLow = currentUrl.toLowerCase();

  if (uLow.includes("instagram.com") || uLow.includes("instagr.am")) {
    return [await normalizeInstagramUrl(currentUrl), null];
  }
  if (uLow.includes("youtube.com") || uLow.includes("youtu.be")) {
    return [normalizeYouTubeUrl(currentUrl), null];
  }
  if (isTikTokUrl(uLow)) {
    return [currentUrl, null];
  }

  try {
    const parsedInit = new URL(currentUrl);
    const hostL = parsedInit.hostname.toLowerCase();
    if (
      ["goo.gl", "share.google", "bit.ly", "tinyurl.com", "pin.it", "fb.watch"].some((d) => hostL.includes(d)) ||
      parsedInit.pathname.toLowerCase().includes("/share/")
    ) {
      const r = await fetchWithTimeout(currentUrl, {
        headers: { "User-Agent": DEFAULT_UA },
        redirect: "follow",
        timeoutMs: 8000,
      });
      if (r.url) {
        currentUrl = r.url;
        const cLow = currentUrl.toLowerCase();
        if (cLow.includes("instagram.com")) return [await normalizeInstagramUrl(currentUrl), null];
        if (cLow.includes("youtube.com") || cLow.includes("youtu.be")) return [normalizeYouTubeUrl(currentUrl), null];
      }
    }
  } catch {
    // ignore
  }

  try {
    const parsed = new URL(currentUrl);
    if (parsed.hostname.toLowerCase().includes("google.")) {
      const imgUrl = parsed.searchParams.get("imgurl");
      if (imgUrl) return [imgUrl, null];
      for (const param of ["url", "q"]) {
        const val = (parsed.searchParams.get(param) || "").trim();
        if (/^https?:\/\//i.test(val)) {
          if (val.toLowerCase().includes("youtube.com") || val.toLowerCase().includes("youtu.be")) {
            return [normalizeYouTubeUrl(val), null];
          }
          return [val, null];
        }
      }
      const q = parsed.searchParams.get("q");
      if (q) return [currentUrl, q.trim()];
    }
  } catch {
    // ignore
  }

  return [currentUrl, null];
}

async function collectYdlFiles(
  workDir: string,
  isYt: boolean,
  mode: "video" | "voice" | "mp3",
  videoCandidates: string[],
  audioCandidates: string[],
  imageCandidates: string[]
): Promise<string[]> {
  const newYdlImages: string[] = [];
  for (const fname of fs.readdirSync(workDir).sort()) {
    if (!fname.startsWith("media_")) continue;
    if (fname.endsWith(".part") || fname.endsWith(".ytdl") || fname.endsWith(".temp")) continue;
    const fpath = path.join(workDir, fname);
    if (!fs.statSync(fpath).isFile() || fs.statSync(fpath).size < 4096) continue;

    const ext = path.extname(fpath).toLowerCase();
    if ([".jpg", ".jpeg", ".png", ".webp"].includes(ext)) {
      if (!isYt && !imageCandidates.includes(fpath)) newYdlImages.push(fpath);
    } else if ([".mp3", ".m4a", ".ogg", ".opus", ".wav", ".aac", ".flac"].includes(ext)) {
      if (!audioCandidates.includes(fpath)) audioCandidates.push(fpath);
    } else if ([".mp4", ".mkv", ".webm", ".mov", ".avi", ".ts", ".m4v", ".3gp", ".flv"].includes(ext)) {
      if (!videoCandidates.includes(fpath) && !audioCandidates.includes(fpath)) {
        if ((await probeHasVideoStream(fpath)) || (isYt && mode === "video" && fs.statSync(fpath).size >= 24576)) {
          videoCandidates.push(fpath);
        } else {
          audioCandidates.push(fpath);
        }
      }
    }
  }
  return newYdlImages.length && !isYt
    ? validateAndFilterImages([...imageCandidates, ...newYdlImages])
    : imageCandidates;
}

export async function downloadMediaPipeline(
  urlOrQuery: string,
  mode: "video" | "voice" | "mp3",
  workDir: string,
  isSearch = false
): Promise<DownloadPipelineOutput> {
  const output: DownloadPipelineOutput = {
    status: false,
    title: "منشور محمل",
    description: "",
    author: "",
    video_path: null,
    extra_videos: [],
    voice_path: null,
    audio_path: null,
    images: [],
    error: null,
  };

  let cleanUrl = urlOrQuery;
  let googleSearchQuery: string | null = null;
  let searchMode = isSearch;

  if (searchMode) {
    googleSearchQuery = urlOrQuery;
    const topItems = await searchYouTubeTop5(urlOrQuery);
    if (topItems.length > 0) {
      cleanUrl = normalizeYouTubeUrl(topItems[0].url);
      output.title = topItems[0].title || output.title;
      output.author = topItems[0].channel || output.author;
      searchMode = false;
    } else {
      cleanUrl = `ytsearch1:${urlOrQuery}`;
    }
  } else {
    [cleanUrl, googleSearchQuery] = await analyzeAndResolveUrl(urlOrQuery);
  }

  const cLow = cleanUrl.toLowerCase();
  const isIg = !searchMode && (cLow.includes("instagram.com") || cLow.includes("instagr.am"));
  const isYt = searchMode || cLow.includes("youtube.com") || cLow.includes("youtu.be");
  const isTt = !searchMode && (isTikTokUrl(cleanUrl) || isTikTokUrl(urlOrQuery));

  if (isYt && !searchMode) cleanUrl = normalizeYouTubeUrl(cleanUrl);

  // أ) تيليجرام
  if (!searchMode && (cLow.includes("t.me/") || cLow.includes("telegram.me/"))) {
    const tgRes = await downloadTelegramPublicPost(cleanUrl, workDir);
    if (tgRes.unsupported_reason) {
      output.error = tgRes.unsupported_reason;
      return output;
    }
    if (tgRes.videos.length || tgRes.audios.length || tgRes.images.length) {
      output.title = tgRes.title;
      output.description = tgRes.description || tgRes.title;
      if (mode === "voice" && (tgRes.audios.length || tgRes.videos.length)) {
        const src = tgRes.audios[0] || tgRes.videos[0];
        output.voice_path = await convertToVoiceOgg(src, path.join(workDir, "tg_out.ogg"));
        output.status = true;
        return output;
      }
      if (tgRes.videos.length) {
        output.video_path = await prepareHighQualityVideo(tgRes.videos[0], workDir, "tg");
      }
      output.images = tgRes.images;
      if (tgRes.audios.length) {
        output.voice_path = await convertToVoiceOgg(tgRes.audios[0], path.join(workDir, "tg_v.ogg"));
      }
      output.status = true;
      return output;
    }
  }

  const videoCandidates: string[] = [];
  const audioCandidates: string[] = [];
  let imageCandidates: string[] = [];

  // ب) تيك توك (المحرك المتوازي المصلّح + yt-dlp الحديث مدمج داخل الموجة 2)
  if (isTt) {
    const ttMedia = await downloadTikTokFast(cleanUrl, workDir, mode, urlOrQuery);
    if (ttMedia.images.length || ttMedia.videos.length || ttMedia.audios.length) {
      output.title = ttMedia.title;
      output.description = ttMedia.description || ttMedia.title;
      output.author = ttMedia.author || "";
      videoCandidates.push(...ttMedia.videos);
      audioCandidates.push(...ttMedia.audios);
      imageCandidates.push(...ttMedia.images);
    }
  }

  // ج) انستغرام (الموجات المتوازية)
  if (isIg) {
    const igMedia = await downloadInstagramFast(cleanUrl, workDir);
    if (igMedia.title) output.title = igMedia.title;
    if (igMedia.description) output.description = igMedia.description;
    if (igMedia.author) output.author = igMedia.author;
    videoCandidates.push(...igMedia.videos);
    imageCandidates.push(...igMedia.images);
  }

  // د) yt-dlp المستقل المحدّث تلقائياً (ليوتيوب وبقية المنصات أو عند عدم نجاح الطبقات السريعة)
  const needYtdlp =
    isYt ||
    (!isTt && !videoCandidates.length && !imageCandidates.length) ||
    (!isTt && !videoCandidates.length && !audioCandidates.length && imageCandidates.length <= 1);

  if (needYtdlp) {
    const targetForYdl =
      googleSearchQuery && searchMode ? `ytsearch1:${googleSearchQuery}` : cleanUrl;

    let ytProfiles: Array<{ extArgs?: string; simple?: boolean }> = [{}];
    if (isYt) {
      const vidIdTmp = !searchMode ? extractYouTubeVideoId(cleanUrl) : null;
      const { visitorData } = vidIdTmp ? await fetchYouTubeVisitorData(vidIdTmp) : { visitorData: "" };
      const vdSuffix = visitorData ? `;visitor_data=${visitorData}` : "";
      ytProfiles = [
        { extArgs: `youtube:player_client=tv_simply,web_embedded,ios,android_vr;player_skip=webpage${vdSuffix}` },
        { extArgs: `youtube:player_client=mweb,web_safari,mediaconnect;player_skip=webpage${vdSuffix}` },
        { extArgs: "youtube:player_client=default,-android_sdkless", simple: true },
      ];
    }

    for (let idx = 0; idx < ytProfiles.length; idx++) {
      if ((mode === "video" && videoCandidates.length) || (mode !== "video" && (audioCandidates.length || videoCandidates.length))) {
        break;
      }
      const prof = ytProfiles[idx];
      const yRes = await runYtDlpDownload({
        targetUrl: targetForYdl,
        workDir,
        mode,
        platform: isYt ? "youtube" : isIg ? "instagram" : "generic",
        extractorArgs: prof.extArgs,
        fallbackSimpleFormat: prof.simple,
      });

      if (yRes.title || yRes.description || yRes.author) {
        if (isIg) {
          const [st, fd] = cleanInstagramCaptionAndTitle(
            yRes.description || yRes.title,
            extractInstagramShortcode(cleanUrl) || ""
          );
          if (st && (!output.title || output.title.startsWith("منشور انستغرام"))) output.title = st;
          if (fd && !output.description) output.description = fd;
          if (yRes.author && !output.author) output.author = cleanInstagramAuthor(yRes.author);
        } else {
          if (yRes.title) output.title = yRes.title.slice(0, 140);
          else if (yRes.description && output.title === "منشور محمل") {
            output.title = yRes.description.split("\n")[0].slice(0, 140);
          }
          if (yRes.description) output.description = yRes.description.slice(0, 2500);
          if (yRes.author) output.author = yRes.author.slice(0, 60);
        }
      }

      imageCandidates = await collectYdlFiles(
        workDir,
        isYt,
        mode,
        videoCandidates,
        audioCandidates,
        imageCandidates
      );

      const errL = (yRes.error || "").toLowerCase();
      if (isYt && idx >= 1 && (errL.includes("not a bot") || errL.includes("sign in") || errL.includes("login_required"))) {
        break;
      }
    }

    if (isYt && !videoCandidates.length && !audioCandidates.length) {
      const extFb = await downloadYouTubeMultiApiFallback(cleanUrl, workDir, mode, output);
      if (extFb && fs.existsSync(extFb)) {
        if (mode !== "video" || /\.(mp3|m4a|ogg|opus|wav)$/i.test(extFb)) {
          audioCandidates.push(extFb);
        } else {
          videoCandidates.push(extFb);
        }
      }
    }

    if (isYt && !output.description) {
      const vidIdCheck = extractYouTubeVideoId(cleanUrl);
      if (vidIdCheck) {
        const ytM = await fetchYouTubeMetadataAndDescription(vidIdCheck);
        if (ytM.description) output.description = ytM.description;
        if (ytM.title && output.title === "منشور محمل") output.title = ytM.title;
        if (ytM.author && !output.author) output.author = ytM.author;
      }
    }
  }

  // هـ) محرك الويب للمواقع العامة
  if (!isIg && !isYt && !isTt && !videoCandidates.length && !audioCandidates.length && !imageCandidates.length && !searchMode) {
    const webMedia = await scrapeGoogleAndWebpageMedia(cleanUrl, workDir, googleSearchQuery);
    if (webMedia.title && output.title === "منشور محمل") output.title = webMedia.title;
    if (webMedia.description && !output.description) output.description = webMedia.description;
    videoCandidates.push(...webMedia.videos);
    audioCandidates.push(...webMedia.audios);
    imageCandidates.push(...webMedia.images);
  }

  if (!output.description && output.title && output.title !== "منشور محمل") {
    output.description = output.title;
  }

  if (isYt) {
    imageCandidates = [];
  } else if (imageCandidates.length) {
    imageCandidates = validateAndFilterImages(imageCandidates);
  }

  // و) تجهيز المخرجات بأعلى جودة
  if (mode === "voice") {
    const src = audioCandidates[0] || videoCandidates[0];
    if (src) {
      const oggPath = path.join(workDir, "voice_output.ogg");
      output.voice_path = await convertToVoiceOgg(src, oggPath);
      if (path.resolve(src) !== path.resolve(output.voice_path)) cleanupFiles(src);
      output.status = true;
      return output;
    }
    if (imageCandidates.length && !isYt) {
      output.images = imageCandidates;
      output.status = true;
      return output;
    }
  }

  if (mode === "mp3") {
    const src = audioCandidates[0] || videoCandidates[0];
    if (src) {
      const mp3Path = path.join(workDir, "audio_output.mp3");
      output.audio_path = await convertToMp3(src, mp3Path);
      if (path.resolve(src) !== path.resolve(output.audio_path)) cleanupFiles(src);
      output.status = true;
      return output;
    }
  }

  if (!isYt && imageCandidates.length && !videoCandidates.length) {
    output.images = imageCandidates;
    if (audioCandidates[0]) {
      const oggPath = path.join(workDir, "song_voice.ogg");
      output.voice_path = await convertToVoiceOgg(audioCandidates[0], oggPath);
      if (path.resolve(audioCandidates[0]) !== path.resolve(output.voice_path)) cleanupFiles(audioCandidates[0]);
    }
    output.status = Boolean(output.images.length || output.voice_path);
    return output;
  }

  if (videoCandidates.length) {
    output.video_path = await prepareHighQualityVideo(videoCandidates[0], workDir, "main");
    if (videoCandidates.length > 1) {
      output.extra_videos = [];
      for (let idx = 0; idx < Math.min(videoCandidates.length - 1, 4); idx++) {
        output.extra_videos.push(await prepareHighQualityVideo(videoCandidates[idx + 1], workDir, `extra_${idx}`));
      }
    }
    if (!isYt && imageCandidates.length > 1) {
      output.images = imageCandidates.slice(0, 6);
    }
    output.status = true;
    return output;
  }

  if (audioCandidates.length) {
    const oggPath = path.join(workDir, "auto_voice.ogg");
    output.voice_path = await convertToVoiceOgg(audioCandidates[0], oggPath);
    output.status = true;
    return output;
  }

  if (isYt) {
    output.error = "تعذر تنزيل هذا الفيديو حالياً. جرب إرسال الرابط مرة أخرى أو ارفع ملف cookies.txt من (/admin -> كوكيز).";
  } else if (isIg) {
    output.error = "تعذر استخراج هذا المنشور من انستغرام. إذا كان الحساب خاصاً، يمكن للمشرف رفع ملف كوكيز من (/admin -> كوكيز).";
  } else if (isTt) {
    output.error = "تعذر تنزيل هذا المنشور من تيك توك حالياً. تأكد من أن الفيديو عام وجرب مرة أخرى.";
  } else {
    output.error = "تعذر استخراج وسائط من هذا الرابط. تأكد من أن المنشور عام.";
  }

  return output;
}
