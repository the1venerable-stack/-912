/**
 * محرك يوتيوب المطور بالتوازي:
 * - البحث الهجين السريع (أفضل 5 نتائج: YouTube HTML -> Piped/Invidious المتوازي -> yt-dlp).
 * - تنزيل بأعلى دقة (1080p H.264/AAC) مع استخراج الوصف الكامل.
 * - سباق متوازي بين طبقات الإنقاذ (Innertube Direct + SaveTube + Invidious + Piped + Cobalt)
 *   لتفادي الانتظار التسلسلي البطيء.
 */

import { execFile } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { promisify } from "node:util";
import {
  checkFfmpegInstalled,
  cleanupFiles,
  downloadBinaryFile,
} from "../mediaUtils.js";
import { DEFAULT_UA, fetchWithTimeout, logger, raceFirstSuccess } from "../network.js";
import { runYtDlpFlatSearch } from "./ytdlp.js";

const execFileAsync = promisify(execFile);

export const YT_VIDEO_ID_RE =
  /(?:(?:www\.|m\.|music\.)?youtube(?:-nocookie)?\.com\/(?:watch\?.*?v=|shorts\/|embed\/|live\/|v\/|clip\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/i;

const PIPED_API_INSTANCES = [
  "https://pipedapi.kavin.rocks",
  "https://api.piped.private.coffee",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.drgns.space",
];

const INVIDIOUS_API_INSTANCES = [
  "https://inv.nadeko.net",
  "https://invidious.nerdvpn.de",
  "https://invidious.jing.rocks",
  "https://yewtu.be",
];

const SAVETUBE_CDN_HOSTS = [
  "https://cdn51.savetube.su",
  "https://cdn52.savetube.su",
  "https://cdn59.savetube.su",
];

const COBALT_API_INSTANCES = [
  "https://cobalt-backend.canine.tools",
  "https://co.eepy.today",
];

export interface YouTubeSearchItem {
  id: string;
  url: string;
  title: string;
  channel: string;
  duration: string;
}

export interface YouTubeMeta {
  title: string;
  description: string;
  author: string;
}

export function formatDurationHuman(seconds: number): string {
  if (!seconds || !Number.isFinite(seconds) || seconds <= 0) return "";
  const sec = Math.floor(seconds);
  const hrs = Math.floor(sec / 3600);
  const mins = Math.floor((sec % 3600) / 60);
  const rem = sec % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return hrs > 0 ? `${hrs}:${pad(mins)}:${pad(rem)}` : `${pad(mins)}:${pad(rem)}`;
}

export function extractYouTubeVideoId(url: string): string | null {
  if (!url) return null;
  const m = YT_VIDEO_ID_RE.exec(String(url));
  if (m) return m[1];
  try {
    const parsed = new URL(String(url));
    const v = parsed.searchParams.get("v");
    if (v && v.length === 11) return v;
    if (parsed.hostname.toLowerCase().includes("youtube") || parsed.hostname.toLowerCase().includes("youtu.be")) {
      const parts = parsed.pathname.split("/").filter(Boolean).reverse();
      for (const part of parts) {
        if (/^[A-Za-z0-9_-]{11}$/.test(part) && !["watch", "shorts", "embed", "live"].includes(part.toLowerCase())) {
          return part;
        }
      }
    }
  } catch {
    // ignore
  }
  return null;
}

export function normalizeYouTubeUrl(url: string): string {
  if (!url) return url;
  const vidId = extractYouTubeVideoId(url);
  return vidId ? `https://www.youtube.com/watch?v=${vidId}` : url.trim();
}

export function extractYouTubeSearchQuery(text: string): [string | null, boolean] {
  if (!text) return [null, false];
  const t = text.trim();
  const m = /^(?:ب|بـ|بحث|\/search|\/yt)\s+([\s\S]+)$/i.exec(t);
  if (m) {
    const q = m[1].trim();
    return [q.length >= 1 ? q : null, true];
  }
  return [t, false];
}

export async function fetchYouTubeMetadataAndDescription(vidId: string): Promise<YouTubeMeta> {
  const meta: YouTubeMeta = { title: "", description: "", author: "" };
  if (!vidId) return meta;
  const cleanUrl = `https://www.youtube.com/watch?v=${vidId}`;

  try {
    const r = await fetchWithTimeout(`${cleanUrl}&hl=ar`, {
      headers: { "User-Agent": DEFAULT_UA, "Accept-Language": "ar,en-US;q=0.9,en;q=0.8" },
      timeoutMs: 6500,
    });
    if (r.ok) {
      const htmlText = await r.text();
      const mPr =
        /var\s+ytInitialPlayerResponse\s*=\s*(\{[\s\S]*?\});/.exec(htmlText) ||
        /ytInitialPlayerResponse\s*=\s*(\{[\s\S]*?\});/.exec(htmlText);
      if (mPr) {
        const prData = JSON.parse(mPr[1]);
        const vd = prData?.videoDetails || {};
        if (vd.title) meta.title = String(vd.title).trim().slice(0, 140);
        if (vd.shortDescription) meta.description = String(vd.shortDescription).trim().slice(0, 2500);
        if (vd.author) meta.author = String(vd.author).trim().slice(0, 60);
        if (meta.title && meta.description) return meta;
      }
    }
  } catch {
    // ignore
  }

  if (!meta.title) {
    try {
      const oe = await fetchWithTimeout(
        `https://www.youtube.com/oembed?url=${encodeURIComponent(cleanUrl)}&format=json`,
        { timeoutMs: 4500 }
      );
      if (oe.ok) {
        const oj = (await oe.json()) as Record<string, unknown>;
        if (oj.title) meta.title = String(oj.title).trim().slice(0, 140);
        if (oj.author_name && !meta.author) meta.author = String(oj.author_name).trim().slice(0, 60);
      }
    } catch {
      // ignore
    }
  }

  return meta;
}

async function searchYouTubeHtmlScrape(query: string, maxResults = 5): Promise<YouTubeSearchItem[]> {
  const results: YouTubeSearchItem[] = [];
  try {
    const r = await fetchWithTimeout(
      `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=ar`,
      {
        headers: { "User-Agent": DEFAULT_UA, "Accept-Language": "ar,en-US;q=0.9,en;q=0.8" },
        timeoutMs: 7500,
      }
    );
    if (!r.ok) return results;
    const htmlText = await r.text();
    const m =
      /var\s+ytInitialData\s*=\s*(\{[\s\S]*?\});<\/script>/.exec(htmlText) ||
      /ytInitialData\s*=\s*(\{[\s\S]*?\});/.exec(htmlText);
    if (!m) return results;
    const data = JSON.parse(m[1]);
    const contents =
      data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];
    for (const sec of contents) {
      const items = sec?.itemSectionRenderer?.contents || [];
      for (const it of items) {
        const vr = it?.videoRenderer;
        if (!vr?.videoId) continue;
        const vidId = String(vr.videoId);
        const title = String(vr.title?.runs?.[0]?.text || "فيديو يوتيوب").slice(0, 95);
        const channel = String(
          vr.ownerText?.runs?.[0]?.text || vr.longBylineText?.runs?.[0]?.text || "YouTube"
        ).slice(0, 40);
        const durTxt = String(vr.lengthText?.simpleText || "--:--");
        results.push({
          id: vidId,
          url: `https://www.youtube.com/watch?v=${vidId}`,
          title,
          channel,
          duration: durTxt,
        });
        if (results.length >= maxResults) return results;
      }
    }
  } catch (err) {
    logger.debug(`YouTube HTML search note: ${String(err)}`);
  }
  return results;
}

async function searchYouTubePipedInvidiousParallel(query: string, maxResults = 5): Promise<YouTubeSearchItem[]> {
  const tasks = [
    ...PIPED_API_INSTANCES.map((host) => async (sig: AbortSignal) => {
      const r = await fetchWithTimeout(
        `${host}/search?q=${encodeURIComponent(query)}&filter=videos`,
        { timeoutMs: 5500, externalSignal: sig }
      );
      if (!r.ok) return null;
      const j = (await r.json()) as { items?: Array<Record<string, unknown>> };
      const out: YouTubeSearchItem[] = [];
      for (const it of j.items || []) {
        const vidId = extractYouTubeVideoId(`https://www.youtube.com${String(it.url || "")}`);
        if (!vidId) continue;
        out.push({
          id: vidId,
          url: `https://www.youtube.com/watch?v=${vidId}`,
          title: String(it.title || "فيديو يوتيوب").slice(0, 95),
          channel: String(it.uploaderName || "YouTube").slice(0, 40),
          duration: formatDurationHuman(Number(it.duration || 0)) || "--:--",
        });
        if (out.length >= maxResults) break;
      }
      return out.length ? out : null;
    }),
    ...INVIDIOUS_API_INSTANCES.map((host) => async (sig: AbortSignal) => {
      const r = await fetchWithTimeout(
        `${host}/api/v1/search?q=${encodeURIComponent(query)}&type=video`,
        { timeoutMs: 5500, externalSignal: sig }
      );
      if (!r.ok) return null;
      const arr = (await r.json()) as Array<Record<string, unknown>>;
      const out: YouTubeSearchItem[] = [];
      for (const it of arr || []) {
        if (!it?.videoId) continue;
        const vidId = String(it.videoId);
        out.push({
          id: vidId,
          url: `https://www.youtube.com/watch?v=${vidId}`,
          title: String(it.title || "فيديو يوتيوب").slice(0, 95),
          channel: String(it.author || "YouTube").slice(0, 40),
          duration: formatDurationHuman(Number(it.lengthSeconds || 0)) || "--:--",
        });
        if (out.length >= maxResults) break;
      }
      return out.length ? out : null;
    }),
  ];

  return (await raceFirstSuccess(tasks, 7000)) || [];
}

export async function searchYouTubeTop5(query: string): Promise<YouTubeSearchItem[]> {
  const cleanQ = (query || "").trim();
  if (!cleanQ) return [];

  const htmlRes = await searchYouTubeHtmlScrape(cleanQ, 5);
  if (htmlRes.length > 0) return htmlRes.slice(0, 5);

  const apiRes = await searchYouTubePipedInvidiousParallel(cleanQ, 5);
  if (apiRes.length > 0) return apiRes.slice(0, 5);

  const flat = await runYtDlpFlatSearch(cleanQ, 5);
  return flat.map((it) => ({
    id: it.id,
    url: normalizeYouTubeUrl(it.url),
    title: it.title,
    channel: it.channel,
    duration: formatDurationHuman(it.durationSec) || "--:--",
  }));
}

export async function fetchYouTubeVisitorData(vidId: string): Promise<{ visitorData: string; stsVal: number | null }> {
  let visitorData = "";
  let stsVal: number | null = null;
  try {
    const r = await fetchWithTimeout(`https://www.youtube.com/embed/${vidId}?hl=en`, {
      headers: { "User-Agent": DEFAULT_UA, Referer: "https://www.youtube.com/" },
      timeoutMs: 4500,
    });
    if (r.ok) {
      const txt = await r.text();
      const mVd = /"VISITOR_DATA"\s*:\s*"([^"]+)"/.exec(txt);
      if (mVd) visitorData = mVd[1];
      const mSts = /"sts"\s*:\s*(\d+)/.exec(txt);
      if (mSts) stsVal = Number.parseInt(mSts[1], 10);
    }
  } catch {
    // ignore
  }
  return { visitorData, stsVal };
}

async function downloadYouTubeInnertubeDirect(
  vidId: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  resultMeta: Partial<YouTubeMeta>,
  signal: AbortSignal
): Promise<string | null> {
  const { visitorData, stsVal } = await fetchYouTubeVisitorData(vidId);
  const hasFfmpeg = await checkFfmpegInstalled();

  const clients = [
    {
      name: "IOS",
      ua: "com.google.ios.youtube/20.03.02 (iPhone16,2; U; CPU iOS 18_2_1 like Mac OS X;)",
      clientId: "5",
      context: {
        clientName: "IOS",
        clientVersion: "20.03.02",
        deviceMake: "Apple",
        deviceModel: "iPhone16,2",
        osName: "iPhone",
        osVersion: "18.2.1.22C161",
        hl: "en",
        gl: "US",
      },
    },
    {
      name: "ANDROID_VR",
      ua: "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
      clientId: "28",
      context: {
        clientName: "ANDROID_VR",
        clientVersion: "1.60.19",
        androidSdkVersion: 32,
        osName: "Android",
        osVersion: "12L",
        deviceMake: "Oculus",
        deviceModel: "Quest 3",
        hl: "en",
        gl: "US",
      },
    },
    {
      name: "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
      ua: "Mozilla/5.0 (PlayStation; PlayStation 5/6.02) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Safari/605.1.15",
      clientId: "85",
      context: { clientName: "TVHTML5_SIMPLY_EMBEDDED_PLAYER", clientVersion: "2.0", hl: "en", gl: "US" },
      thirdParty: { embedUrl: `https://www.youtube.com/embed/${vidId}` },
    },
  ];

  for (const spec of clients) {
    if (signal.aborted) return null;
    try {
      const ctx: Record<string, unknown> = { ...spec.context };
      if (visitorData) ctx.visitorData = visitorData;
      const fullCtx: Record<string, unknown> = { client: ctx };
      if (spec.thirdParty) fullCtx.thirdParty = spec.thirdParty;

      const payload: Record<string, unknown> = {
        videoId: vidId,
        context: fullCtx,
        contentCheckOk: true,
        racyCheckOk: true,
      };
      if (stsVal) {
        payload.playbackContext = { contentPlaybackContext: { signatureTimestamp: stsVal } };
      }

      const reqHeaders: Record<string, string> = {
        "User-Agent": spec.ua,
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-YouTube-Client-Name": spec.clientId,
        "X-YouTube-Client-Version": String(spec.context.clientVersion),
        Origin: "https://www.youtube.com",
      };
      if (visitorData) reqHeaders["X-Goog-Visitor-Id"] = visitorData;

      const resp = await fetchWithTimeout("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
        method: "POST",
        headers: reqHeaders,
        body: JSON.stringify(payload),
        timeoutMs: 9000,
        externalSignal: signal,
      });
      if (!resp.ok) continue;
      const pdata = (await resp.json()) as Record<string, unknown>;
      const vd = (pdata.videoDetails || {}) as Record<string, unknown>;
      if (vd.title && (!resultMeta.title || resultMeta.title === "منشور محمل")) {
        resultMeta.title = String(vd.title).slice(0, 140);
      }
      if (vd.shortDescription && !resultMeta.description) {
        resultMeta.description = String(vd.shortDescription).slice(0, 2500);
      }
      if (vd.author && !resultMeta.author) {
        resultMeta.author = String(vd.author).slice(0, 50);
      }

      const sData = (pdata.streamingData || {}) as Record<string, unknown>;
      const muxed = ((sData.formats || []) as Array<Record<string, unknown>>).filter((f) => f.url);
      const adaptive = ((sData.adaptiveFormats || []) as Array<Record<string, unknown>>).filter((f) => f.url);
      const dlHeaders = { "User-Agent": spec.ua, Accept: "*/*" };

      if (mode === "voice" || mode === "mp3") {
        const audios = adaptive
          .filter((f) => String(f.mimeType || "").toLowerCase().includes("audio"))
          .sort((a, b) => Number(b.bitrate || 0) - Number(a.bitrate || 0));
        for (const ast of audios.slice(0, 2)) {
          const ext = String(ast.mimeType || "").includes("mp4") ? ".m4a" : ".webm";
          const outAud = path.join(workDir, `yt_inner_${spec.name}${ext}`);
          if (
            await downloadBinaryFile(String(ast.url), outAud, {
              headers: dlHeaders,
              expectedType: "audio",
              minSize: 8192,
              signal,
            })
          ) {
            return outAud;
          }
        }
        continue;
      }

      if (hasFfmpeg && adaptive.length > 0) {
        const vidStreams = adaptive
          .filter((f) => String(f.mimeType || "").toLowerCase().includes("video/mp4") && Number(f.height || 0) <= 1080)
          .sort((a, b) => {
            const aAvc = String(a.mimeType || "").includes("avc1") ? 1 : 0;
            const bAvc = String(b.mimeType || "").includes("avc1") ? 1 : 0;
            return Number(b.height || 0) - Number(a.height || 0) || bAvc - aAvc || Number(b.bitrate || 0) - Number(a.bitrate || 0);
          });
        const audStreams = adaptive
          .filter((f) => String(f.mimeType || "").toLowerCase().includes("audio/mp4"))
          .sort((a, b) => Number(b.bitrate || 0) - Number(a.bitrate || 0));

        if (vidStreams[0] && audStreams[0]) {
          const vTmp = path.join(workDir, `inner_v_${spec.name}.mp4`);
          const aTmp = path.join(workDir, `inner_a_${spec.name}.m4a`);
          const merged = path.join(workDir, `inner_merged_${spec.name}.mp4`);

          // تنزيل الفيديو والصوت بالتوازي في وقت واحد!
          const [vOk, aOk] = await Promise.all([
            downloadBinaryFile(String(vidStreams[0].url), vTmp, {
              headers: dlHeaders,
              expectedType: "video",
              minSize: 24576,
              signal,
            }),
            downloadBinaryFile(String(audStreams[0].url), aTmp, {
              headers: dlHeaders,
              expectedType: "audio",
              minSize: 8192,
              signal,
            }),
          ]);

          if (vOk && aOk) {
            try {
              await execFileAsync(
                "ffmpeg",
                ["-y", "-i", vTmp, "-i", aTmp, "-c:v", "copy", "-c:a", "copy", "-movflags", "+faststart", merged],
                { timeout: 60000 }
              );
              cleanupFiles(vTmp, aTmp);
              if (fs.existsSync(merged) && fs.statSync(merged).size > 24576) return merged;
            } catch {
              cleanupFiles(vTmp, aTmp);
            }
          } else {
            cleanupFiles(vTmp, aTmp);
          }
        }
      }

      if (muxed.length > 0) {
        muxed.sort((a, b) => Number(b.height || 0) - Number(a.height || 0));
        const outV = path.join(workDir, `yt_inner_mux_${spec.name}.mp4`);
        if (
          await downloadBinaryFile(String(muxed[0].url), outV, {
            headers: dlHeaders,
            expectedType: "video",
            minSize: 24576,
            signal,
          })
        ) {
          return outV;
        }
      }
    } catch {
      continue;
    }
  }
  return null;
}

async function downloadYouTubeCobaltParallel(
  cleanUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  signal: AbortSignal
): Promise<string | null> {
  return raceFirstSuccess(
    COBALT_API_INSTANCES.map((cEp, idx) => async (sig: AbortSignal) => {
      if (signal.aborted) return null;
      const headers = {
        Accept: "application/json",
        "Content-Type": "application/json",
        "User-Agent": DEFAULT_UA,
        Origin: cEp,
        Referer: `${cEp}/`,
      };
      const cr = await fetchWithTimeout(`${cEp.replace(/\/$/, "")}/`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          url: cleanUrl,
          videoQuality: "1080",
          downloadMode: mode === "voice" || mode === "mp3" ? "audio" : "auto",
          youtubeVideoCodec: "h264",
        }),
        timeoutMs: 9000,
        externalSignal: sig,
      });
      if (!cr.ok) return null;
      const j = (await cr.json()) as Record<string, unknown>;
      if (typeof j.url !== "string") return null;
      const ext = mode === "voice" || mode === "mp3" ? ".mp3" : ".mp4";
      const outP = path.join(workDir, `yt_cobalt_${idx}${ext}`);
      const ok = await downloadBinaryFile(j.url, outP, {
        expectedType: ext === ".mp3" ? "audio" : "video",
        minSize: 8192,
        signal: sig,
      });
      return ok ? outP : null;
    }),
    12000
  );
}

async function downloadYouTubeSaveTubeParallel(
  cleanUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  signal: AbortSignal
): Promise<string | null> {
  const headers = {
    "User-Agent": DEFAULT_UA,
    Accept: "application/json, text/plain, */*",
    "Content-Type": "application/json",
    Origin: "https://ytshorts.savetube.me",
    Referer: "https://ytshorts.savetube.me/",
  };

  return raceFirstSuccess(
    SAVETUBE_CDN_HOSTS.map((cdnHost, idx) => async (sig: AbortSignal) => {
      if (signal.aborted) return null;
      const rInfo = await fetchWithTimeout(`${cdnHost}/info`, {
        method: "POST",
        headers,
        body: JSON.stringify({ url: cleanUrl }),
        timeoutMs: 8000,
        externalSignal: sig,
      });
      if (!rInfo.ok) return null;
      const data = ((await rInfo.json()) as { data?: Record<string, unknown> }).data;
      if (!data?.key) return null;

      const dlType = mode === "voice" || mode === "mp3" ? "audio" : "video";
      const qVal = dlType === "audio" ? "128" : "1080";
      const rDl = await fetchWithTimeout(`${cdnHost}/download`, {
        method: "POST",
        headers,
        body: JSON.stringify({ downloadType: dlType, quality: qVal, key: data.key }),
        timeoutMs: 10000,
        externalSignal: sig,
      });
      if (!rDl.ok) return null;
      const dlUrl = ((await rDl.json()) as { data?: { downloadUrl?: string } }).data?.downloadUrl;
      if (!dlUrl) return null;
      const ext = dlType === "audio" ? ".mp3" : ".mp4";
      const outP = path.join(workDir, `yt_st_${idx}${ext}`);
      const ok = await downloadBinaryFile(dlUrl, outP, {
        headers,
        expectedType: dlType === "audio" ? "audio" : "video",
        minSize: 8192,
        signal: sig,
      });
      return ok ? outP : null;
    }),
    15000
  );
}

/**
 * سباق متوازي بين طبقات إنقاذ يوتيوب (Innertube + Cobalt + SaveTube) لتوفير 60-90 ثانية مقارنة بالانتظار التسلسلي.
 */
export async function downloadYouTubeMultiApiFallback(
  ytUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3" = "video",
  resultMeta: Partial<YouTubeMeta> = {}
): Promise<string | null> {
  const vidId = extractYouTubeVideoId(ytUrl);
  if (!vidId) return null;
  const cleanUrl = `https://www.youtube.com/watch?v=${vidId}`;

  return raceFirstSuccess<string>(
    [
      (sig) => downloadYouTubeInnertubeDirect(vidId, workDir, mode, resultMeta, sig),
      (sig) => downloadYouTubeCobaltParallel(cleanUrl, workDir, mode, sig),
      (sig) => downloadYouTubeSaveTubeParallel(cleanUrl, workDir, mode, sig),
    ],
    22000
  );
}
