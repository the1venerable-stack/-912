/**
 * محرك انستغرام المطور بالتوازي (Parallel Multi-Layer Engine):
 * - نفس دقة التنظيف والاستخراج لأعلى جودة (HD) والألبومات المتعددة والوصف الكامل.
 * - تشغيل الطبقات بموجات متوازية بدلاً من الانتظار التسلسلي الطويل.
 * - تحميل صور الألبومات بالتوازي (mapConcurrent).
 */

import path from "node:path";
import * as cheerio from "cheerio";
import { downloadBinaryFile, probeHasVideoStream, validateAndFilterImages } from "../mediaUtils.js";
import {
  DEFAULT_UA,
  MOBILE_IOS_UA,
  SimpleCookieJar,
  fetchWithTimeout,
  logger,
  mapConcurrent,
  raceFirstSuccess,
} from "../network.js";

export const IG_SHORTCODE_RE =
  /(?:instagram\.com|instagr\.am)\/(?:[A-Za-z0-9_.-]+\/)?(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/i;

const IG_BAD_AUTHORS = new Set([
  "vxinstagram", "d.vxinstagram", "ddinstagram", "d.ddinstagram",
  "kkinstagram", "instafix", "fxstagram", "uuinstagram", "instagram", "insta", "meta",
  "login", "snapsave", "fastdl", "saveig", "cobalt", "igram",
  "unknown", "none", "null", "undefined", "error", "not found",
]);

const STATIC_UI_URL_PATTERNS = [
  "rsrc.php", "static.cdninstagram.com", "static.xx.fbcdn.net", "static.whatsapp.net",
  "gstatic.com", "google.com/images/branding", "/rsrc/", "/images/instagram/",
  "favicon", "apple-touch-icon", "branding", "logo", "placeholder", "blank.gif",
  "spacer.gif", "1x1", "pixel", "sprite", "default_profile",
  "44884218_345707102882519_2446069589734326272_n",
];

const AVATAR_URL_PATTERNS = [
  "t51.2885-19", "/s150x150/", "/s320x320/", "/p50x50/", "/p100x100/", "/s64x64/", "profile_pic",
];

const COBALT_INSTANCES = [
  "https://cobalt-backend.canine.tools",
  "https://co.eepy.today",
];

export interface InstagramDownloadResult {
  videos: string[];
  images: string[];
  title: string;
  description: string;
  author: string;
}

export function isValidMediaUrl(u: unknown, mediaType: "image" | "video" = "image"): boolean {
  if (!u || typeof u !== "string" || !/^https?:\/\//i.test(u)) return false;
  const ul = u.toLowerCase();
  if (STATIC_UI_URL_PATTERNS.some((bad) => ul.includes(bad))) return false;
  if (mediaType === "image") {
    if (AVATAR_URL_PATTERNS.some((av) => ul.includes(av))) return false;
    const basePath = ul.split("?")[0];
    if ([".svg", ".ico", ".mp4", ".webm", ".m4a", ".mp3", ".js", ".css"].some((ext) => basePath.endsWith(ext))) {
      return false;
    }
  }
  return true;
}

export function cleanInstagramAuthor(rawAuthor: unknown): string {
  if (!rawAuthor || typeof rawAuthor !== "string") return "";
  let a = rawAuthor.trim();
  const mHandle = /\(@([A-Za-z0-9_.-]+)\)/.exec(a);
  if (mHandle) {
    a = mHandle[1];
  } else {
    a = a.replace(/\s+on\s+instagram.*$/i, "").trim().replace(/^@+/, "").trim();
  }
  const aLow = a.toLowerCase();
  if (!aLow || IG_BAD_AUTHORS.has(aLow)) return "";
  if (
    ["vxinstagram", "ddinstagram", "kkinstagram", "instafix", "fxstagram", "uuinstagram", "login •", "instagram photos and videos"].some(
      (b) => aLow.includes(b)
    )
  ) {
    return "";
  }
  return a.slice(0, 45);
}

export function cleanInstagramCaptionAndTitle(
  rawText: unknown,
  shortcode = ""
): [string, string] {
  const fallback = shortcode ? `منشور انستغرام (${shortcode})` : "منشور انستغرام";
  if (!rawText || typeof rawText !== "string") return [fallback, ""];
  let t = rawText.trim();
  const mCap = /:\s*["“]([\s\S]+?)["”]\s*\.?\s*$/.exec(t);
  if (mCap) t = mCap[1].trim();
  const tLow = t.toLowerCase();
  if (
    IG_BAD_AUTHORS.has(tLow) ||
    ["vxinstagram", "ddinstagram", "kkinstagram", "instafix", "login • instagram", "create an account"].some((b) =>
      tLow.includes(b)
    )
  ) {
    return [fallback, ""];
  }
  if (!t) return [fallback, ""];
  const firstLine = (t.split("\n")[0] || t).trim();
  return [firstLine ? firstLine.slice(0, 130) : fallback, t.slice(0, 2500)];
}

export function extractInstagramShortcode(url: string): string | null {
  const m = IG_SHORTCODE_RE.exec(url || "");
  return m ? m[1] : null;
}

export async function normalizeInstagramUrl(url: string): Promise<string> {
  let clean = (url || "").trim();
  if (clean.toLowerCase().includes("/share/") || clean.toLowerCase().includes("instagr.am")) {
    try {
      const r = await fetchWithTimeout(clean, {
        headers: { "User-Agent": MOBILE_IOS_UA, "Accept-Language": "en-US,en;q=0.9,ar;q=0.8" },
        redirect: "follow",
        timeoutMs: 9000,
      });
      if (r.url && r.url.includes("instagram.com")) {
        clean = r.url;
      } else {
        const txt = await r.text();
        const mOg = /property=["']og:url["']\s+content=["'](https:\/\/[^"']+)["']/i.exec(txt);
        if (mOg) clean = mOg[1];
      }
    } catch (e) {
      logger.debug(`Instagram share redirect note: ${String(e)}`);
    }
  }

  const m = IG_SHORTCODE_RE.exec(clean);
  if (m) {
    const shortcode = m[1];
    const postType = clean.toLowerCase().includes("/reel/") || clean.toLowerCase().includes("/reels/") ? "reel" : "p";
    return `https://www.instagram.com/${postType}/${shortcode}/`;
  }

  try {
    const parsed = new URL(clean);
    if (parsed.hostname.toLowerCase().includes("instagram.com")) {
      const p = parsed.pathname.replace(/\/reels\//i, "/reel/");
      return `https://www.instagram.com${p}`;
    }
  } catch {
    // ignore
  }
  return clean;
}

function cleanEscapedUrl(u: string): string {
  return u
    .replace(/\\u0026/g, "&")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&")
    .replace(/\\u003C/g, "<")
    .trim();
}

function pickBestVideoVersion(videoVersions: unknown): string | null {
  if (!Array.isArray(videoVersions) || !videoVersions.length) return null;
  const valid = videoVersions.filter(
    (v): v is Record<string, unknown> => Boolean(v && typeof v === "object" && (v as Record<string, unknown>).url)
  );
  if (!valid.length) return null;
  valid.sort((a, b) => {
    const aArea = Number(a.width || 0) * Number(a.height || 0);
    const bArea = Number(b.width || 0) * Number(b.height || 0);
    return bArea - aArea || Number(b.bandwidth || 0) - Number(a.bandwidth || 0);
  });
  return String(valid[0].url || "");
}

interface IgExtractedCandidate {
  videoUrls: string[];
  imageUrls: string[];
  title: string;
  description: string;
  author: string;
}

function extractFromIgMediaDict(media: Record<string, unknown>, out: IgExtractedCandidate, shortcode: string): void {
  const addV = (u: unknown) => {
    if (typeof u !== "string") return;
    const c = cleanEscapedUrl(u);
    if (isValidMediaUrl(c, "video") && !out.videoUrls.includes(c)) out.videoUrls.push(c);
  };
  const addI = (u: unknown) => {
    if (typeof u !== "string") return;
    const c = cleanEscapedUrl(u);
    if (isValidMediaUrl(c, "image") && !out.imageUrls.includes(c)) out.imageUrls.push(c);
  };

  const owner = (media.owner || media.user || {}) as Record<string, unknown>;
  if (!out.author && owner && typeof owner === "object") {
    const cleaned = cleanInstagramAuthor(owner.username || owner.full_name || "");
    if (cleaned) out.author = cleaned;
  }

  if (!out.description || !out.title) {
    let rawCap = "";
    const capObj = media.caption as Record<string, unknown> | string | undefined;
    if (capObj && typeof capObj === "object" && typeof capObj.text === "string") {
      rawCap = capObj.text;
    } else if (typeof capObj === "string" && capObj.trim()) {
      rawCap = capObj;
    } else {
      const edges = ((media.edge_media_to_caption as Record<string, unknown> | undefined)?.edges || []) as Array<
        Record<string, unknown>
      >;
      if (edges[0]) {
        rawCap = String(((edges[0].node as Record<string, unknown> | undefined)?.text) || "").trim();
      }
    }
    if (rawCap) {
      const [st, fd] = cleanInstagramCaptionAndTitle(rawCap, shortcode);
      if (st && !out.title) out.title = st;
      if (fd && !out.description) out.description = fd;
    }
  }

  const extractSingle = (node: Record<string, unknown>) => {
    if (!node || typeof node !== "object") return;
    const vUrl = pickBestVideoVersion(node.video_versions) || (typeof node.video_url === "string" ? node.video_url : null);
    if (
      vUrl &&
      (node.is_video || node.media_type === 2 || node.__typename === "GraphVideo" || vUrl.includes(".mp4"))
    ) {
      addV(vUrl);
      return;
    }

    let iUrl: string | null = null;
    if (Array.isArray(node.display_resources) && node.display_resources.length > 0) {
      const last = node.display_resources[node.display_resources.length - 1] as Record<string, unknown>;
      iUrl = typeof last?.src === "string" ? last.src : null;
    }
    if (!iUrl) {
      const cands = ((node.image_versions2 as Record<string, unknown> | undefined)?.candidates || []) as Array<
        Record<string, unknown>
      >;
      if (cands.length > 0) {
        cands.sort(
          (a, b) => Number(b.width || 0) * Number(b.height || 0) - Number(a.width || 0) * Number(a.height || 0)
        );
        iUrl = typeof cands[0].url === "string" ? cands[0].url : null;
      }
    }
    if (!iUrl) {
      iUrl =
        (typeof node.display_url === "string" ? node.display_url : null) ||
        (typeof node.thumbnail_src === "string" ? node.thumbnail_src : null);
    }
    if (iUrl) addI(iUrl);
  };

  const sidecarEdges = ((media.edge_sidecar_to_children as Record<string, unknown> | undefined)?.edges || []) as Array<
    Record<string, unknown>
  >;
  const carouselMedia = Array.isArray(media.carousel_media)
    ? (media.carousel_media as Array<Record<string, unknown>>)
    : [];

  if (sidecarEdges.length > 0) {
    for (const edge of sidecarEdges) {
      extractSingle((edge.node as Record<string, unknown>) || edge);
    }
  } else if (carouselMedia.length > 0) {
    for (const item of carouselMedia) extractSingle(item);
  } else {
    extractSingle(media);
  }
}

function parseEmbedContextJson(htmlText: string): Record<string, unknown> | null {
  const mCtx = /"contextJSON"\s*:\s*("(?:\\.|[^"\\])*")/.exec(htmlText);
  if (mCtx) {
    try {
      const unquoted = JSON.parse(mCtx[1]);
      const ctxData = JSON.parse(unquoted);
      const mediaObj = ctxData?.gql_data?.shortcode_media || ctxData?.shortcode_media;
      if (mediaObj && typeof mediaObj === "object") return mediaObj;
    } catch {
      // ignore
    }
  }
  const mItems = /"xdt_api__v1__media__shortcode__web_info"\s*:\s*\{\s*"items"\s*:\s*(\[\{[\s\S]*?\}\])/.exec(
    htmlText
  );
  if (mItems) {
    try {
      const arr = JSON.parse(mItems[1]);
      if (Array.isArray(arr) && arr[0] && typeof arr[0] === "object") return arr[0];
    } catch {
      // ignore
    }
  }
  return null;
}

async function layerEmbedCaptioned(shortcode: string, signal: AbortSignal): Promise<IgExtractedCandidate | null> {
  const out: IgExtractedCandidate = { videoUrls: [], imageUrls: [], title: "", description: "", author: "" };
  const headers = {
    "User-Agent": DEFAULT_UA,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    Referer: "https://www.instagram.com/",
    "Sec-Fetch-Dest": "iframe",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "cross-site",
  };

  for (const embPath of [
    `https://www.instagram.com/p/${shortcode}/embed/captioned/`,
    `https://www.instagram.com/reel/${shortcode}/embed/captioned/`,
  ]) {
    if (signal.aborted) return null;
    try {
      const r = await fetchWithTimeout(embPath, { headers, timeoutMs: 8000, externalSignal: signal });
      if (!r.ok) continue;
      const etext = await r.text();
      if (!etext) continue;

      const mediaObj = parseEmbedContextJson(etext);
      if (mediaObj) extractFromIgMediaDict(mediaObj, out, shortcode);

      if (!out.videoUrls.length) {
        const reVid = /\\?"video_url\\?"\s*:\s*\\?"(https?:[^"\\]+(?:\\.[^"\\]*)*)\\?"/g;
        let m: RegExpExecArray | null;
        while ((m = reVid.exec(etext)) !== null) {
          const c = cleanEscapedUrl(m[1]);
          if (isValidMediaUrl(c, "video") && !out.videoUrls.includes(c)) out.videoUrls.push(c);
        }
      }

      const $ = cheerio.load(etext);
      if (!out.author) {
        const uText = $(".UsernameText").first().text().trim() || $(".EmbedProfile").first().text().trim();
        const cleaned = cleanInstagramAuthor(uText);
        if (cleaned) out.author = cleaned;
      }
      if (!out.description || !out.title) {
        const capEl = $(".Caption").first().clone();
        capEl.find("a.CaptionUsername, div.CaptionComments").remove();
        const capTxt = capEl.text().trim();
        if (capTxt) {
          const [st, fd] = cleanInstagramCaptionAndTitle(capTxt, shortcode);
          if (st && !out.title) out.title = st;
          if (fd && !out.description) out.description = fd;
        }
      }
      $("video").each((_, el) => {
        const src = $(el).attr("src");
        if (src && isValidMediaUrl(src, "video") && !out.videoUrls.includes(src)) out.videoUrls.push(src);
      });
      if (!out.videoUrls.length && !out.imageUrls.length) {
        $("img.EmbeddedMediaImage").each((_, el) => {
          const src = $(el).attr("src") || ($(el).attr("srcset") || "").split(" ")[0];
          if (src && isValidMediaUrl(src, "image") && !out.imageUrls.includes(src)) out.imageUrls.push(src);
        });
      }

      if (out.videoUrls.length || out.imageUrls.length) return out;
    } catch {
      continue;
    }
  }
  return null;
}

async function layerGraphql(shortcode: string, signal: AbortSignal): Promise<IgExtractedCandidate | null> {
  const out: IgExtractedCandidate = { videoUrls: [], imageUrls: [], title: "", description: "", author: "" };
  const jar = new SimpleCookieJar();
  const lsd = "AVqbxe3J_YA";

  const headers = {
    "User-Agent": DEFAULT_UA,
    Accept: "*/*",
    "X-IG-App-ID": "936619743392459",
    "X-ASBD-ID": "129477",
    "X-IG-WWW-Claim": "0",
    "X-CSRFToken": jar.get("csrftoken") || "missing",
    "X-FB-LSD": lsd,
    "X-Requested-With": "XMLHttpRequest",
    "Content-Type": "application/x-www-form-urlencoded",
    Referer: `https://www.instagram.com/reel/${shortcode}/`,
    Origin: "https://www.instagram.com",
  };

  for (const docId of ["8845758582119845", "10015901848480474", "27128499623469141"]) {
    if (signal.aborted) return null;
    try {
      const payload = new URLSearchParams({
        av: "0",
        __d: "www",
        __user: "0",
        __a: "1",
        __req: "3",
        lsd,
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "PolarisPostActionLoadPostQueryQuery",
        variables: JSON.stringify({
          shortcode,
          fetch_comment_count: 2,
          fetch_related_profile_media_count: 0,
          parent_comment_count: 0,
          child_comment_count: 0,
          fetch_like_count: 10,
          fetch_tagged_user_count: null,
          fetch_preview_comment_count: 2,
          has_threaded_comments: true,
          hoisted_comment_id: null,
          hoisted_reply_id: null,
        }),
        server_timestamps: "true",
        doc_id: docId,
      });

      const r = await fetchWithTimeout("https://www.instagram.com/graphql/query", {
        method: "POST",
        headers,
        body: payload,
        cookieJar: jar,
        timeoutMs: 7500,
        externalSignal: signal,
      });
      if (!r.ok) continue;
      const gdata = (await r.json()) as Record<string, unknown>;
      const dataRoot = (gdata.data || {}) as Record<string, unknown>;
      let media = (dataRoot.xdt_shortcode_media || dataRoot.shortcode_media) as Record<string, unknown> | undefined;
      if (!media) {
        const items = ((dataRoot.xdt_api__v1__media__shortcode__web_info as Record<string, unknown> | undefined)
          ?.items || []) as Array<Record<string, unknown>>;
        if (items[0]) media = items[0];
      }
      if (media && typeof media === "object") {
        extractFromIgMediaDict(media, out, shortcode);
        if (out.videoUrls.length || out.imageUrls.length) return out;
      }
    } catch {
      continue;
    }
  }
  return null;
}

async function layerVxAndBridges(shortcode: string, signal: AbortSignal): Promise<IgExtractedCandidate | null> {
  const vxTask = async (sig: AbortSignal): Promise<IgExtractedCandidate | null> => {
    try {
      const r = await fetchWithTimeout(`https://vxinstagram.com/api/getPostDetails?id=${shortcode}`, {
        headers: { "User-Agent": DEFAULT_UA, Accept: "application/json" },
        timeoutMs: 7000,
        externalSignal: sig,
      });
      if (!r.ok) return null;
      const vj = (await r.json()) as Record<string, unknown>;
      const out: IgExtractedCandidate = { videoUrls: [], imageUrls: [], title: "", description: "", author: "" };
      const authorObj = vj.author as Record<string, unknown> | undefined;
      if (authorObj?.username) out.author = cleanInstagramAuthor(authorObj.username);
      if (vj.title) {
        const [st, fd] = cleanInstagramCaptionAndTitle(vj.title, shortcode);
        out.title = st;
        out.description = fd;
      }
      const vidObj = vj.video as Record<string, unknown> | undefined;
      if (vj.is_video && vidObj?.url && typeof vidObj.url === "string") {
        out.videoUrls.push(vidObj.url);
      } else if (typeof vj.thumbnail_url === "string" && isValidMediaUrl(vj.thumbnail_url, "image")) {
        out.imageUrls.push(vj.thumbnail_url);
      }
      return out.videoUrls.length || out.imageUrls.length ? out : null;
    } catch {
      return null;
    }
  };

  const bridgeHosts = [
    `https://d.ddinstagram.com/reel/${shortcode}/`,
    `https://fxstagram.com/reel/${shortcode}/`,
    `https://uuinstagram.com/reel/${shortcode}/`,
    `https://kkinstagram.com/reel/${shortcode}/`,
  ];

  const bridgeTasks = bridgeHosts.map(
    (bUrl) => async (sig: AbortSignal): Promise<IgExtractedCandidate | null> => {
      try {
        const br = await fetchWithTimeout(bUrl, {
          headers: { "User-Agent": "TelegramBot (like TwitterBot)", Accept: "text/html,application/xhtml+xml,*/*" },
          redirect: "follow",
          timeoutMs: 7500,
          externalSignal: sig,
        });
        if (!br.ok) return null;
        const out: IgExtractedCandidate = { videoUrls: [], imageUrls: [], title: "", description: "", author: "" };
        const ctype = (br.headers.get("content-type") || "").toLowerCase();
        if (ctype.includes("video/")) {
          out.videoUrls.push(br.url);
          return out;
        }
        if (ctype.includes("image/") && isValidMediaUrl(br.url, "image")) {
          out.imageUrls.push(br.url);
          return out;
        }
        const $ = cheerio.load(await br.text());
        for (const prop of ["og:video", "og:video:secure_url", "og:video:url", "twitter:player:stream"]) {
          const content = $(`meta[property="${prop}"], meta[name="${prop}"]`).attr("content");
          if (content) {
            const vCand = new URL(content, bUrl).toString();
            if (isValidMediaUrl(vCand, "video") && !out.videoUrls.includes(vCand)) out.videoUrls.push(vCand);
          }
        }
        const desc = $('meta[property="og:description"], meta[name="description"]').attr("content");
        if (desc) {
          const [st, fd] = cleanInstagramCaptionAndTitle(desc, shortcode);
          out.title = st;
          out.description = fd;
        }
        const tit = $('meta[property="og:title"], meta[name="twitter:title"]').attr("content");
        if (tit) out.author = cleanInstagramAuthor(tit);

        if (!out.videoUrls.length) {
          const img = $('meta[property="og:image"], meta[name="twitter:image"]').attr("content");
          if (img) {
            const iCand = new URL(img, bUrl).toString();
            if (isValidMediaUrl(iCand, "image")) out.imageUrls.push(iCand);
          }
        }
        return out.videoUrls.length || out.imageUrls.length ? out : null;
      } catch {
        return null;
      }
    }
  );

  if (signal.aborted) return null;
  return raceFirstSuccess([vxTask, ...bridgeTasks], 9000);
}

async function layerCobalt(cleanUrl: string, signal: AbortSignal): Promise<IgExtractedCandidate | null> {
  return raceFirstSuccess(
    COBALT_INSTANCES.map(
      (cEp) => async (sig: AbortSignal): Promise<IgExtractedCandidate | null> => {
        if (signal.aborted) return null;
        try {
          const headers = {
            Accept: "application/json",
            "Content-Type": "application/json",
            "User-Agent": DEFAULT_UA,
            Origin: cEp,
            Referer: `${cEp}/`,
          };
          const cr = await fetchWithTimeout(`${cEp.replace(/\/$/, "")}/`, {
            method: "POST",
            headers,
            body: JSON.stringify({ url: cleanUrl, videoQuality: "1080" }),
            timeoutMs: 8000,
            externalSignal: sig,
          });
          if (!cr.ok) return null;
          const cj = (await cr.json()) as Record<string, unknown>;
          const out: IgExtractedCandidate = { videoUrls: [], imageUrls: [], title: "", description: "", author: "" };
          if (typeof cj.url === "string") {
            out.videoUrls.push(cj.url);
          } else if (Array.isArray(cj.picker)) {
            for (const p of cj.picker as Array<Record<string, unknown>>) {
              if (typeof p?.url === "string") {
                if (p.type === "video") out.videoUrls.push(p.url);
                else out.imageUrls.push(p.url);
              }
            }
          }
          return out.videoUrls.length || out.imageUrls.length ? out : null;
        } catch {
          return null;
        }
      }
    ),
    9000
  );
}

export async function downloadInstagramFast(url: string, workDir: string): Promise<InstagramDownloadResult> {
  const result: InstagramDownloadResult = { videos: [], images: [], title: "", description: "", author: "" };
  const cleanUrl = await normalizeInstagramUrl(url);
  const shortcode = extractInstagramShortcode(cleanUrl);
  if (!shortcode) return result;

  // موجة 1 متوازية: Embed Captioned + GraphQL
  let candidate = await raceFirstSuccess<IgExtractedCandidate>(
    [
      (sig) => layerEmbedCaptioned(shortcode, sig),
      (sig) => layerGraphql(shortcode, sig),
    ],
    10000
  );

  // موجة 2 متوازية: VX/Bridges + Cobalt
  if (!candidate) {
    candidate = await raceFirstSuccess<IgExtractedCandidate>(
      [
        (sig) => layerVxAndBridges(shortcode, sig),
        (sig) => layerCobalt(cleanUrl, sig),
      ],
      10000
    );
  }

  if (!candidate) return result;

  // تحميل الفيديوهات والصور بالتوازي
  const dlVideos = await mapConcurrent(candidate.videoUrls.slice(0, 5), 3, async (vu, idx) => {
    const vPath = path.join(workDir, `ig_video_${idx}.mp4`);
    if (await downloadBinaryFile(vu, vPath, { minSize: 8192, expectedType: "video" })) {
      if (await probeHasVideoStream(vPath)) return vPath;
    }
    return null;
  });
  result.videos = dlVideos.filter((v): v is string => Boolean(v));

  const dlImages = await mapConcurrent(candidate.imageUrls.slice(0, 10), 5, async (iu, idx) => {
    const iPath = path.join(workDir, `ig_image_${idx}.jpg`);
    if (await downloadBinaryFile(iu, iPath, { minSize: 2500, expectedType: "image" })) {
      return iPath;
    }
    return null;
  });
  result.images = validateAndFilterImages(dlImages.filter((i): i is string => Boolean(i)));

  result.author = cleanInstagramAuthor(candidate.author);
  const [shortT, fullD] = cleanInstagramCaptionAndTitle(candidate.description || candidate.title, shortcode);
  result.title = shortT;
  result.description = fullD || (shortT.startsWith("منشور انستغرام") ? "" : shortT);

  return result;
}
