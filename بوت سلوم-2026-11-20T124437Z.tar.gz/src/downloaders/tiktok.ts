/**
 * محرك تيك توك المصلّح والسريع (Parallel Multi-Route Engine):
 *
 * الإصلاحات الجذرية التي عالجت فشل تيك توك وبطء التحميل:
 * 1) فك روابط تيك توك المختصرة (vt.tiktok.com / vm.tiktok.com / /t/) بسرعة عالية مع استخراج المعرف (video/photo).
 * 2) سباق متوازي (Wave 1) بين 3 مسارات سريعة مع AbortController لإلغاء البطيء فوراً:
 *    - TikWM v2 API (بـ Headers كاملة + تحميل الصوت فقط عند الحاجة وليس مع كل فيديو!).
 *    - استخراج مباشر من صفحة تيك توك (__UNIVERSAL_DATA_FOR_REHYDRATION__ + SIGI_STATE)
 *      مع CookieJar (ttwid / tt_chain_token) وأولوية كودك H.264 لتفادي إعادة الترميز البطيئة.
 *    - TikTok Embed v2 Endpoint (خفيف ونادراً ما يتعرض للحظر).
 * 3) سباق احتياطي (Wave 2) عند الحاجة:
 *    - أحدث إصدار من yt-dlp المستقل بدون المضيف المعطل (api16-normal-c-useast1a.tiktokv.com).
 *    - LoveTik + TikCDN Web API.
 * 4) تحميل متوازي لألبومات صور تيك توك (Photo Slideshows) بسرعة مضاعفة.
 */

import fs from "node:fs";
import path from "node:path";
import { downloadBinaryFile, probeHasVideoStream } from "../mediaUtils.js";
import {
  DEFAULT_UA,
  MOBILE_ANDROID_UA,
  SimpleCookieJar,
  fetchWithTimeout,
  logger,
  mapConcurrent,
  raceFirstSuccess,
  sleep,
} from "../network.js";
import { runYtDlpDownload } from "./ytdlp.js";

export const TIKTOK_ID_RE = /\/(?:video|photo|v)\/(\d{15,22})/i;
export const TIKTOK_HOST_RE = /(?:^|\.)(?:tiktok\.com|tiktokv\.com|musical\.ly)$/i;

export interface TikTokDownloadResult {
  videos: string[];
  audios: string[];
  images: string[];
  title: string;
  description: string;
  author: string;
  routeUsed?: string;
}

export function isTikTokUrl(url: string): boolean {
  try {
    const parsed = new URL((url || "").trim());
    return TIKTOK_HOST_RE.test(parsed.hostname.toLowerCase());
  } catch {
    return (url || "").toLowerCase().includes("tiktok.com");
  }
}

export function extractTikTokIdFromUrl(url: string): string | null {
  const m = TIKTOK_ID_RE.exec((url || "").trim());
  return m ? m[1] : null;
}

export function normalizeTikWmUrl(u: unknown): string {
  if (!u || typeof u !== "string") return "";
  const trimmed = u.trim();
  if (trimmed.startsWith("//")) return `https:${trimmed}`;
  if (trimmed.startsWith("/")) return `https://www.tikwm.com${trimmed}`;
  return trimmed;
}

/**
 * فك اختصار روابط تيك توك (vt.tiktok.com / vm.tiktok.com / tiktok.com/t/...) بسرعة (مهلة 4 ثوانٍ).
 */
export async function resolveTikTokUrlAndId(
  url: string,
  signal?: AbortSignal
): Promise<{ finalUrl: string; awemeId: string | null }> {
  const clean = (url || "").trim();
  const directId = extractTikTokIdFromUrl(clean);
  if (directId) {
    return { finalUrl: clean, awemeId: directId };
  }

  let current = clean;
  for (let hop = 0; hop < 5; hop++) {
    try {
      const resp = await fetchWithTimeout(current, {
        method: "GET",
        headers: {
          "User-Agent": MOBILE_ANDROID_UA,
          Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        },
        redirect: "manual",
        timeoutMs: 4500,
        externalSignal: signal,
      });

      const loc = resp.headers.get("location");
      if (loc) {
        const nextUrl = new URL(loc, current).toString();
        const foundId = extractTikTokIdFromUrl(nextUrl);
        if (foundId) {
          return { finalUrl: nextUrl, awemeId: foundId };
        }
        current = nextUrl;
        continue;
      }

      if (resp.url && resp.url !== current) {
        const foundId = extractTikTokIdFromUrl(resp.url);
        if (foundId) return { finalUrl: resp.url, awemeId: foundId };
        current = resp.url;
      }

      // أحياناً يكون الرابط الكامل داخل canonical أو HTML
      if (resp.ok) {
        const htmlText = await resp.text();
        const mHtml = TIKTOK_ID_RE.exec(htmlText);
        if (mHtml) {
          return { finalUrl: `https://www.tiktok.com/@tiktok/video/${mHtml[1]}`, awemeId: mHtml[1] };
        }
      }
      break;
    } catch {
      break;
    }
  }

  return { finalUrl: current, awemeId: extractTikTokIdFromUrl(current) };
}

/**
 * المسار 1: TikWM v2 API (سريع جداً، يدعم الفيديوهات بدون علامة مائية + ألبومات الصور + الصوت).
 * تم إصلاح المشاكل السابقة:
 * - إرسال User-Agent كامل و Referer و Origin لتجنب حظر WAF.
 * - عدم تحميل ملف الصوت tt_music.mp3 عند طلب فيديو فقط (يوفر 2-4 ثوانٍ في كل تحميل!).
 * - تحميل ألبومات الصور بالتوازي بدلاً من التسلسل.
 */
async function routeTikWm(
  targetUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  signal: AbortSignal
): Promise<TikTokDownloadResult | null> {
  const headers: Record<string, string> = {
    "User-Agent": DEFAULT_UA,
    Accept: "application/json, text/javascript, */*; q=0.01",
    Origin: "https://www.tikwm.com",
    Referer: "https://www.tikwm.com/",
    "X-Requested-With": "XMLHttpRequest",
  };

  for (let attempt = 0; attempt < 2; attempt++) {
    if (signal.aborted) return null;
    try {
      let resp: Response;
      if (attempt === 0) {
        const body = new URLSearchParams({ url: targetUrl, count: "12", cursor: "0", web: "1", hd: "1" });
        resp = await fetchWithTimeout("https://www.tikwm.com/api/", {
          method: "POST",
          headers: { ...headers, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
          body,
          timeoutMs: 8000,
          externalSignal: signal,
        });
      } else {
        const qs = new URLSearchParams({ url: targetUrl, hd: "1" });
        resp = await fetchWithTimeout(`https://www.tikwm.com/api/?${qs.toString()}`, {
          method: "GET",
          headers,
          timeoutMs: 8000,
          externalSignal: signal,
        });
      }

      if (!resp.ok) continue;
      const json = (await resp.json()) as Record<string, unknown>;
      const msgLow = String(json.msg || "").toLowerCase();

      if (json.code !== 0) {
        if ((msgLow.includes("limit") || msgLow.includes("1 request")) && attempt === 0) {
          await sleep(1100);
          continue;
        }
        continue;
      }

      const data = json.data as Record<string, unknown> | undefined;
      if (!data || typeof data !== "object") continue;

      const out: TikTokDownloadResult = {
        videos: [],
        audios: [],
        images: [],
        title: "منشور تيك توك",
        description: "",
        author: "",
        routeUsed: "TikWM v2",
      };

      const rawTitle = String(data.title || "").trim();
      if (rawTitle) {
        out.title = rawTitle.slice(0, 140);
        out.description = rawTitle.slice(0, 2500);
      }
      const authorObj = data.author as Record<string, unknown> | undefined;
      if (authorObj && typeof authorObj === "object") {
        out.author = String(authorObj.nickname || authorObj.unique_id || "").slice(0, 50);
      }

      const imagesList = Array.isArray(data.images) ? (data.images as string[]) : [];
      const musicUrl = normalizeTikWmUrl(
        data.music || ((data.music_info as Record<string, unknown> | undefined)?.play ?? "")
      );

      const dlHeaders = { "User-Agent": DEFAULT_UA, Referer: "https://www.tikwm.com/" };

      // حالة 1: طلب صوت فقط (voice/mp3) -> نحمّل الصوت مباشرة بدون تحميل الفيديو!
      if ((mode === "voice" || mode === "mp3") && musicUrl) {
        const audPath = path.join(workDir, "tt_tikwm_music.mp3");
        if (
          await downloadBinaryFile(musicUrl, audPath, {
            headers: dlHeaders,
            expectedType: "audio",
            minSize: 4096,
            signal,
          })
        ) {
          out.audios.push(audPath);
          return out;
        }
      }

      // حالة 2: ألبوم صور (TikTok Photo Slideshow) -> تحميل متوازي لكل الصور + الصوت
      if (imagesList.length > 0) {
        const downloadedImgs = await mapConcurrent(imagesList.slice(0, 10), 5, async (imgUrl, idx) => {
          const absUrl = normalizeTikWmUrl(imgUrl);
          const imgPath = path.join(workDir, `tt_slide_${idx}.jpg`);
          const ok = await downloadBinaryFile(absUrl, imgPath, {
            headers: dlHeaders,
            expectedType: "image",
            minSize: 1500,
            signal,
          });
          return ok ? imgPath : null;
        });
        out.images = downloadedImgs.filter((p): p is string => Boolean(p));

        if (musicUrl) {
          const audPath = path.join(workDir, "tt_slide_music.mp3");
          if (
            await downloadBinaryFile(musicUrl, audPath, {
              headers: dlHeaders,
              expectedType: "audio",
              minSize: 4096,
              signal,
            })
          ) {
            out.audios.push(audPath);
          }
        }
        if (out.images.length > 0 || out.audios.length > 0) return out;
      }

      // حالة 3: فيديو بدون علامة مائية (تفضيل HD ثم Play العادي ثم WM)
      for (const field of ["hdplay", "play", "wmplay"] as const) {
        if (signal.aborted) return null;
        const vidUrl = normalizeTikWmUrl(data[field]);
        if (!vidUrl) continue;
        const vidPath = path.join(workDir, `tt_tikwm_${field}.mp4`);
        if (
          await downloadBinaryFile(vidUrl, vidPath, {
            headers: dlHeaders,
            expectedType: "video",
            minSize: 16384,
            signal,
          })
        ) {
          out.videos.push(vidPath);
          return out;
        }
      }
    } catch (err) {
      logger.debug(`[TikTok] TikWM note: ${String(err)}`);
    }
  }

  return null;
}

/**
 * استخراج روابط الفيديو من كائن itemStruct مع أولوية H.264 (avc1) لتفادي إعادة الترميز البطيئة.
 */
function pickBestTikTokVideoUrls(videoObj: Record<string, unknown>): string[] {
  const candidates: Array<{ url: string; isH264: number; bitrate: number }> = [];
  const seen = new Set<string>();

  const pushUrl = (u: unknown, isH264: number, bitrate: number) => {
    if (typeof u !== "string" || !u.startsWith("http") || seen.has(u)) return;
    seen.add(u);
    candidates.push({ url: u, isH264, bitrate });
  };

  const bitrateInfo = Array.isArray(videoObj.bitrateInfo)
    ? (videoObj.bitrateInfo as Array<Record<string, unknown>>)
    : [];
  for (const br of bitrateInfo) {
    const codec = String(br.CodecType || br.GearName || "").toLowerCase();
    const isH264 = codec.includes("h264") || codec.includes("avc") || !codec.includes("bytevc1") ? 1 : 0;
    const bitrate = Number(br.Bitrate || 0);
    const playAddr = br.PlayAddr as Record<string, unknown> | undefined;
    const urlList = Array.isArray(playAddr?.UrlList) ? (playAddr!.UrlList as string[]) : [];
    for (const u of urlList) {
      pushUrl(u, isH264, bitrate);
    }
  }

  pushUrl(videoObj.playAddr, 1, 1);
  pushUrl(videoObj.downloadAddr, 0, 0);

  candidates.sort((a, b) => b.isH264 - a.isH264 || b.bitrate - a.bitrate);
  return candidates.map((c) => c.url);
}

/**
 * المسار 2: استخراج مباشر من صفحة تيك توك (__UNIVERSAL_DATA_FOR_REHYDRATION__ و SIGI_STATE)
 * مع CookieJar يحافظ على ttwid + tt_chain_token لتفادي خطأ 403 من خوادم tiktokcdn.
 */
async function routeTikTokWebDirect(
  targetUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  signal: AbortSignal
): Promise<TikTokDownloadResult | null> {
  const jar = new SimpleCookieJar();
  const pageHeaders = {
    "User-Agent": DEFAULT_UA,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Upgrade-Insecure-Requests": "1",
  };

  try {
    const resp = await fetchWithTimeout(targetUrl, {
      headers: pageHeaders,
      cookieJar: jar,
      redirect: "follow",
      timeoutMs: 8500,
      externalSignal: signal,
    });
    if (!resp.ok) return null;
    const htmlText = await resp.text();
    if (!htmlText) return null;

    let item: Record<string, unknown> | null = null;

    const mUni = /<script\s+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/i.exec(
      htmlText
    );
    if (mUni) {
      try {
        const uni = JSON.parse(mUni[1]);
        const scope = uni?.__DEFAULT_SCOPE__ || {};
        item =
          scope?.["webapp.video-detail"]?.itemInfo?.itemStruct ||
          scope?.["webapp.reflow.video.detail"]?.itemInfo?.itemStruct ||
          null;
      } catch {
        // ignore
      }
    }

    if (!item) {
      const mSigi = /<script\s+id="SIGI_STATE"[^>]*>([\s\S]*?)<\/script>/i.exec(htmlText);
      if (mSigi) {
        try {
          const sigi = JSON.parse(mSigi[1]);
          const itemModule = sigi?.ItemModule || {};
          const firstKey = Object.keys(itemModule)[0];
          if (firstKey) item = itemModule[firstKey];
        } catch {
          // ignore
        }
      }
    }

    if (!item || typeof item !== "object") return null;

    const out: TikTokDownloadResult = {
      videos: [],
      audios: [],
      images: [],
      title: "منشور تيك توك",
      description: "",
      author: "",
      routeUsed: "TikTok Web Direct",
    };

    const desc = String(item.desc || "").trim();
    if (desc) {
      out.title = desc.slice(0, 140);
      out.description = desc.slice(0, 2500);
    }
    const author = item.author as Record<string, unknown> | undefined;
    if (author && typeof author === "object") {
      out.author = String(author.nickname || author.uniqueId || "").slice(0, 50);
    }

    const dlHeaders = {
      "User-Agent": DEFAULT_UA,
      Referer: "https://www.tiktok.com/",
      Origin: "https://www.tiktok.com",
    };

    const musicUrl = String((item.music as Record<string, unknown> | undefined)?.playUrl || "");
    if ((mode === "voice" || mode === "mp3") && musicUrl) {
      const audPath = path.join(workDir, "tt_web_music.mp3");
      if (
        await downloadBinaryFile(musicUrl, audPath, {
          headers: dlHeaders,
          cookieJar: jar,
          expectedType: "audio",
          minSize: 4096,
          signal,
        })
      ) {
        out.audios.push(audPath);
        return out;
      }
    }

    // ألبوم صور
    const imgPost = ((item.imagePost as Record<string, unknown> | undefined)?.images || []) as Array<
      Record<string, unknown>
    >;
    if (imgPost.length > 0) {
      const downloadedImgs = await mapConcurrent(imgPost.slice(0, 10), 5, async (im, idx) => {
        const urls = ((im.imageURL as Record<string, unknown> | undefined)?.urlList || []) as string[];
        for (const iu of urls) {
          const ip = path.join(workDir, `tt_web_img_${idx}.jpg`);
          if (
            await downloadBinaryFile(iu, ip, {
              headers: dlHeaders,
              cookieJar: jar,
              expectedType: "image",
              minSize: 1500,
              signal,
            })
          ) {
            return ip;
          }
        }
        return null;
      });
      out.images = downloadedImgs.filter((p): p is string => Boolean(p));
      if (musicUrl) {
        const ap = path.join(workDir, "tt_web_slide_music.mp3");
        if (
          await downloadBinaryFile(musicUrl, ap, {
            headers: dlHeaders,
            cookieJar: jar,
            expectedType: "audio",
            minSize: 4096,
            signal,
          })
        ) {
          out.audios.push(ap);
        }
      }
      if (out.images.length > 0) return out;
    }

    // فيديو H.264 بأعلى دقة
    const videoObj = (item.video || {}) as Record<string, unknown>;
    const vidUrls = pickBestTikTokVideoUrls(videoObj);
    for (let idx = 0; idx < Math.min(vidUrls.length, 3); idx++) {
      if (signal.aborted) return null;
      const vp = path.join(workDir, `tt_web_vid_${idx}.mp4`);
      if (
        await downloadBinaryFile(vidUrls[idx], vp, {
          headers: dlHeaders,
          cookieJar: jar,
          expectedType: "video",
          minSize: 16384,
          signal,
        })
      ) {
        out.videos.push(vp);
        return out;
      }
    }
  } catch (err) {
    logger.debug(`[TikTok] Web Direct note: ${String(err)}`);
  }

  return null;
}

/**
 * المسار 3: TikTok Embed v2 Endpoint (خفيف جداً وسريع الاستجابة).
 */
async function routeTikTokEmbedV2(
  awemeId: string | null,
  workDir: string,
  signal: AbortSignal
): Promise<TikTokDownloadResult | null> {
  if (!awemeId) return null;
  const jar = new SimpleCookieJar();

  try {
    const resp = await fetchWithTimeout(`https://www.tiktok.com/embed/v2/${awemeId}`, {
      headers: {
        "User-Agent": DEFAULT_UA,
        Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        Referer: "https://www.tiktok.com/",
      },
      cookieJar: jar,
      timeoutMs: 7500,
      externalSignal: signal,
    });
    if (!resp.ok) return null;
    const htmlText = await resp.text();
    const mData = /<script\s+id="__FRONTITY_CONNECT_STATE__"[^>]*>([\s\S]*?)<\/script>/i.exec(htmlText);
    if (!mData) return null;

    const state = JSON.parse(mData[1]);
    const videoData = state?.source?.data?.[`/embed/v2/${awemeId}`]?.videoData;
    const itemInfos = videoData?.itemInfos;
    if (!itemInfos) return null;

    const urls: string[] = itemInfos?.video?.urls || [];
    if (!urls.length) return null;

    const out: TikTokDownloadResult = {
      videos: [],
      audios: [],
      images: [],
      title: String(itemInfos.text || "منشور تيك توك").slice(0, 140),
      description: String(itemInfos.text || "").slice(0, 2500),
      author: String(videoData?.authorInfos?.nickName || videoData?.authorInfos?.uniqueId || "").slice(0, 50),
      routeUsed: "TikTok Embed v2",
    };

    const dlHeaders = {
      "User-Agent": DEFAULT_UA,
      Referer: `https://www.tiktok.com/embed/v2/${awemeId}`,
    };

    for (let i = 0; i < Math.min(urls.length, 2); i++) {
      const vp = path.join(workDir, `tt_embed_${i}.mp4`);
      if (
        await downloadBinaryFile(urls[i], vp, {
          headers: dlHeaders,
          cookieJar: jar,
          expectedType: "video",
          minSize: 16384,
          signal,
        })
      ) {
        out.videos.push(vp);
        return out;
      }
    }
  } catch (err) {
    logger.debug(`[TikTok] Embed v2 note: ${String(err)}`);
  }

  return null;
}

/**
 * المسار 4: LoveTik AJAX API (مسار احتياطي سريع).
 */
async function routeLoveTik(
  targetUrl: string,
  workDir: string,
  signal: AbortSignal
): Promise<TikTokDownloadResult | null> {
  try {
    const resp = await fetchWithTimeout("https://lovetik.com/api/ajax/search", {
      method: "POST",
      headers: {
        "User-Agent": DEFAULT_UA,
        Accept: "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        Origin: "https://lovetik.com",
        Referer: "https://lovetik.com/",
        "X-Requested-With": "XMLHttpRequest",
      },
      body: new URLSearchParams({ query: targetUrl }),
      timeoutMs: 8000,
      externalSignal: signal,
    });
    if (!resp.ok) return null;
    const j = (await resp.json()) as Record<string, unknown>;
    if (j.status !== "ok") return null;

    const links = (Array.isArray(j.links) ? j.links : []) as Array<Record<string, string>>;
    const mp4Links = links
      .filter((lk) => String(lk.t || "").toUpperCase().includes("MP4") && lk.a)
      .sort((a, b) => {
        const aHd = String(a.t || "").toUpperCase().includes("HD") ? 1 : 0;
        const bHd = String(b.t || "").toUpperCase().includes("HD") ? 1 : 0;
        const aNoWm = String(a.t || "").toUpperCase().includes("NO WATERMARK") ? 1 : 0;
        const bNoWm = String(b.t || "").toUpperCase().includes("NO WATERMARK") ? 1 : 0;
        return bHd - aHd || bNoWm - aNoWm;
      });

    for (let i = 0; i < Math.min(mp4Links.length, 2); i++) {
      const vp = path.join(workDir, `tt_lovetik_${i}.mp4`);
      if (
        await downloadBinaryFile(mp4Links[i].a, vp, {
          headers: { "User-Agent": DEFAULT_UA, Referer: "https://lovetik.com/" },
          expectedType: "video",
          minSize: 16384,
          signal,
        })
      ) {
        const desc = String(j.desc || "").trim();
        return {
          videos: [vp],
          audios: [],
          images: [],
          title: (desc || "منشور تيك توك").slice(0, 140),
          description: desc.slice(0, 2500),
          author: String(j.author_name || "").slice(0, 50),
          routeUsed: "LoveTik",
        };
      }
    }
  } catch (err) {
    logger.debug(`[TikTok] LoveTik note: ${String(err)}`);
  }

  return null;
}

/**
 * المسار 5: yt-dlp المستقل المحدّث تلقائياً (بدون المضيف المعطل api16-normal-c-useast1a.tiktokv.com).
 */
async function routeTikTokYtDlp(
  targetUrl: string,
  workDir: string,
  mode: "video" | "voice" | "mp3",
  signal: AbortSignal
): Promise<TikTokDownloadResult | null> {
  const ydlDir = path.join(workDir, "ydl_tt");
  fs.mkdirSync(ydlDir, { recursive: true });

  const res = await runYtDlpDownload({
    targetUrl,
    workDir: ydlDir,
    mode,
    platform: "tiktok",
    timeoutMs: 35000,
    signal,
  });

  const out: TikTokDownloadResult = {
    videos: [],
    audios: [],
    images: [],
    title: (res.title || "منشور تيك توك").slice(0, 140),
    description: (res.description || res.title || "").slice(0, 2500),
    author: (res.author || "").slice(0, 50),
    routeUsed: "yt-dlp (latest)",
  };

  try {
    for (const fname of fs.readdirSync(ydlDir).sort()) {
      if (fname.endsWith(".part") || fname.endsWith(".ytdl")) continue;
      const fp = path.join(ydlDir, fname);
      if (!fs.statSync(fp).isFile() || fs.statSync(fp).size < 4096) continue;
      const ext = path.extname(fp).toLowerCase();
      if ([".mp3", ".m4a", ".ogg", ".opus", ".wav"].includes(ext)) {
        out.audios.push(fp);
      } else if ([".mp4", ".mkv", ".webm", ".mov"].includes(ext)) {
        if (await probeHasVideoStream(fp)) out.videos.push(fp);
        else out.audios.push(fp);
      }
    }
  } catch {
    // ignore
  }

  return out.videos.length > 0 || out.audios.length > 0 ? out : null;
}

/**
 * المحرك الرئيسي الموحد لتيك توك (سباق متوازي على موجتين -> أسرع مسار يفوز خلال ~1-2 ثانية).
 */
export async function downloadTikTokFast(
  url: string,
  workDir: string,
  mode: "video" | "voice" | "mp3" = "video",
  originalUrl?: string
): Promise<TikTokDownloadResult> {
  const empty: TikTokDownloadResult = {
    videos: [],
    audios: [],
    images: [],
    title: "منشور تيك توك",
    description: "",
    author: "",
  };

  const primaryUrl = (originalUrl || url || "").trim();
  if (!isTikTokUrl(primaryUrl)) return empty;

  const { finalUrl, awemeId } = await resolveTikTokUrlAndId(primaryUrl);
  const canonicalUrl = awemeId && finalUrl.includes("tiktok.com") ? finalUrl : primaryUrl;

  // الموجة 1: سباق متوازي لأسرع 3 مسارات (TikWM v2 + Web Direct + Embed v2)
  const wave1 = await raceFirstSuccess<TikTokDownloadResult>(
    [
      (sig) => routeTikWm(primaryUrl, workDir, mode, sig),
      (sig) => routeTikTokWebDirect(canonicalUrl, workDir, mode, sig),
      ...(mode === "video" && awemeId ? [(sig: AbortSignal) => routeTikTokEmbedV2(awemeId, workDir, sig)] : []),
    ],
    14000
  );
  if (wave1) {
    logger.info(`[TikTok] نجح التحميل عبر مسار: ${wave1.routeUsed}`);
    return wave1;
  }

  // الموجة 2: سباق متوازي بين yt-dlp المحدّث تلقائياً + LoveTik
  const wave2 = await raceFirstSuccess<TikTokDownloadResult>(
    [
      (sig) => routeTikTokYtDlp(canonicalUrl, workDir, mode, sig),
      ...(mode === "video" ? [(sig: AbortSignal) => routeLoveTik(canonicalUrl, workDir, sig)] : []),
    ],
    35000
  );
  if (wave2) {
    logger.info(`[TikTok] نجح التحميل عبر مسار احتياطي: ${wave2.routeUsed}`);
    return wave2;
  }

  return empty;
}
