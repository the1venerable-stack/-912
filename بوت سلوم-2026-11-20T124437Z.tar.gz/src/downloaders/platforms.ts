/**
 * محركات المنصات الإضافية:
 * - منشورات تيليجرام العامة (t.me/channel/123)
 * - صفحات الويب وروابط جوجل المباشرة
 */

import path from "node:path";
import * as cheerio from "cheerio";
import { downloadBinaryFile, validateAndFilterImages } from "../mediaUtils.js";
import { DEFAULT_UA, fetchWithTimeout, logger, mapConcurrent } from "../network.js";
import { isValidMediaUrl } from "./instagram.js";

export interface PlatformScrapeResult {
  videos: string[];
  audios: string[];
  images: string[];
  title: string;
  description: string;
  unsupported_reason?: string | null;
}

export async function downloadTelegramPublicPost(
  url: string,
  workDir: string
): Promise<PlatformScrapeResult> {
  const result: PlatformScrapeResult = {
    videos: [],
    audios: [],
    images: [],
    title: "منشور تيليجرام",
    description: "",
    unsupported_reason: null,
  };

  let pathParts: string[] = [];
  try {
    pathParts = new URL(url).pathname.split("/").filter(Boolean);
  } catch {
    return result;
  }

  if (!pathParts.length) return result;

  if (["addlist", "joinchat"].includes(pathParts[0].toLowerCase()) || pathParts[0].startsWith("+")) {
    result.unsupported_reason =
      "هذا الرابط هو رابط إضافة مجلد أو دعوة انضمام وليس رابط منشور عام (مثال: t.me/channel/123).";
    return result;
  }

  if (pathParts.length >= 2 && /^\d+$/.test(pathParts[pathParts.length - 1])) {
    const channel = pathParts[pathParts.length - 2];
    const msgId = pathParts[pathParts.length - 1];
    const embedUrl = `https://t.me/${channel}/${msgId}?embed=1`;

    try {
      const resp = await fetchWithTimeout(embedUrl, {
        headers: { "User-Agent": DEFAULT_UA },
        timeoutMs: 12000,
      });
      if (!resp.ok) return result;
      const $ = cheerio.load(await resp.text());

      const textDiv = $(".tgme_widget_message_text").first();
      if (textDiv.length) {
        const fullTxt = textDiv.text().trim();
        result.title = (fullTxt.split("\n")[0] || "منشور تيليجرام").slice(0, 120);
        result.description = fullTxt.slice(0, 2500);
      }

      const vidSrcs: string[] = [];
      $("video").each((_, el) => {
        const src = $(el).attr("src");
        if (src && src.startsWith("http")) vidSrcs.push(src);
      });
      for (let i = 0; i < vidSrcs.length; i++) {
        const vp = path.join(workDir, `tg_video_${i}.mp4`);
        if (await downloadBinaryFile(vidSrcs[i], vp, { expectedType: "video", minSize: 1024 })) {
          result.videos.push(vp);
        }
      }

      const audSrcs: string[] = [];
      $("audio").each((_, el) => {
        const src = $(el).attr("src");
        if (src && src.startsWith("http")) audSrcs.push(src);
      });
      for (let i = 0; i < audSrcs.length; i++) {
        const ap = path.join(workDir, `tg_voice_${i}.ogg`);
        if (await downloadBinaryFile(audSrcs[i], ap, { expectedType: "audio", minSize: 512 })) {
          result.audios.push(ap);
        }
      }

      const imgSrcs: string[] = [];
      $("a.tgme_widget_message_photo_wrap").each((_, el) => {
        const styleAttr = $(el).attr("style") || "";
        const m = /background-image:url\(['"]?(https:\/\/[^'")]+)['"]?\)/i.exec(styleAttr);
        if (m) imgSrcs.push(m[1]);
      });

      const dlImgs = await mapConcurrent(imgSrcs.slice(0, 10), 4, async (iu, idx) => {
        const ip = path.join(workDir, `tg_photo_${idx}.jpg`);
        return (await downloadBinaryFile(iu, ip, { expectedType: "image", minSize: 512 })) ? ip : null;
      });
      result.images = dlImgs.filter((p): p is string => Boolean(p));
    } catch (e) {
      logger.debug(`Telegram embed scrape note: ${String(e)}`);
    }
  }

  return result;
}

export async function scrapeGoogleAndWebpageMedia(
  url: string,
  workDir: string,
  searchQuery?: string | null
): Promise<PlatformScrapeResult> {
  const result: PlatformScrapeResult = {
    videos: [],
    audios: [],
    images: [],
    title: searchQuery || "منشور محمل",
    description: "",
  };

  const uLow = (url || "").toLowerCase();
  if (["instagram.com", "instagr.am", "youtube.com", "youtu.be", "tiktok.com"].some((k) => uLow.includes(k))) {
    return result;
  }

  try {
    const resp = await fetchWithTimeout(url, {
      headers: { "User-Agent": DEFAULT_UA, Accept: "*/*" },
      redirect: "follow",
      timeoutMs: 15000,
    });
    const contentType = (resp.headers.get("content-type") || "").toLowerCase();
    const baseUrlPath = uLow.split("?")[0];

    if (contentType.includes("video/") || [".mp4", ".mov", ".webm", ".mkv"].some((e) => baseUrlPath.endsWith(e))) {
      const vp = path.join(workDir, "direct_video.mp4");
      if (await downloadBinaryFile(url, vp, { expectedType: "video", minSize: 1024 })) {
        result.videos.push(vp);
        return result;
      }
    }

    if (
      contentType.includes("audio/") ||
      [".mp3", ".m4a", ".wav", ".ogg", ".opus", ".aac"].some((e) => baseUrlPath.endsWith(e))
    ) {
      const ap = path.join(workDir, "direct_audio.mp3");
      if (await downloadBinaryFile(url, ap, { expectedType: "audio", minSize: 1024 })) {
        result.audios.push(ap);
        return result;
      }
    }

    if (
      contentType.includes("image/") ||
      [".jpg", ".jpeg", ".png", ".webp", ".gif"].some((e) => baseUrlPath.endsWith(e))
    ) {
      const ext = contentType.includes("png") ? ".png" : ".jpg";
      const ip = path.join(workDir, `direct_image${ext}`);
      if (await downloadBinaryFile(url, ip, { expectedType: "image", minSize: 512 })) {
        result.images.push(ip);
        return result;
      }
    }

    const htmlText = await resp.text();
    const $ = cheerio.load(htmlText);
    const pageTitle = $("title").first().text().trim();
    if (pageTitle) result.title = pageTitle.slice(0, 120);

    const descMeta =
      $('meta[property="og:description"]').attr("content") ||
      $('meta[name="description"]').attr("content") ||
      $('meta[name="twitter:description"]').attr("content");
    if (descMeta) result.description = descMeta.trim().slice(0, 2500);

    const videoUrls: string[] = [];
    const audioUrls: string[] = [];
    const imageUrls: string[] = [];

    for (const prop of ["og:video", "og:video:url", "og:video:secure_url", "twitter:player:stream"]) {
      const c = $(`meta[property="${prop}"], meta[name="${prop}"]`).attr("content");
      if (c) {
        const vu = new URL(c, url).toString();
        if (isValidMediaUrl(vu, "video") && !videoUrls.includes(vu)) videoUrls.push(vu);
      }
    }
    for (const prop of ["og:audio", "og:audio:secure_url", "twitter:audio:src"]) {
      const c = $(`meta[property="${prop}"], meta[name="${prop}"]`).attr("content");
      if (c) {
        const au = new URL(c, url).toString();
        if (!audioUrls.includes(au)) audioUrls.push(au);
      }
    }
    for (const prop of ["og:image", "twitter:image"]) {
      const c = $(`meta[property="${prop}"], meta[name="${prop}"]`).attr("content");
      if (c) {
        const iu = new URL(c, url).toString();
        if (isValidMediaUrl(iu, "image") && !imageUrls.includes(iu)) imageUrls.push(iu);
      }
    }

    $("video, video source").each((_, el) => {
      const src = $(el).attr("src");
      if (src) {
        const vu = new URL(src, url).toString();
        if (!videoUrls.includes(vu)) videoUrls.push(vu);
      }
    });

    const mp4Matches = htmlText.match(/https?:\/\/[^"'\s<>\\]+\.mp4(?:\?[^"'\s<>\\]+)?/gi) || [];
    for (const m of mp4Matches) {
      const cleanV = m.replace(/\\u0026/g, "&").replace(/\\\//g, "/");
      if (isValidMediaUrl(cleanV, "video") && !videoUrls.includes(cleanV)) videoUrls.push(cleanV);
    }

    for (let i = 0; i < Math.min(videoUrls.length, 3); i++) {
      const vp = path.join(workDir, `web_video_${i}.mp4`);
      if (await downloadBinaryFile(videoUrls[i], vp, { expectedType: "video", minSize: 4096 })) {
        result.videos.push(vp);
        break;
      }
    }
    for (let i = 0; i < Math.min(audioUrls.length, 3); i++) {
      const ap = path.join(workDir, `web_audio_${i}.mp3`);
      if (await downloadBinaryFile(audioUrls[i], ap, { expectedType: "audio", minSize: 2048 })) {
        result.audios.push(ap);
        break;
      }
    }

    const dlImgs = await mapConcurrent(imageUrls.slice(0, 4), 4, async (iu, idx) => {
      const ip = path.join(workDir, `web_image_${idx}.jpg`);
      return (await downloadBinaryFile(iu, ip, { expectedType: "image", minSize: 2048 })) ? ip : null;
    });
    result.images = validateAndFilterImages(dlImgs.filter((p): p is string => Boolean(p)));
  } catch (e) {
    logger.debug(`Web scrape note: ${String(e)}`);
  }

  return result;
}
