/**
 * معالجات لوحة تحكم الأدمن (/admin):
 * - جميع أزرار Callback الخاصة بلوحة التحكم وتخصيص الـ 21 زر وقسم.
 * - إدخالات الأدمن النصية والملصقات وملفات الكوكيز والإذاعة والقنوات.
 */

import fs from "node:fs";
import {
  adminStates,
  bot,
  escapeHtml,
  formatPremiumBadge,
  InlineKeyboardMarkup,
  makeBtn,
  safeEditMessage,
  safeSendMessage,
  SmartInlineButton,
  TgCallbackQuery,
  TgMessage,
  TgMessageEntity,
  utf16Slice,
} from "../botClient.js";
import {
  COOKIES_FILE_PATH,
  CUSTOMIZABLE_UI_KEYS,
  DEFAULT_WELCOME_TEXT,
  OWNER_ID,
  PLACEMENT_LABELS,
  THEME_LABELS,
} from "../config.js";
import { db, hasCookiesFile } from "../database.js";
import { sleep } from "../network.js";
import {
  buildAdminMainKeyboard,
  buildSingleUiKeyEditor,
  buildUiCustomizationListKeyboard,
  convertTextAndEntitiesToHtml,
  getAdminDashboardText,
  sendWelcomeScreen,
} from "../ui.js";

export async function handleAdminCallback(call: TgCallbackQuery): Promise<void> {
  const user = call.from;
  const data = call.data || "";
  const msg = call.message;
  if (!msg) return;

  const chatId = msg.chat.id;
  const msgId = msg.message_id;
  const badge = formatPremiumBadge("sections", "");

  if (!db.isAdmin(user.id)) {
    await bot.answerCallbackQuery(call.id, "للمشرفين فقط.", true);
    return;
  }

  adminStates.delete(user.id);

  if (data === "admin_home") {
    await bot.answerCallbackQuery(call.id);
    await safeEditMessage(chatId, msgId, getAdminDashboardText(), {
      reply_markup: buildAdminMainKeyboard(),
    });
    return;
  }

  if (data === "adm_ui_custom_menu") {
    await bot.answerCallbackQuery(call.id);
    const text =
      `${badge}<b>تخصيص جميع الأزرار والأقسام والملصقات:</b>\n` +
      "<blockquote>" +
      "• تعديل اسم أي زر.\n" +
      "• تعديل النص والرسالة التي تظهر بداخل الزر أو القسم.\n" +
      "• إضافة ملصق (Sticker) أو إيموجي مميز مع الزر أو تركه بدون." +
      "</blockquote>\n" +
      "<b>اختر الزر أو القسم الذي تريد تعديله:</b>";
    await safeEditMessage(chatId, msgId, text, {
      reply_markup: buildUiCustomizationListKeyboard(),
    });
    return;
  }

  if (data.startsWith("adm_uikey|")) {
    await bot.answerCallbackQuery(call.id);
    const uiKey = data.slice("adm_uikey|".length);
    const { text, markup } = buildSingleUiKeyEditor(uiKey);
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data.startsWith("adm_uiedit_lbl|")) {
    await bot.answerCallbackQuery(call.id);
    const uiKey = data.slice("adm_uiedit_lbl|".length);
    const cfg = db.getUiConfig(uiKey);
    adminStates.set(user.id, { action: "ui_edit_label", ui_key: uiKey });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: `adm_uikey|${uiKey}`, style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      `<b>تعديل اسم الزر (${escapeHtml(cfg.title)}):</b>\nالاسم الحالي: <code>${escapeHtml(cfg.btn_label)}</code>\n\n<b>أرسل الآن الاسم الجديد للزر:</b>`,
      { reply_markup: markup }
    );
    return;
  }

  if (data.startsWith("adm_uiedit_both|")) {
    await bot.answerCallbackQuery(call.id);
    const uiKey = data.slice("adm_uiedit_both|".length);
    const cfg = db.getUiConfig(uiKey);
    adminStates.set(user.id, { action: "ui_edit_label_and_sticker", ui_key: uiKey, temp_label_saved: false });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: `adm_uikey|${uiKey}`, style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      `<b>تعديل اسم الزر + الملصق (${escapeHtml(cfg.title)}):</b>\n1. أرسل الآن <b>الاسم الجديد للزر</b> أولاً، وبعدها أرسل الملصق أو تخطّه:`,
      { reply_markup: markup }
    );
    return;
  }

  if (data.startsWith("adm_uiedit_cnt|")) {
    await bot.answerCallbackQuery(call.id);
    const uiKey = data.slice("adm_uiedit_cnt|".length);
    const cfg = db.getUiConfig(uiKey);
    adminStates.set(user.id, { action: "ui_edit_content", ui_key: uiKey });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: `adm_uikey|${uiKey}`, style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      `<b>تعديل النص بداخل (${escapeHtml(cfg.title)}):</b>\n<blockquote>${escapeHtml((cfg.inner_content || "").slice(0, 300))}</blockquote>\n<b>أرسل النص الجديد:</b>`,
      { reply_markup: markup }
    );
    return;
  }

  if (data.startsWith("adm_uiedit_stk|")) {
    await bot.answerCallbackQuery(call.id);
    const uiKey = data.slice("adm_uiedit_stk|".length);
    const cfg = db.getUiConfig(uiKey);
    adminStates.set(user.id, { action: "ui_edit_sticker", ui_key: uiKey });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: `adm_uikey|${uiKey}`, style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      `<b>إضافة ملصق أو إيموجي مميز لـ (${escapeHtml(cfg.title)}):</b>\nأرسل الآن <b>الملصق (Sticker)</b> أو <b>إيموجي مميز (Custom Emoji)</b>:`,
      { reply_markup: markup }
    );
    return;
  }

  if (data.startsWith("adm_uidel_stk|")) {
    const uiKey = data.slice("adm_uidel_stk|".length);
    db.updateUiConfig(uiKey, { sticker_id: "", custom_emoji_id: "", custom_emoji_char: "" });
    await bot.answerCallbackQuery(call.id, "تم حذف الملصق والإيموجي من هذا الزر.");
    const { text, markup } = buildSingleUiKeyEditor(uiKey);
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data.startsWith("adm_uireset_one|")) {
    const uiKey = data.slice("adm_uireset_one|".length);
    const defaults = CUSTOMIZABLE_UI_KEYS[uiKey];
    db.updateUiConfig(uiKey, {
      btn_label: defaults?.default_label || uiKey,
      inner_content: defaults?.default_content || "",
      sticker_id: "",
      custom_emoji_id: "",
      custom_emoji_char: "",
    });
    await bot.answerCallbackQuery(call.id, "تمت استعادة الإعدادات الافتراضية لهذا الزر.");
    const { text, markup } = buildSingleUiKeyEditor(uiKey);
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data === "adm_ui_reset_all") {
    db.resetAllUiConfigs();
    await bot.answerCallbackQuery(call.id, "تمت استعادة جميع الأزرار والأقسام للوضع الافتراضي.", true);
    await handleAdminCallback({ ...call, data: "adm_ui_custom_menu" });
    return;
  }

  if (data === "adm_close") {
    await bot.answerCallbackQuery(call.id, "تم إغلاق اللوحة.");
    await bot.deleteMessage(chatId, msgId);
    return;
  }

  if (data === "adm_clear_cache") {
    db.clearAllMediaCache();
    await bot.answerCallbackQuery(call.id, "تم مسح جميع سجلات الكاش بنجاح.", true);
    await safeEditMessage(chatId, msgId, getAdminDashboardText(), {
      reply_markup: buildAdminMainKeyboard(),
    });
    return;
  }

  if (data === "adm_toggle_bot") {
    const newVal = db.getSetting("bot_enabled", "1") === "1" ? "0" : "1";
    db.setSetting("bot_enabled", newVal);
    await bot.answerCallbackQuery(call.id, `حالة البوت: ${newVal === "1" ? "يعمل" : "صيانة"}`);
    await safeEditMessage(chatId, msgId, getAdminDashboardText(), {
      reply_markup: buildAdminMainKeyboard(),
    });
    return;
  }

  if (data === "adm_toggle_fsub") {
    const newVal = db.getSetting("force_sub_enabled", "1") === "1" ? "0" : "1";
    db.setSetting("force_sub_enabled", newVal);
    await bot.answerCallbackQuery(call.id, `الاشتراك الإجباري: ${newVal === "1" ? "مفعل" : "معطل"}`);
    await safeEditMessage(chatId, msgId, getAdminDashboardText(), {
      reply_markup: buildAdminMainKeyboard(),
    });
    return;
  }

  if (data === "adm_cookies_menu") {
    await bot.answerCallbackQuery(call.id);
    const cExists = hasCookiesFile();
    const text =
      `${badge}<b>إدارة كوكيز المنصات (Instagram & YouTube Cookies):</b>\n` +
      "<blockquote>" +
      `<b>الحالة الحالية:</b> <code>${cExists ? "مفعل ومرفوع" : "غير مرفوع (يعمل تلقائياً بدون كوكيز)"}</code>\n\n` +
      "<i>رفع ملف <code>cookies.txt</code> يفيد في فتح المنشورات المقيدة بالعمر أو الخاصة.</i>" +
      "</blockquote>";
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [
          makeBtn({ text: "رفع ملف cookies.txt", callback_data: "adm_up_cookies", style: "success", scope: "sections" }),
          makeBtn({ text: "حذف الكوكيز", callback_data: "adm_del_cookies", style: "danger", scope: "sections" }),
        ],
        [makeBtn({ text: "رجوع", callback_data: "admin_home", style: "primary", scope: "sections" })],
      ],
    };
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data === "adm_up_cookies") {
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: "upload_cookies_file" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_cookies_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      "<b>أرسل الآن ملف <code>cookies.txt</code> كمستند (Document) أو الصق نص الكوكيز بصيغة Netscape:</b>",
      { reply_markup: markup }
    );
    return;
  }

  if (data === "adm_del_cookies") {
    if (fs.existsSync(COOKIES_FILE_PATH)) {
      try {
        fs.unlinkSync(COOKIES_FILE_PATH);
      } catch {
        // ignore
      }
    }
    await bot.answerCallbackQuery(call.id, "تم حذف ملف الكوكيز.");
    await handleAdminCallback({ ...call, data: "adm_cookies_menu" });
    return;
  }

  if (data === "adm_premium_menu") {
    await bot.answerCallbackQuery(call.id);
    const currPlace = db.getSetting("premium_placement", "off");
    const startCe = db.getSetting("premium_start_emoji_id", "");
    const secCe = db.getSetting("premium_sections_emoji_id", "");
    const stickerId = db.getSetting("welcome_sticker_id", "");

    const text =
      `${badge}<b>إعدادات الملصقات والمميز العام (اختياري):</b>\n` +
      "<blockquote>" +
      `الظهور العام: ${escapeHtml(PLACEMENT_LABELS[currPlace] || currPlace)}\n` +
      `إيموجي البداية: <code>${startCe ? "مضاف" : "غير مضاف"}</code>\n` +
      `إيموجي الأقسام: <code>${secCe ? "مضاف" : "غير مضاف"}</code>\n` +
      `الملصق الترحيبي: <code>${stickerId ? "مضاف" : "غير مضاف"}</code>` +
      "</blockquote>";

    const placeBtns: SmartInlineButton[] = Object.entries(PLACEMENT_LABELS).map(([pKey, pLabel]) => {
      const check = currPlace === pKey ? "[محدد] " : "";
      return makeBtn({
        text: `${check}${pLabel}`,
        callback_data: `adm_set_place|${pKey}`,
        style: currPlace === pKey ? "success" : "primary",
        scope: "sections",
      });
    });

    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [placeBtns[0], placeBtns[1]],
        [placeBtns[2], placeBtns[3]],
        [
          makeBtn({ text: "إضافة ملصق/مميز للبداية", callback_data: "adm_add_prem|start", style: "primary", scope: "sections" }),
          makeBtn({ text: "إضافة ملصق/مميز للأقسام", callback_data: "adm_add_prem|sections", style: "primary", scope: "sections" }),
        ],
        [
          makeBtn({ text: "إضافة للكل", callback_data: "adm_add_prem|both", style: "success", scope: "sections" }),
          makeBtn({ text: "مسح جميع الملصقات والمميز", callback_data: "adm_clear_prem", style: "danger", scope: "sections" }),
        ],
        [makeBtn({ text: "رجوع", callback_data: "admin_home", style: "danger", scope: "sections" })],
      ],
    };
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data.startsWith("adm_set_place|")) {
    const newPlace = data.split("|")[1] || "off";
    db.setSetting("premium_placement", newPlace);
    await bot.answerCallbackQuery(call.id, `تم التحديد: ${PLACEMENT_LABELS[newPlace] || newPlace}`);
    await handleAdminCallback({ ...call, data: "adm_premium_menu" });
    return;
  }

  if (data.startsWith("adm_add_prem|")) {
    await bot.answerCallbackQuery(call.id);
    const scopeChoice = data.split("|")[1] || "both";
    const actionMap: Record<string, string> = {
      start: "set_premium_start",
      sections: "set_premium_sections",
      both: "set_premium_both",
    };
    adminStates.set(user.id, { action: actionMap[scopeChoice] || "set_premium_both" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_premium_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      "<b>أرسل الآن الملصق (Sticker) أو الإيموجي المميز (Custom Emoji):</b>",
      { reply_markup: markup }
    );
    return;
  }

  if (data === "adm_clear_prem") {
    for (const k of [
      "welcome_sticker_id",
      "premium_start_emoji_id",
      "premium_start_emoji_char",
      "premium_sections_emoji_id",
      "premium_sections_emoji_char",
    ]) {
      db.setSetting(k, "");
    }
    db.setSetting("premium_placement", "off");
    await bot.answerCallbackQuery(call.id, "تم مسح الملصقات والمميز العام بالكامل.");
    await handleAdminCallback({ ...call, data: "adm_premium_menu" });
    return;
  }

  if (data === "adm_colors_menu") {
    await bot.answerCallbackQuery(call.id);
    const currTheme = db.getSetting("color_theme", "mixed");
    const text = `<b>ثيم ألوان الأزرار والأقسام:</b>\n<blockquote>النمط الحالي: ${escapeHtml(THEME_LABELS[currTheme] || currTheme)}</blockquote>`;
    const themeBtns: SmartInlineButton[] = Object.entries(THEME_LABELS).map(([tKey, tLabel]) => {
      const check = currTheme === tKey ? "[محدد] " : "";
      const stylePreview: "primary" | "success" | "danger" =
        tKey === "primary" || tKey === "success" || tKey === "danger"
          ? tKey
          : currTheme === tKey
          ? "success"
          : "primary";
      return {
        text: `${check}${tLabel}`,
        callback_data: `adm_set_theme|${tKey}`,
        style: stylePreview,
      };
    });

    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [themeBtns[0], themeBtns[1]],
        [themeBtns[2], themeBtns[3]],
        [themeBtns[4], makeBtn({ text: "رجوع", callback_data: "admin_home", style: "danger", scope: "sections" })],
      ],
    };
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data.startsWith("adm_set_theme|")) {
    const newTheme = data.split("|")[1] || "mixed";
    db.setSetting("color_theme", newTheme);
    await bot.answerCallbackQuery(call.id, `تم التفعيل: ${THEME_LABELS[newTheme] || newTheme}`);
    await handleAdminCallback({ ...call, data: "adm_colors_menu" });
    return;
  }

  if (data === "adm_stats") {
    await bot.answerCallbackQuery(call.id);
    const stats = db.getDashboardStats();
    const recentUsers = db.getRecentUsers(5);

    const recentLines = recentUsers.map((ru, idx) => {
      const uname = ru.username ? `(@${escapeHtml(ru.username)})` : "";
      return `${idx + 1}. ${escapeHtml((ru.first_name || "مستخدم").slice(0, 18))} ${uname}`;
    });
    const recentText = recentLines.length ? `${recentLines.join("\n")}\n` : "لا يوجد مشتركين بعد.\n";

    const statsMsg =
      `${badge}<b>إحصائيات المشتركين:</b>\n` +
      "<blockquote>" +
      `إجمالي المشتركين: <code>${stats.total_users}</code>\n` +
      `نشط للإذاعة: <code>${stats.total_users - stats.banned_users}</code> | محظور: <code>${stats.banned_users}</code>\n` +
      `الكاش: <code>${stats.cached_items}</code>` +
      "</blockquote>\n" +
      `<b>أحدث المشتركين المنضمين:</b>\n<blockquote>${recentText}</blockquote>`;

    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "admin_home", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(chatId, msgId, statsMsg, { reply_markup: markup });
    return;
  }

  if (data === "adm_fsub_menu") {
    await bot.answerCallbackQuery(call.id);
    const channels = db.getForceChannels();
    let text = `${badge}<b>قنوات الاشتراك الإجباري:</b>\n<blockquote>`;
    const rows: SmartInlineButton[][] = [];

    if (!channels.length) {
      text += "لا توجد قنوات مضافة.</blockquote>";
    } else {
      const botId = await bot.getBotId();
      const delBtns: SmartInlineButton[] = [];
      for (const ch of channels) {
        const cIdStr = String(ch.chat_id);
        const shortTitle = (ch.title || "قناة").slice(0, 16);
        let statusNote = "";
        if (botId) {
          try {
            const bm = await bot.getChatMember(cIdStr, botId);
            if (bm.status === "administrator" || bm.status === "creator") {
              statusNote = " (البوت مشرف - مفعل)";
              db.clearInaccessibleChannel(cIdStr);
            } else {
              statusNote = " (البوت ليس مشرفاً - ارفعه مشرفاً!)";
            }
          } catch {
            statusNote = " (تعذر الوصول - ارفع البوت مشرفاً!)";
          }
        }
        text += `• <b>${escapeHtml(ch.title)}</b> <code>${escapeHtml(cIdStr)}</code>${statusNote}\n`;
        delBtns.push(
          makeBtn({
            text: `حذف: ${shortTitle}`,
            callback_data: `adm_del_ch|${ch.chat_id}`,
            style: "danger",
            scope: "sections",
          })
        );
      }
      text += "</blockquote>";
      for (let i = 0; i < delBtns.length; i += 2) {
        rows.push(delBtns.slice(i, i + 2));
      }
    }

    rows.push([
      makeBtn({ text: "إضافة قناة", callback_data: "adm_add_ch", style: "success", scope: "sections" }),
      makeBtn({ text: "مسح الكل", callback_data: "adm_clear_chs", style: "danger", scope: "sections" }),
    ]);
    rows.push([makeBtn({ text: "رجوع", callback_data: "admin_home", style: "primary", scope: "sections" })]);

    await safeEditMessage(chatId, msgId, text, { reply_markup: { inline_keyboard: rows } });
    return;
  }

  if (data === "adm_add_ch") {
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: "add_force_channel" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_fsub_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      "<b>ارفع البوت مشرفاً في القناة ثم أرسل معرفها (<code>@Ch</code>) أو وجّه منشوراً منها:</b>",
      { reply_markup: markup }
    );
    return;
  }

  if (data.startsWith("adm_del_ch|")) {
    const chId = data.slice("adm_del_ch|".length);
    db.clearInaccessibleChannel(chId);
    db.deleteForceChannel(chId);
    await bot.answerCallbackQuery(call.id, "تم حذف القناة.");
    await handleAdminCallback({ ...call, data: "adm_fsub_menu" });
    return;
  }

  if (data === "adm_clear_chs") {
    db.clearInaccessibleChannel(null);
    db.clearForceChannels();
    await bot.answerCallbackQuery(call.id, "تم مسح القنوات.");
    await handleAdminCallback({ ...call, data: "adm_fsub_menu" });
    return;
  }

  if (data === "adm_welcome_menu") {
    await bot.answerCallbackQuery(call.id);
    const currWelcome = db.getSetting("welcome_text", DEFAULT_WELCOME_TEXT);
    const text = `${badge}<b>رسالة البداية (/start):</b>\n<blockquote>${escapeHtml(currWelcome.slice(0, 250))}</blockquote>`;
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [
          makeBtn({ text: "تعديل النص", callback_data: "adm_edit_welcome", style: "primary", scope: "sections" }),
          makeBtn({ text: "معاينة", callback_data: "adm_preview_welcome", style: "success", scope: "sections" }),
        ],
        [
          makeBtn({ text: "استعادة الافتراضي", callback_data: "adm_reset_welcome", style: "primary", scope: "sections" }),
          makeBtn({ text: "رجوع", callback_data: "admin_home", style: "danger", scope: "sections" }),
        ],
      ],
    };
    await safeEditMessage(chatId, msgId, text, { reply_markup: markup });
    return;
  }

  if (data === "adm_edit_welcome") {
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: "set_welcome_text" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_welcome_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(
      chatId,
      msgId,
      "<b>أرسل نص الترحيب الجديد (يدعم الإيموجي المميز وكلمة <code>@البوت</code>):</b>",
      { reply_markup: markup }
    );
    return;
  }

  if (data === "adm_reset_welcome") {
    db.setSetting("welcome_text", DEFAULT_WELCOME_TEXT);
    db.setSetting("welcome_entities", "[]");
    await bot.answerCallbackQuery(call.id, "تمت استعادة الترحيب الافتراضي.");
    await handleAdminCallback({ ...call, data: "adm_welcome_menu" });
    return;
  }

  if (data === "adm_preview_welcome") {
    await bot.answerCallbackQuery(call.id, "جاري إرسال المعاينة...");
    await sendWelcomeScreen(chatId, user);
    return;
  }

  if (data === "adm_broadcast_menu") {
    await bot.answerCallbackQuery(call.id);
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [
          makeBtn({ text: "إذاعة نسخ", callback_data: "adm_bc_copy", style: "primary", scope: "sections" }),
          makeBtn({ text: "إذاعة توجيه", callback_data: "adm_bc_forward", style: "success", scope: "sections" }),
        ],
        [makeBtn({ text: "رجوع", callback_data: "admin_home", style: "danger", scope: "sections" })],
      ],
    };
    await safeEditMessage(
      chatId,
      msgId,
      `${badge}<b>قسم الإذاعة:</b>\n<blockquote>اختر طريقة الإرسال لجميع المشتركين:</blockquote>`,
      { reply_markup: markup }
    );
    return;
  }

  if (data === "adm_bc_copy" || data === "adm_bc_forward") {
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: data === "adm_bc_copy" ? "broadcast_copy" : "broadcast_forward" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_broadcast_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(chatId, msgId, "<b>أرسل الرسالة أو المنشور المراد إذاعته الآن:</b>", {
      reply_markup: markup,
    });
    return;
  }

  if (data === "adm_ban_menu") {
    await bot.answerCallbackQuery(call.id);
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [
        [
          makeBtn({ text: "حظر عضو", callback_data: "adm_do_ban", style: "danger", scope: "sections" }),
          makeBtn({ text: "فك حظر", callback_data: "adm_do_unban", style: "success", scope: "sections" }),
        ],
        [makeBtn({ text: "رجوع", callback_data: "admin_home", style: "primary", scope: "sections" })],
      ],
    };
    await safeEditMessage(chatId, msgId, `${badge}<b>إدارة الحظر:</b>`, { reply_markup: markup });
    return;
  }

  if (data === "adm_do_ban" || data === "adm_do_unban") {
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: data === "adm_do_ban" ? "ban_user" : "unban_user" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_ban_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(chatId, msgId, "<b>أرسل الآيدي الرقمي (ID) للمستخدم:</b>", { reply_markup: markup });
    return;
  }

  if (data === "adm_admins_menu") {
    await bot.answerCallbackQuery(call.id);
    const adms = db.getAdmins();
    let text = `${badge}<b>المشرفين:</b>\n<blockquote>`;
    const rows: SmartInlineButton[][] = [];
    const delBtns: SmartInlineButton[] = [];

    for (const a of adms) {
      const aid = Number(a.user_id);
      const role = aid === OWNER_ID ? "مالك" : "مشرف";
      text += `• <code>${aid}</code> (${role})\n`;
      if (aid !== OWNER_ID && user.id === OWNER_ID) {
        delBtns.push(
          makeBtn({ text: `حذف ${aid}`, callback_data: `adm_del_adm|${aid}`, style: "danger", scope: "sections" })
        );
      }
    }
    text += "</blockquote>";

    for (let i = 0; i < delBtns.length; i += 2) {
      rows.push(delBtns.slice(i, i + 2));
    }

    if (user.id === OWNER_ID) {
      rows.push([
        makeBtn({ text: "إضافة مشرف", callback_data: "adm_add_adm", style: "success", scope: "sections" }),
        makeBtn({ text: "رجوع", callback_data: "admin_home", style: "primary", scope: "sections" }),
      ]);
    } else {
      rows.push([makeBtn({ text: "رجوع", callback_data: "admin_home", style: "primary", scope: "sections" })]);
    }

    await safeEditMessage(chatId, msgId, text, { reply_markup: { inline_keyboard: rows } });
    return;
  }

  if (data === "adm_add_adm") {
    if (user.id !== OWNER_ID) {
      await bot.answerCallbackQuery(call.id, "للمالك الأساسي فقط.", true);
      return;
    }
    await bot.answerCallbackQuery(call.id);
    adminStates.set(user.id, { action: "add_new_admin" });
    const markup: InlineKeyboardMarkup = {
      inline_keyboard: [[makeBtn({ text: "رجوع", callback_data: "adm_admins_menu", style: "danger", scope: "sections" })]],
    };
    await safeEditMessage(chatId, msgId, "<b>أرسل الآيدي الرقمي (ID) للمشرف الجديد:</b>", {
      reply_markup: markup,
    });
    return;
  }

  if (data.startsWith("adm_del_adm|")) {
    if (user.id !== OWNER_ID) {
      await bot.answerCallbackQuery(call.id, "للمالك الأساسي فقط.", true);
      return;
    }
    const targetAid = Number.parseInt(data.split("|")[1] || "", 10);
    if (Number.isFinite(targetAid)) {
      db.removeAdmin(targetAid);
    }
    await bot.answerCallbackQuery(call.id, "تمت إزالة المشرف.");
    await handleAdminCallback({ ...call, data: "adm_admins_menu" });
  }
}

export async function handleAdminStateInput(message: TgMessage): Promise<boolean> {
  const user = message.from;
  if (!user || !adminStates.has(user.id)) return false;

  const userId = user.id;
  if (!db.isAdmin(userId)) {
    adminStates.delete(userId);
    return false;
  }

  const stateInfo = adminStates.get(userId);
  if (!stateInfo) return false;
  const action = stateInfo.action;

  if (message.text && ["/cancel", "الغاء", "إلغاء"].includes(message.text.trim())) {
    adminStates.delete(userId);
    await safeSendMessage(message.chat.id, "<b>تم الإلغاء والعودة للوحة التحكم.</b>", {
      reply_markup: buildAdminMainKeyboard(),
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  if (action === "ui_edit_label" && stateInfo.ui_key) {
    const uiKey = stateInfo.ui_key;
    if (!message.text) {
      await safeSendMessage(message.chat.id, "يرجى إرسال الاسم الجديد للزر كنص.");
      return true;
    }
    const newLbl = message.text.trim().slice(0, 60);
    let foundCeId: string | undefined;
    let foundChar = "";
    for (const ent of message.entities || []) {
      if (ent.type === "custom_emoji" && ent.custom_emoji_id) {
        foundCeId = ent.custom_emoji_id;
        foundChar = utf16Slice(message.text, ent.offset, ent.length);
        break;
      }
    }
    if (foundCeId) {
      db.updateUiConfig(uiKey, { btn_label: newLbl, custom_emoji_id: foundCeId, custom_emoji_char: foundChar });
    } else {
      db.updateUiConfig(uiKey, { btn_label: newLbl });
    }
    adminStates.delete(userId);
    const { text, markup } = buildSingleUiKeyEditor(uiKey);
    await safeSendMessage(
      message.chat.id,
      `<b>تم تحديث اسم الزر بنجاح إلى:</b> <code>${escapeHtml(newLbl)}</code>\n\n${text}`,
      { reply_markup: markup, reply_to_message_id: message.message_id }
    );
    return true;
  }

  if (action === "ui_edit_label_and_sticker" && stateInfo.ui_key) {
    const uiKey = stateInfo.ui_key;
    if (message.text && !stateInfo.temp_label_saved) {
      const newLbl = message.text.trim().slice(0, 60);
      db.updateUiConfig(uiKey, { btn_label: newLbl });
      stateInfo.temp_label_saved = true;
      await safeSendMessage(
        message.chat.id,
        `<b>تم حفظ اسم الزر:</b> <code>${escapeHtml(newLbl)}</code>\nالآن أرسل <b>الملصق</b> أو <b>الإيموجي المميز</b>، أو أرسل <code>تخطي</code>:`,
        { reply_to_message_id: message.message_id }
      );
      return true;
    }
    if (message.text && ["تخطي", "بدون", "لا", "skip"].includes(message.text.trim())) {
      adminStates.delete(userId);
      const { text, markup } = buildSingleUiKeyEditor(uiKey);
      await safeSendMessage(message.chat.id, `<b>تم الحفظ بدون إضافة ملصق.</b>\n\n${text}`, {
        reply_markup: markup,
        reply_to_message_id: message.message_id,
      });
      return true;
    }
    if (message.sticker) {
      const stId = message.sticker.file_id;
      const ceId = message.sticker.custom_emoji_id || "";
      const ceCh = message.sticker.emoji || "";
      db.updateUiConfig(uiKey, {
        sticker_id: stId,
        ...(ceId ? { custom_emoji_id: ceId, custom_emoji_char: ceCh } : {}),
      });
      adminStates.delete(userId);
      const { text, markup } = buildSingleUiKeyEditor(uiKey);
      await safeSendMessage(message.chat.id, `<b>تم حفظ الملصق مع الزر بنجاح.</b>\n\n${text}`, {
        reply_markup: markup,
        reply_to_message_id: message.message_id,
      });
      return true;
    }
    if (message.text && message.entities) {
      for (const ent of message.entities) {
        if (ent.type === "custom_emoji" && ent.custom_emoji_id) {
          db.updateUiConfig(uiKey, {
            custom_emoji_id: ent.custom_emoji_id,
            custom_emoji_char: utf16Slice(message.text, ent.offset, ent.length),
          });
          adminStates.delete(userId);
          const { text, markup } = buildSingleUiKeyEditor(uiKey);
          await safeSendMessage(message.chat.id, `<b>تم حفظ الإيموجي المميز للزر بنجاح.</b>\n\n${text}`, {
            reply_markup: markup,
            reply_to_message_id: message.message_id,
          });
          return true;
        }
      }
    }
    await safeSendMessage(
      message.chat.id,
      "أرسل الملصق/الإيموجي المميز، أو أرسل <code>تخطي</code> أو <code>إلغاء</code>.",
      { reply_to_message_id: message.message_id }
    );
    return true;
  }

  if (action === "ui_edit_content" && stateInfo.ui_key) {
    const uiKey = stateInfo.ui_key;
    if (!message.text) {
      await safeSendMessage(message.chat.id, "يرجى إرسال النص الجديد.");
      return true;
    }
    const entitiesList: TgMessageEntity[] = (message.entities || []).map((ent) => ({
      type: ent.type,
      offset: ent.offset,
      length: ent.length,
      url: ent.url,
      language: ent.language,
      custom_emoji_id: ent.custom_emoji_id,
    }));
    const htmlContent = entitiesList.length
      ? convertTextAndEntitiesToHtml(message.text, entitiesList)
      : message.text;
    db.updateUiConfig(uiKey, { inner_content: htmlContent });
    adminStates.delete(userId);
    const { text, markup } = buildSingleUiKeyEditor(uiKey);
    await safeSendMessage(message.chat.id, `<b>تم تحديث النص الداخلي بنجاح.</b>\n\n${text}`, {
      reply_markup: markup,
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  if (action === "ui_edit_sticker" && stateInfo.ui_key) {
    const uiKey = stateInfo.ui_key;
    if (message.sticker) {
      const stId = message.sticker.file_id;
      const ceId = message.sticker.custom_emoji_id || "";
      const ceCh = message.sticker.emoji || "";
      db.updateUiConfig(uiKey, {
        sticker_id: stId,
        ...(ceId ? { custom_emoji_id: ceId, custom_emoji_char: ceCh } : {}),
      });
      adminStates.delete(userId);
      const { text, markup } = buildSingleUiKeyEditor(uiKey);
      await safeSendMessage(message.chat.id, `<b>تم إرفاق الملصق بنجاح.</b>\n\n${text}`, {
        reply_markup: markup,
        reply_to_message_id: message.message_id,
      });
      return true;
    }
    if (message.text && message.entities) {
      for (const ent of message.entities) {
        if (ent.type === "custom_emoji" && ent.custom_emoji_id) {
          db.updateUiConfig(uiKey, {
            custom_emoji_id: ent.custom_emoji_id,
            custom_emoji_char: utf16Slice(message.text, ent.offset, ent.length),
          });
          adminStates.delete(userId);
          const { text, markup } = buildSingleUiKeyEditor(uiKey);
          await safeSendMessage(message.chat.id, `<b>تم إرفاق الإيموجي المميز بنجاح.</b>\n\n${text}`, {
            reply_markup: markup,
            reply_to_message_id: message.message_id,
          });
          return true;
        }
      }
    }
    await safeSendMessage(message.chat.id, "يرجى إرسال ملصق أو إيموجي مميز، أو أرسل <code>إلغاء</code>.", {
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  if (action === "set_welcome_text") {
    if (!message.text) {
      await safeSendMessage(message.chat.id, "يرجى إرسال نص رسالة الترحيب.");
      return true;
    }
    const entitiesList = (message.entities || []).map((ent) => ({
      type: ent.type,
      offset: ent.offset,
      length: ent.length,
      url: ent.url,
      language: ent.language,
      custom_emoji_id: ent.custom_emoji_id,
    }));
    db.setSetting("welcome_text", message.text);
    db.setSetting("welcome_entities", JSON.stringify(entitiesList));
    adminStates.delete(userId);
    await safeSendMessage(message.chat.id, "<b>تم تحديث رسالة البداية (/start) بنجاح.</b>", {
      reply_markup: buildAdminMainKeyboard(),
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  if (action === "upload_cookies_file") {
    if (message.document) {
      try {
        const downloaded = await bot.downloadTelegramFile(message.document.file_id);
        fs.writeFileSync(COOKIES_FILE_PATH, downloaded);
        adminStates.delete(userId);
        await safeSendMessage(message.chat.id, "<b>تم حفظ وتفعيل ملف الكوكيز (cookies.txt) بنجاح.</b>", {
          reply_markup: buildAdminMainKeyboard(),
          reply_to_message_id: message.message_id,
        });
        return true;
      } catch (e) {
        await safeSendMessage(message.chat.id, `خطأ أثناء حفظ الملف: <code>${escapeHtml(e)}</code>`);
        return true;
      }
    }
    if (
      message.text &&
      (message.text.includes("# Netscape HTTP Cookie File") ||
        message.text.includes("instagram.com") ||
        message.text.includes("youtube.com") ||
        message.text.includes("tiktok.com"))
    ) {
      fs.writeFileSync(COOKIES_FILE_PATH, message.text, "utf8");
      adminStates.delete(userId);
      await safeSendMessage(message.chat.id, "<b>تم حفظ نص الكوكيز بنجاح.</b>", {
        reply_markup: buildAdminMainKeyboard(),
        reply_to_message_id: message.message_id,
      });
      return true;
    }
    await safeSendMessage(
      message.chat.id,
      "<b>أرسل ملف <code>cookies.txt</code> كمستند أو الصق نص الكوكيز، أو أرسل <code>إلغاء</code>.</b>",
      { reply_to_message_id: message.message_id }
    );
    return true;
  }

  if (action === "set_premium_start" || action === "set_premium_sections" || action === "set_premium_both") {
    const targetScope =
      action === "set_premium_start" ? "start" : action === "set_premium_sections" ? "sections" : "both";
    if (message.sticker) {
      const fileId = message.sticker.file_id;
      const ceId = message.sticker.custom_emoji_id || "";
      const emojiCh = message.sticker.emoji || "";
      if (targetScope === "start" || targetScope === "both") {
        db.setSetting("welcome_sticker_id", fileId);
        if (ceId) {
          db.setSetting("premium_start_emoji_id", ceId);
          db.setSetting("premium_start_emoji_char", emojiCh);
        }
      }
      if ((targetScope === "sections" || targetScope === "both") && ceId) {
        db.setSetting("premium_sections_emoji_id", ceId);
        db.setSetting("premium_sections_emoji_char", emojiCh);
      }
      if (db.getSetting("premium_placement", "off") === "off") {
        db.setSetting(
          "premium_placement",
          targetScope === "both" ? "both" : targetScope === "start" ? "start_only" : "sections_only"
        );
      }
      adminStates.delete(userId);
      await safeSendMessage(message.chat.id, "<b>تم حفظ الملصق بنجاح.</b>", {
        reply_markup: buildAdminMainKeyboard(),
        reply_to_message_id: message.message_id,
      });
      return true;
    }
    if (message.text && message.entities) {
      for (const ent of message.entities) {
        if (ent.type === "custom_emoji" && ent.custom_emoji_id) {
          const foundCeId = ent.custom_emoji_id;
          const foundChar = utf16Slice(message.text, ent.offset, ent.length);
          if (targetScope === "start" || targetScope === "both") {
            db.setSetting("premium_start_emoji_id", foundCeId);
            db.setSetting("premium_start_emoji_char", foundChar);
          }
          if (targetScope === "sections" || targetScope === "both") {
            db.setSetting("premium_sections_emoji_id", foundCeId);
            db.setSetting("premium_sections_emoji_char", foundChar);
          }
          if (db.getSetting("premium_placement", "off") === "off") {
            db.setSetting(
              "premium_placement",
              targetScope === "both" ? "both" : targetScope === "start" ? "start_only" : "sections_only"
            );
          }
          adminStates.delete(userId);
          await safeSendMessage(
            message.chat.id,
            `<b>تم تفعيل الإيموجي المميز بنجاح:</b>\n<code>${escapeHtml(foundCeId)}</code>`,
            { reply_markup: buildAdminMainKeyboard(), reply_to_message_id: message.message_id }
          );
          return true;
        }
      }
    }
    await safeSendMessage(message.chat.id, "<b>أرسل إيموجي مميز أو ملصق، أو أرسل <code>إلغاء</code>.</b>", {
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  if (action === "add_force_channel") {
    let chatIdStr: string | null = null;
    let titleStr = "قناة البوت";
    let inviteLinkStr = "https://t.me/";

    if (
      message.forward_from_chat &&
      (message.forward_from_chat.type === "channel" || message.forward_from_chat.type === "supergroup")
    ) {
      const fChat = message.forward_from_chat;
      chatIdStr = String(fChat.id);
      titleStr = fChat.title || "قناة البوت";
      if (fChat.username) {
        inviteLinkStr = `https://t.me/${fChat.username}`;
      } else {
        try {
          inviteLinkStr = await bot.exportChatInviteLink(fChat.id);
        } catch {
          inviteLinkStr = "https://t.me/";
        }
      }
    } else if (message.text) {
      const parts = message.text.trim().split(/\s+/);
      let target = parts[0] || "";
      if (target.startsWith("https://t.me/")) {
        const uname = target.replace("https://t.me/", "").replace(/^\/+|\/+$/g, "");
        if (!uname.startsWith("+")) target = `@${uname}`;
      }
      try {
        const chatInfo = await bot.getChat(target);
        chatIdStr = String(chatInfo.id);
        titleStr = chatInfo.title || target;
        if (parts[1]?.startsWith("http")) {
          inviteLinkStr = parts[1];
        } else if (chatInfo.username) {
          inviteLinkStr = `https://t.me/${chatInfo.username}`;
        } else if (chatInfo.invite_link) {
          inviteLinkStr = chatInfo.invite_link;
        } else {
          inviteLinkStr = await bot.exportChatInviteLink(chatInfo.id);
        }
      } catch (e) {
        await safeSendMessage(
          message.chat.id,
          `<b>تعذر الوصول للقناة:</b> <code>${escapeHtml(e)}</code>\nتأكد من رفع البوت مشرفاً في القناة.`,
          { reply_to_message_id: message.message_id }
        );
        return true;
      }
    }

    if (chatIdStr) {
      const botId = await bot.getBotId();
      if (botId) {
        try {
          const botMember = await bot.getChatMember(chatIdStr, botId);
          if (botMember.status !== "administrator" && botMember.status !== "creator") {
            await safeSendMessage(
              message.chat.id,
              `<b>تنبيه:</b> البوت ليس مشرفاً في قناة <b>${escapeHtml(titleStr)}</b>. ارفعه مشرفاً أولاً.`,
              { reply_to_message_id: message.message_id }
            );
            return true;
          }
        } catch (e) {
          await safeSendMessage(
            message.chat.id,
            `<b>تنبيه:</b> لم يتمكن البوت من التحقق من صلاحيات الإشراف (<code>${escapeHtml(e)}</code>).`,
            { reply_to_message_id: message.message_id }
          );
          return true;
        }
      }

      db.clearInaccessibleChannel(chatIdStr);
      db.upsertForceChannel(chatIdStr, titleStr, inviteLinkStr);
      adminStates.delete(userId);
      await safeSendMessage(message.chat.id, `<b>تمت إضافة القناة بنجاح:</b> ${escapeHtml(titleStr)}`, {
        reply_markup: buildAdminMainKeyboard(),
        reply_to_message_id: message.message_id,
      });
    }
    return true;
  }

  if (action === "broadcast_copy" || action === "broadcast_forward") {
    adminStates.delete(userId);
    const userIds = db.getAllUserIds();
    const statusMsg = await safeSendMessage(
      message.chat.id,
      `<b>جاري الإذاعة إلى <code>${userIds.length}</code> مستخدم...</b>`,
      { reply_to_message_id: message.message_id }
    );

    // تشغيل الإذاعة في الخلفية بدون حجب الرسائل الأخرى
    (async () => {
      let sent = 0;
      let failed = 0;
      for (const uid of userIds) {
        try {
          if (action === "broadcast_forward") {
            await bot.forwardMessage(uid, message.chat.id, message.message_id);
          } else {
            await bot.copyMessage(uid, message.chat.id, message.message_id);
          }
          sent += 1;
          await sleep(40);
        } catch {
          failed += 1;
        }
      }
      if (statusMsg) {
        await safeEditMessage(
          message.chat.id,
          statusMsg.message_id,
          `<b>اكتملت الإذاعة</b> (تم: <code>${sent}</code> | فشل: <code>${failed}</code>)`,
          { reply_markup: buildAdminMainKeyboard() }
        );
      }
    })().catch(() => {});

    return true;
  }

  if (action === "ban_user" || action === "unban_user") {
    if (!message.text || !/^\d+$/.test(message.text.trim())) {
      await safeSendMessage(message.chat.id, "يرجى إرسال الآيدي الرقمي (ID) للمستخدم.");
      return true;
    }
    const targetUid = Number.parseInt(message.text.trim(), 10);
    const isBan = action === "ban_user";
    db.setUserBanned(targetUid, isBan);
    adminStates.delete(userId);
    await safeSendMessage(
      message.chat.id,
      `تم <b>${isBan ? "حظر" : "فك حظر"}</b> المستخدم <code>${targetUid}</code>.`,
      { reply_markup: buildAdminMainKeyboard(), reply_to_message_id: message.message_id }
    );
    return true;
  }

  if (action === "add_new_admin") {
    if (!message.text || !/^\d+$/.test(message.text.trim())) {
      await safeSendMessage(message.chat.id, "يرجى إرسال الآيدي الرقمي (ID) للمشرف الجديد.");
      return true;
    }
    const newAdmId = Number.parseInt(message.text.trim(), 10);
    db.addAdmin(newAdmId, userId);
    adminStates.delete(userId);
    await safeSendMessage(message.chat.id, `تمت ترقية <code>${newAdmId}</code> إلى مشرف بنجاح.`, {
      reply_markup: buildAdminMainKeyboard(),
      reply_to_message_id: message.message_id,
    });
    return true;
  }

  return false;
}
