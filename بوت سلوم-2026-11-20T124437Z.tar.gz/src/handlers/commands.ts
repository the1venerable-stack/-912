/**
 * معالجات الأوامر الأساسية (/start و /admin و /panel).
 */

import {
  adminStates,
  safeSendMessage,
  sendForceSubPrompt,
  TgMessage,
} from "../botClient.js";
import { db } from "../database.js";
import {
  buildAdminMainKeyboard,
  getAdminDashboardText,
  sendWelcomeScreen,
} from "../ui.js";

export async function handleStartCommand(message: TgMessage): Promise<void> {
  const user = message.from;
  if (!user) return;
  db.registerUser(user);

  if (db.isUserBanned(user.id)) {
    await safeSendMessage(message.chat.id, "عذراً، لقد تم حظرك من استخدام البوت.", {
      reply_to_message_id: message.message_id,
    });
    return;
  }

  if (db.getSetting("bot_enabled", "1") !== "1" && !db.isAdmin(user.id)) {
    await safeSendMessage(message.chat.id, "البوت في وضع الصيانة حالياً، يرجى المحاولة لاحقاً.", {
      reply_to_message_id: message.message_id,
    });
    return;
  }

  if (!(await sendForceSubPrompt(message.chat.id, user, message.message_id))) {
    return;
  }

  await sendWelcomeScreen(message.chat.id, user, message.message_id);
}

export async function handleAdminCommand(message: TgMessage): Promise<void> {
  const user = message.from;
  if (!user) return;
  db.registerUser(user);

  if (!db.isAdmin(user.id)) {
    await safeSendMessage(message.chat.id, "هذا الأمر مخصص لإدارة البوت فقط.", {
      reply_to_message_id: message.message_id,
    });
    return;
  }

  adminStates.delete(user.id);
  await safeSendMessage(message.chat.id, getAdminDashboardText(), {
    reply_markup: buildAdminMainKeyboard(),
    parse_mode: "HTML",
    reply_to_message_id: message.message_id,
  });
}
