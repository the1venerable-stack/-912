/**
 * معالجات التحميل المباشر، البحث في يوتيوب، المجموعات، الوضع الضمني، وتحويل الصوت.
 * - متطابقة بالكامل مع سلوك النسخة الأصلية مع معالجة غير متزامنة سريعة عبر Semaphore.
 */

import fs from "node:fs";
import path from "node:path";
import {
  bot,
  checkUserSubscription,
  escapeHtml,
  formatPremiumBadge,
  InlineKeyboardMarkup,
  makeBtn,
  safeEditMessage,
  safeSendMessage,
  sendForceSubPrompt,
  sendUiOptionalSticker,
  SmartInlineButton,
  stripAdvancedButtonFields,
  TgCallbackQuery,
  TgInlineQuery,
  TgMessage,
  TgUser,
} from "../botClient.js";
import {
  DEFAULT_HELP_GUIDE_TEXT,
  DEFAULT_SEARCH_HINT_TEXT,
  DOWNLOAD_DIR,
  MAX_CONCURRENT_DOWNLOADS,
} from "../config.js";
import { db } from "../database.js";
import {
  detectPlatformInfo,
  downloadMediaPipeline,
  extractAllUrls,
  extractFirstUrl,
  normalizeCacheUrl,
} from "../downloaders/index.js";
import { cleanInstagramAuthor } from "../downloaders/instagram.js";
import { extractYouTubeSearchQuery, searchYouTubeTop5, YouTubeSearchItem } from "../downloaders/youtube.js";
import { cleanupFiles, getVideoStreamInfo, purgeStaleTempFiles } from "../mediaUtils.js";
import { AsyncSemaphore, logger } from "../network.js";
import { formatMediaCaptionWithDescription, sendWelcomeScreen } from "../ui.js";
import { handleAdminCallback } from "./admin.js";

const downloadSemaphore = new AsyncSemaphore(MAX_CONCURRENT_DOWNLOADS);

export function executeDownloadAndSend(params: {
  chatId: number;
  urlOrQuery: string;
  mode: "video" | "voice" | "mp3";
  statusMsgId?: number | null;
  replyToMsgId?: number | null;
  reqId?: string | null;
  isSearch?: boolean;
  voiceOnlyButton?: boolean;
}): void {
  downloadSemaphore
    .run(() => executeDownloadAndSendInner(params))
    .catch(async (err) => {
      logger.error(`Unhandled download worker error: ${String(err)}`);
      if (params.statusMsgId) {
        await safeEditMessage(
          params.chatId,
          params.statusMsgId,
          `<b>تعذر التحميل حالياً:</b>\n<code>${escapeHtml(String(err).slice(0, 160))}</code>`,
          { parse_mode: "HTML" }
        );
      }
    });
}

async function executeDownloadAndSendInner(params: {
  chatId: number;
  urlOrQuery: string;
  mode: "video" | "voice" | "mp3";
  statusMsgId?: number | null;
  replyToMsgId?: number | null;
  reqId?: string | null;
  isSearch?: boolean;
  voiceOnlyButton?: boolean;
}): Promise<void> {
  const {
    chatId,
    urlOrQuery,
    mode = "video",
    statusMsgId = null,
    replyToMsgId = null,
    reqId = null,
    isSearch = false,
    voiceOnlyButton = false,
  } = params;

  const botUname = await bot.getBotUsername();
  const safeUname = escapeHtml(botUname);
  const badge = formatPremiumBadge("sections", "");
  const pInfo = isSearch ? { name: "يوتيوب", badge: "يوتيوب", key: "youtube" } : detectPlatformInfo(urlOrQuery);
  const normUrl = isSearch ? urlOrQuery : await normalizeCacheUrl(urlOrQuery);

  let extraMarkup: InlineKeyboardMarkup | undefined;
  if (reqId) {
    if (voiceOnlyButton || pInfo.key === "youtube") {
      extraMarkup = {
        inline_keyboard: [
          [makeBtn({ callback_data: `dl|voice|${reqId}`, style: "success", scope: "sections", ui_key: "btn_yt_to_voice" })],
        ],
      };
    } else {
      extraMarkup = {
        inline_keyboard: [
          [
            makeBtn({ callback_data: `dl|voice|${reqId}`, style: "success", scope: "sections", ui_key: "btn_yt_to_voice" }),
            makeBtn({ callback_data: `dl|mp3|${reqId}`, style: "primary", scope: "sections", ui_key: "btn_to_mp3" }),
          ],
        ],
      };
    }
  }

  let reqSavedMeta: Record<string, unknown> = {};
  if (reqId) {
    const reqObj = db.getUrlRequest(reqId);
    if (reqObj && reqObj.meta) reqSavedMeta = reqObj.meta;
  }

  // 1) فحص الكاش السريع أولاً (استجابة فورية 0ms)
  if (!isSearch && (mode === "video" || mode === "voice" || mode === "mp3")) {
    const cached = db.getCachedMedia(normUrl, mode);
    if (cached && cached.file_id) {
      try {
        const cTitle = cached.title || String(reqSavedMeta.title || "") || "منشور محمل";
        const cDesc = cached.description || String(reqSavedMeta.description || "") || cTitle;
        let rawCAuthor = cached.author || String(reqSavedMeta.author || "");
        if (pInfo.key === "instagram") rawCAuthor = cleanInstagramAuthor(rawCAuthor);
        const authorDisp =
          rawCAuthor && pInfo.key === "instagram" ? `@${rawCAuthor.replace(/^@+/, "")}` : rawCAuthor;

        const { fullCaption: cCap, cleanCaption: cleanCap, overflowDesc } = formatMediaCaptionWithDescription({
          badge,
          title: cTitle,
          description: cDesc,
          platformName: pInfo.name,
          authorDisplay: authorDisp,
          botUname,
        });

        let sentCachedMsg: TgMessage | null = null;
        if (cached.file_type === "video") {
          try {
            sentCachedMsg = await bot.sendVideo(chatId, cached.file_id, {
              caption: cCap,
              parse_mode: "HTML",
              supports_streaming: true,
              reply_to_message_id: replyToMsgId || undefined,
              reply_markup: extraMarkup,
            });
          } catch {
            sentCachedMsg = await bot.sendVideo(chatId, cached.file_id, {
              caption: cleanCap,
              parse_mode: "HTML",
              supports_streaming: true,
              reply_to_message_id: replyToMsgId || undefined,
              reply_markup: stripAdvancedButtonFields(extraMarkup),
            });
          }
        } else if (cached.file_type === "voice") {
          await sendUiOptionalSticker(chatId, "btn_yt_to_voice");
          sentCachedMsg = await bot.sendVoice(chatId, cached.file_id, {
            caption: cleanCap,
            parse_mode: "HTML",
            reply_to_message_id: replyToMsgId || undefined,
          });
        } else if (cached.file_type === "audio") {
          sentCachedMsg = await bot.sendAudio(chatId, cached.file_id, {
            caption: cleanCap,
            parse_mode: "HTML",
            reply_to_message_id: replyToMsgId || undefined,
          });
        }

        if (overflowDesc && sentCachedMsg) {
          await safeSendMessage(
            chatId,
            `<b>الوصف الكامل للمنشور:</b>\n<blockquote>${escapeHtml(overflowDesc.slice(0, 3500))}</blockquote>`,
            { parse_mode: "HTML", reply_to_message_id: sentCachedMsg.message_id }
          );
        }

        if (statusMsgId) {
          await bot.deleteMessage(chatId, statusMsgId);
        }
        return;
      } catch (e) {
        logger.debug(`Cache miss, re-downloading: ${String(e)}`);
      }
    }
  }

  // 2) التحميل الفعلي بأعلى جودة وأسرع مسار
  const workDir = fs.mkdtempSync(path.join(DOWNLOAD_DIR, "dl_task_"));
  try {
    if (statusMsgId) {
      const actionLabel =
        mode === "video"
          ? "جاري التحميل..."
          : mode === "voice"
          ? "جاري استخراج الصوت..."
          : "جاري استخراج MP3...";
      await safeEditMessage(chatId, statusMsgId, `${badge}<b>${actionLabel}</b>`, { parse_mode: "HTML" });
    }

    const res = await downloadMediaPipeline(urlOrQuery, mode, workDir, isSearch);

    if (!res.status) {
      const errText = `<b>تعذر التحميل:</b>\n<blockquote>${escapeHtml(res.error || "حدث خطأ أثناء التحميل.")}</blockquote>`;
      if (statusMsgId) {
        await safeEditMessage(chatId, statusMsgId, errText, { parse_mode: "HTML" });
      } else {
        await safeSendMessage(chatId, errText, {
          parse_mode: "HTML",
          reply_to_message_id: replyToMsgId || undefined,
        });
      }
      return;
    }

    const finalTitle = res.title || String(reqSavedMeta.title || "") || "منشور محمل";
    const finalDesc = res.description || String(reqSavedMeta.description || "") || finalTitle;
    let rawAuthor = String(res.author || reqSavedMeta.author || "").trim();
    if (pInfo.key === "instagram") rawAuthor = cleanInstagramAuthor(rawAuthor);
    const authorDisplay =
      rawAuthor && pInfo.key === "instagram" ? `@${rawAuthor.replace(/^@+/, "")}` : rawAuthor;

    const { fullCaption: caption, cleanCaption, overflowDesc } = formatMediaCaptionWithDescription({
      badge,
      title: finalTitle,
      description: finalDesc,
      platformName: pInfo.name,
      authorDisplay,
      botUname,
    });

    let lastSentMediaMsg: TgMessage | null = null;

    // أ) إرسال الفيديو مع تمرير width و height و duration الحقيقية
    if (res.video_path && fs.existsSync(res.video_path)) {
      void bot.sendChatAction(chatId, "upload_video");
      const vMeta = await getVideoStreamInfo(res.video_path);
      const sendOpts: {
        supports_streaming: boolean;
        parse_mode: string;
        reply_to_message_id?: number;
        width?: number;
        height?: number;
        duration?: number;
      } = {
        supports_streaming: true,
        parse_mode: "HTML",
        reply_to_message_id: replyToMsgId || undefined,
      };
      if (vMeta.width > 0 && vMeta.height > 0) {
        sendOpts.width = vMeta.width;
        sendOpts.height = vMeta.height;
      }
      if (vMeta.duration > 0) {
        sendOpts.duration = Math.floor(vMeta.duration);
      }

      let sentVidMsg: TgMessage | null = null;
      try {
        sentVidMsg = await bot.sendVideo(chatId, res.video_path, {
          ...sendOpts,
          caption,
          reply_markup: extraMarkup,
        });
      } catch {
        sentVidMsg = await bot.sendVideo(chatId, res.video_path, {
          ...sendOpts,
          caption: cleanCaption,
          reply_markup: stripAdvancedButtonFields(extraMarkup),
        });
      }

      if (sentVidMsg) lastSentMediaMsg = sentVidMsg;
      if (sentVidMsg?.video?.file_id && !isSearch) {
        db.saveCachedMedia(normUrl, "video", "video", sentVidMsg.video.file_id, finalTitle, finalDesc, rawAuthor);
      }
      cleanupFiles(res.video_path);
    }

    for (const extraV of res.extra_videos.slice(0, 4)) {
      if (fs.existsSync(extraV)) {
        try {
          const evMeta = await getVideoStreamInfo(extraV);
          await bot.sendVideo(chatId, extraV, {
            caption: `@${safeUname}`,
            supports_streaming: true,
            ...(evMeta.width > 0 && evMeta.height > 0 ? { width: evMeta.width, height: evMeta.height } : {}),
            ...(evMeta.duration > 0 ? { duration: Math.floor(evMeta.duration) } : {}),
          });
        } catch {
          // ignore
        } finally {
          cleanupFiles(extraV);
        }
      }
    }

    // ب) إرسال الصور (لغير يوتيوب)
    const validImages =
      pInfo.key !== "youtube" ? res.images.slice(0, 10).filter((p) => fs.existsSync(p)) : [];
    if (validImages.length > 0) {
      void bot.sendChatAction(chatId, "upload_photo");
      if (validImages.length > 1) {
        try {
          const sentMg = await bot.sendMediaGroupPhotos(
            chatId,
            validImages,
            cleanCaption,
            replyToMsgId || undefined
          );
          if (sentMg.length > 0) lastSentMediaMsg = sentMg[0];
        } catch {
          for (let idx = 0; idx < Math.min(validImages.length, 6); idx++) {
            const sentP = await bot.sendPhoto(chatId, validImages[idx], {
              caption: idx === 0 ? cleanCaption : `(${idx + 1}) — @${safeUname}`,
              parse_mode: "HTML",
              reply_to_message_id: replyToMsgId || undefined,
            });
            if (idx === 0 && sentP) lastSentMediaMsg = sentP;
          }
        } finally {
          cleanupFiles(...validImages);
        }
      } else {
        try {
          const sentP = await bot.sendPhoto(chatId, validImages[0], {
            caption: cleanCaption,
            parse_mode: "HTML",
            reply_to_message_id: replyToMsgId || undefined,
            reply_markup: stripAdvancedButtonFields(extraMarkup),
          });
          if (sentP) lastSentMediaMsg = sentP;
        } finally {
          cleanupFiles(validImages[0]);
        }
      }
    }

    // ج) إرسال الرسالة الصوتية
    if (res.voice_path && fs.existsSync(res.voice_path)) {
      await sendUiOptionalSticker(chatId, "btn_yt_to_voice");
      void bot.sendChatAction(chatId, "record_voice");
      const voiceCfg = db.getUiConfig("btn_yt_to_voice");
      const customVNote = (voiceCfg.inner_content || "الصوت المستخرج من الفيديو").trim();
      const voiceCaption = validImages.length
        ? `<b>${escapeHtml(customVNote)}</b> — @${safeUname}`
        : cleanCaption;
      try {
        const sentVoice = await bot.sendVoice(chatId, res.voice_path, {
          caption: voiceCaption,
          parse_mode: "HTML",
          reply_to_message_id: replyToMsgId || undefined,
        });
        if (sentVoice && !lastSentMediaMsg) lastSentMediaMsg = sentVoice;
        if (sentVoice?.voice?.file_id && !isSearch && mode === "voice") {
          db.saveCachedMedia(normUrl, "voice", "voice", sentVoice.voice.file_id, finalTitle, finalDesc, rawAuthor);
        }
      } finally {
        cleanupFiles(res.voice_path);
      }
    }

    // د) إرسال ملف MP3
    if (res.audio_path && fs.existsSync(res.audio_path)) {
      void bot.sendChatAction(chatId, "upload_audio");
      try {
        const sentAud = await bot.sendAudio(chatId, res.audio_path, {
          caption: cleanCaption,
          title: String(finalTitle).slice(0, 60),
          performer: String(rawAuthor || botUname).slice(0, 40),
          parse_mode: "HTML",
          reply_to_message_id: replyToMsgId || undefined,
        });
        if (sentAud && !lastSentMediaMsg) lastSentMediaMsg = sentAud;
        if (sentAud?.audio?.file_id && !isSearch && mode === "mp3") {
          db.saveCachedMedia(normUrl, "mp3", "audio", sentAud.audio.file_id, finalTitle, finalDesc, rawAuthor);
        }
      } finally {
        cleanupFiles(res.audio_path);
      }
    }

    if (overflowDesc && lastSentMediaMsg) {
      await safeSendMessage(
        chatId,
        `<b>الوصف الكامل للمنشور:</b>\n<blockquote>${escapeHtml(overflowDesc.slice(0, 3500))}</blockquote>`,
        { parse_mode: "HTML", reply_to_message_id: lastSentMediaMsg.message_id }
      );
    }

    if (statusMsgId) {
      await bot.deleteMessage(chatId, statusMsgId);
    }
  } catch (e) {
    logger.error(`خطأ أثناء إرسال الوسائط: ${String(e)}`);
    if (statusMsgId) {
      await safeEditMessage(
        chatId,
        statusMsgId,
        `<b>حدث خطأ أثناء الرفع:</b>\n<code>${escapeHtml(String(e).slice(0, 180))}</code>`,
        { parse_mode: "HTML" }
      );
    }
  } finally {
    cleanupFiles(workDir);
    purgeStaleTempFiles();
  }
}

export async function sendYoutubeTop5SearchCard(
  chatId: number,
  user: TgUser,
  queryText: string,
  replyToMsgId?: number
): Promise<void> {
  const badge = formatPremiumBadge("sections", "", "btn_smart_search");
  const waitMsg = await safeSendMessage(
    chatId,
    `${badge}<b>جاري البحث في يوتيوب عن:</b> <code>${escapeHtml(queryText.slice(0, 60))}</code>...`,
    { parse_mode: "HTML", reply_to_message_id: replyToMsgId }
  );

  (async () => {
    const results = await searchYouTubeTop5(queryText);
    if (!results.length) {
      const errTxt =
        `<b>لم يتم العثور على نتائج في يوتيوب لـ:</b> <code>${escapeHtml(queryText.slice(0, 60))}</code>\n` +
        "<blockquote>حاول كتابة اسم الفيديو بشكل أوضح (مثال: <code>ب سورة الملك</code>).</blockquote>";
      if (waitMsg) {
        await safeEditMessage(chatId, waitMsg.message_id, errTxt, { parse_mode: "HTML" });
      } else {
        await safeSendMessage(chatId, errTxt, { parse_mode: "HTML", reply_to_message_id: replyToMsgId });
      }
      return;
    }

    const reqId = db.saveUrlRequest(user.id, chatId, queryText, 1, {
      yt_results: results,
      query: queryText,
    });
    const lines = [
      `${badge}<b>نتائج بحث يوتيوب (أفضل ${results.length} فيديوهات):</b>`,
      `البحث: <code>${escapeHtml(queryText.slice(0, 70))}</code>`,
      "<blockquote>",
    ];
    const rows: SmartInlineButton[][] = [];

    results.forEach((item, i) => {
      const idx = i + 1;
      lines.push(
        `<b>${idx}.</b> ${escapeHtml(item.title.slice(0, 68))}\n   <code>${escapeHtml(item.channel.slice(0, 25))}</code> | <code>${escapeHtml(item.duration)}</code>`
      );
      const btnTitle = item.title.slice(0, 36) + (item.title.length > 36 ? "..." : "");
      rows.push([
        makeBtn({
          text: `${idx} - ${btnTitle} (${item.duration})`,
          callback_data: `ytsel|${reqId}|${i}`,
          style: idx > 1 ? "primary" : "success",
          scope: "sections",
        }),
      ]);
    });

    lines.push("</blockquote>");
    lines.push("<b>اضغط على الفيديو المطلوب للتحميل:</b>");
    rows.push([
      makeBtn({ callback_data: `dl|cancel|${reqId}`, style: "danger", scope: "sections", ui_key: "btn_cancel" }),
    ]);

    const finalText = lines.join("\n");
    const markup: InlineKeyboardMarkup = { inline_keyboard: rows };
    if (waitMsg) {
      await safeEditMessage(chatId, waitMsg.message_id, finalText, { reply_markup: markup, parse_mode: "HTML" });
    } else {
      await safeSendMessage(chatId, finalText, {
        reply_markup: markup,
        parse_mode: "HTML",
        reply_to_message_id: replyToMsgId,
      });
    }
  })().catch(() => {});
}

export async function startDirectLinkDownload(
  chatId: number,
  user: TgUser,
  targetUrl: string,
  replyToMsgId?: number
): Promise<void> {
  const badge = formatPremiumBadge("sections", "");
  const pInfo = detectPlatformInfo(targetUrl);
  const reqId = db.saveUrlRequest(user.id, chatId, targetUrl, 0);

  const waitMsg = await safeSendMessage(chatId, `${badge}<b>جاري التحميل...</b>`, {
    parse_mode: "HTML",
    reply_to_message_id: replyToMsgId,
  });

  executeDownloadAndSend({
    chatId,
    urlOrQuery: targetUrl,
    mode: "video",
    statusMsgId: waitMsg?.message_id || null,
    replyToMsgId: replyToMsgId || null,
    reqId,
    isSearch: false,
    voiceOnlyButton: pInfo.key === "youtube",
  });
}

export async function handleIncomingMediaMessage(message: TgMessage): Promise<void> {
  const user = message.from;
  if (!user) return;
  db.registerUser(user);

  const chatType = message.chat.type;
  const botUname = await bot.getBotUsername();
  const textContent = (message.text || message.caption || "").trim();
  if (!textContent) return;

  // أ) في المجموعات
  if (chatType === "group" || chatType === "supergroup") {
    const [parsedQ, hasBPrefix] = extractYouTubeSearchQuery(textContent);
    const isMentioned = textContent.toLowerCase().includes(`@${botUname.toLowerCase()}`);

    if (hasBPrefix && parsedQ && !extractFirstUrl(parsedQ)) {
      if (db.isUserBanned(user.id)) return;
      if (!(await sendForceSubPrompt(message.chat.id, user, message.message_id))) return;
      await sendYoutubeTop5SearchCard(message.chat.id, user, parsedQ, message.message_id);
      return;
    }

    if (!isMentioned) return;

    let targetUrl = extractFirstUrl(textContent);
    if (!targetUrl && message.reply_to_message) {
      const replyText = message.reply_to_message.text || message.reply_to_message.caption || "";
      targetUrl = extractFirstUrl(replyText);
    }

    if (!targetUrl) {
      const escapedMention = botUname.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const rawClean = textContent.replace(new RegExp(`@${escapedMention}`, "gi"), "").trim();
      const [cleanQuery] = extractYouTubeSearchQuery(rawClean);
      if (cleanQuery && cleanQuery.length >= 2) {
        if (db.isUserBanned(user.id)) return;
        if (!(await sendForceSubPrompt(message.chat.id, user, message.message_id))) return;
        await sendYoutubeTop5SearchCard(message.chat.id, user, cleanQuery, message.message_id);
        return;
      }

      await safeSendMessage(
        message.chat.id,
        `ضع الرابط مع المنشن أو ابحث في يوتيوب بكتابة (<code>ب اسم الفيديو</code>):\n<code>@${escapeHtml(botUname)} https://...</code>`,
        { reply_to_message_id: message.message_id }
      );
      return;
    }

    if (db.isUserBanned(user.id)) return;
    if (!(await sendForceSubPrompt(message.chat.id, user, message.message_id))) return;

    await startDirectLinkDownload(message.chat.id, user, targetUrl, message.message_id);
    return;
  }

  // ب) في المحادثة الخاصة
  if (chatType === "private") {
    if (db.isUserBanned(user.id)) {
      await safeSendMessage(message.chat.id, "عذراً، أنت محظور من استخدام البوت.", {
        reply_to_message_id: message.message_id,
      });
      return;
    }

    if (db.getSetting("bot_enabled", "1") !== "1" && !db.isAdmin(user.id)) {
      await safeSendMessage(message.chat.id, "البوت في وضع الصيانة حالياً.", {
        reply_to_message_id: message.message_id,
      });
      return;
    }

    if (!(await sendForceSubPrompt(message.chat.id, user, message.message_id))) return;

    const allUrls = extractAllUrls(textContent);
    if (allUrls.length > 0) {
      for (const u of allUrls.slice(0, 3)) {
        await startDirectLinkDownload(message.chat.id, user, u, message.message_id);
      }
      return;
    }

    if (message.text && !textContent.startsWith("/")) {
      const [parsedQ, hasBPrefix] = extractYouTubeSearchQuery(textContent);
      if (parsedQ && (hasBPrefix || parsedQ.length >= 2)) {
        await sendYoutubeTop5SearchCard(message.chat.id, user, parsedQ, message.message_id);
      }
    }
  }
}

export async function handleCallbackQuery(call: TgCallbackQuery): Promise<void> {
  const user = call.from;
  const data = call.data || "";
  db.registerUser(user);
  const badge = formatPremiumBadge("sections", "");

  if (data.startsWith("adm_") || data === "admin_home") {
    await handleAdminCallback(call);
    return;
  }

  const msg = call.message;
  if (!msg) return;
  const chatId = msg.chat.id;
  const msgId = msg.message_id;

  if (data === "verify_subscription") {
    const missing = await checkUserSubscription(user.id);
    if (missing.length > 0) {
      await bot.answerCallbackQuery(call.id, "اشترك في جميع القنوات أولاً ثم اضغط تحقق.", true);
      return;
    }
    await bot.answerCallbackQuery(call.id, "تم التحقق بنجاح");
    await bot.deleteMessage(chatId, msgId);
    await sendWelcomeScreen(chatId, user);
    return;
  }

  if (data === "user_help_guide") {
    await bot.answerCallbackQuery(call.id);
    await sendUiOptionalSticker(chatId, "btn_help_guide");
    const cfg = db.getUiConfig("btn_help_guide");
    const bBadge = formatPremiumBadge("sections", "", "btn_help_guide");
    const botUname = escapeHtml(await bot.getBotUsername());
    const rawContent = cfg.inner_content || DEFAULT_HELP_GUIDE_TEXT;
    const guideText =
      bBadge + rawContent.replaceAll("{bot}", botUname).replaceAll("@البوت", `@${botUname}`);
    await safeSendMessage(chatId, guideText, { parse_mode: "HTML" });
    return;
  }

  if (data === "user_smart_search_hint") {
    await bot.answerCallbackQuery(call.id);
    await sendUiOptionalSticker(chatId, "btn_smart_search");
    const cfg = db.getUiConfig("btn_smart_search");
    const bBadge = formatPremiumBadge("sections", "", "btn_smart_search");
    const hintText = bBadge + (cfg.inner_content || DEFAULT_SEARCH_HINT_TEXT);
    await safeSendMessage(chatId, hintText, { parse_mode: "HTML" });
    return;
  }

  if (data.startsWith("ytsel|")) {
    const parts = data.split("|");
    if (parts.length < 3) return;
    const searchReqId = parts[1];
    const selIdxStr = parts[2];

    if (!(await sendForceSubPrompt(chatId, user))) {
      await bot.answerCallbackQuery(call.id, "اشترك في القنوات أولاً.", true);
      return;
    }

    const reqData = db.getUrlRequest(searchReqId);
    if (!reqData) {
      await bot.answerCallbackQuery(call.id, "انتهت صلاحية البحث، ابحث مجدداً.", true);
      return;
    }

    const ytResults = (reqData.meta.yt_results as YouTubeSearchItem[]) || [];
    const selIdx = /^\d+$/.test(selIdxStr) ? Number.parseInt(selIdxStr, 10) : 0;
    if (selIdx < 0 || selIdx >= ytResults.length) {
      await bot.answerCallbackQuery(call.id, "اختيار غير صالح.", true);
      return;
    }

    const chosenVideo = ytResults[selIdx];
    const chosenUrl = chosenVideo.url;
    const chosenMeta = {
      platform: "يوتيوب",
      key: "youtube",
      title: chosenVideo.title || "فيديو يوتيوب",
      description: "",
      author: chosenVideo.channel || "YouTube",
    };
    const newReqId = db.saveUrlRequest(user.id, chatId, chosenUrl, 0, chosenMeta);
    await bot.answerCallbackQuery(call.id, "جاري التحميل...");
    executeDownloadAndSend({
      chatId,
      urlOrQuery: chosenUrl,
      mode: "video",
      statusMsgId: msgId,
      replyToMsgId: null,
      reqId: newReqId,
      isSearch: false,
      voiceOnlyButton: true,
    });
    return;
  }

  if (data.startsWith("dl|")) {
    const parts = data.split("|");
    if (parts.length < 3) return;
    const modeRaw = parts[1];
    const reqId = parts[parts.length - 1];

    if (modeRaw === "cancel") {
      await bot.answerCallbackQuery(call.id, "تم الإلغاء.");
      await bot.deleteMessage(chatId, msgId);
      return;
    }

    if (!(await sendForceSubPrompt(chatId, user))) {
      await bot.answerCallbackQuery(call.id, "اشترك في القنوات أولاً.", true);
      return;
    }

    const reqData = db.getUrlRequest(reqId);
    if (!reqData) {
      await bot.answerCallbackQuery(call.id, "انتهت صلاحية الطلب، أرسل الرابط مجدداً.", true);
      return;
    }

    const mode: "video" | "voice" | "mp3" =
      modeRaw === "voice" || modeRaw === "mp3" ? modeRaw : "video";

    await bot.answerCallbackQuery(call.id, "جاري التحميل...");
    let statusMsgId: number | null = msg.text ? msgId : null;
    if (!statusMsgId) {
      const waitLabel =
        mode === "mp3" ? "جاري استخراج MP3..." : "جاري تحويل الفيديو إلى رسالة صوتية...";
      const waitM = await safeSendMessage(chatId, `${badge}<b>${waitLabel}</b>`, {
        reply_to_message_id: msgId,
      });
      statusMsgId = waitM?.message_id || null;
    }

    const isSearchFlag = Boolean(reqData.is_search);
    const isYtLink =
      reqData.url.toLowerCase().includes("youtube.com") ||
      reqData.url.toLowerCase().includes("youtu.be");

    executeDownloadAndSend({
      chatId,
      urlOrQuery: reqData.url,
      mode,
      statusMsgId,
      replyToMsgId: msg.text ? null : msgId,
      reqId,
      isSearch: isSearchFlag,
      voiceOnlyButton: isYtLink,
    });
  }
}

export async function handleInlineQuery(inlineQuery: TgInlineQuery): Promise<void> {
  const queryText = (inlineQuery.query || "").trim();
  const botUname = await bot.getBotUsername();
  const url = extractFirstUrl(queryText);
  const results: Array<Record<string, unknown>> = [];

  if (!url && !queryText) {
    results.push({
      type: "article",
      id: "help_inline",
      title: "ضع الرابط أو ابحث في يوتيوب (مثال: ب سورة الكهف)",
      description: `مثال: @${botUname} https://www.instagram.com/reel/...`,
      input_message_content: {
        message_text: `للتحميل أو البحث في يوتيوب، أرسل الرابط أو (ب + اسم الفيديو) إلى @${botUname}`,
      },
    });
  } else if (url) {
    const pInfo = detectPlatformInfo(url);
    const reqId = db.saveUrlRequest(inlineQuery.from.id, inlineQuery.from.id, url, 0);
    const inlineKb: InlineKeyboardMarkup = {
      inline_keyboard: [
        [
          makeBtn({ text: "تحميل الفيديو", callback_data: `dl|video|${reqId}`, style: "success", scope: "sections" }),
          makeBtn({ callback_data: `dl|voice|${reqId}`, style: "primary", scope: "sections", ui_key: "btn_yt_to_voice" }),
        ],
      ],
    };
    results.push({
      type: "article",
      id: `dl_${reqId}`,
      title: `${pInfo.badge} — اضغط للتحميل`,
      description: `المنشور: ${url.slice(0, 60)}`,
      input_message_content: {
        message_text: `<b>${escapeHtml(pInfo.badge)}</b>\n<blockquote><code>${escapeHtml(url.slice(0, 90))}</code></blockquote>`,
        parse_mode: "HTML",
      },
      reply_markup: stripAdvancedButtonFields(inlineKb),
    });
  } else {
    const [cleanQ] = extractYouTubeSearchQuery(queryText);
    const ytItems = await searchYouTubeTop5(cleanQ || queryText);
    ytItems.slice(0, 5).forEach((item, i) => {
      const idx = i + 1;
      const reqId = db.saveUrlRequest(
        inlineQuery.from.id,
        inlineQuery.from.id,
        item.url,
        0,
        item as unknown as Record<string, unknown>
      );
      const ytInlineKb: InlineKeyboardMarkup = {
        inline_keyboard: [
          [
            makeBtn({ text: "تحميل الفيديو", callback_data: `dl|video|${reqId}`, style: "success", scope: "sections" }),
            makeBtn({ callback_data: `dl|voice|${reqId}`, style: "primary", scope: "sections", ui_key: "btn_yt_to_voice" }),
          ],
        ],
      };
      results.push({
        type: "article",
        id: `yt_${reqId}_${idx}`,
        title: `${idx} - ${item.title}`,
        description: `${item.channel} | ${item.duration}`,
        input_message_content: {
          message_text:
            `<b>يوتيوب</b>\n` +
            `<blockquote><b>العنوان:</b> ${escapeHtml(item.title)}\n` +
            `<code>${escapeHtml(item.channel)}</code> | <code>${escapeHtml(item.duration)}</code></blockquote>`,
          parse_mode: "HTML",
        },
        reply_markup: stripAdvancedButtonFields(ytInlineKb),
      });
    });
  }

  try {
    await bot.answerInlineQuery(inlineQuery.id, results, 5);
  } catch (e) {
    logger.debug(`Inline query note: ${String(e)}`);
  }
}
