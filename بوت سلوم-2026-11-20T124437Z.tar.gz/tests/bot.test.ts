import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { BotDatabase } from "../src/database.js";
import {
  extractTikTokIdFromUrl,
  isTikTokUrl,
  normalizeTikWmUrl,
} from "../src/downloaders/tiktok.js";
import { buildYtDlpArgs } from "../src/downloaders/ytdlp.js";
import { isValidMediaBinaryHeader } from "../src/mediaUtils.js";
import { AsyncSemaphore, raceFirstSuccess, SimpleCookieJar } from "../src/network.js";
import { convertTextAndEntitiesToHtml, formatMediaCaptionWithDescription } from "../src/ui.js";

test("TikTok URL detection, ID extraction, and TikWM URL normalization", () => {
  assert.equal(isTikTokUrl("https://www.tiktok.com/@saloum/video/7412345678901234567"), true);
  assert.equal(isTikTokUrl("https://vt.tiktok.com/ZSY123456/"), true);
  assert.equal(isTikTokUrl("https://vm.tiktok.com/ZM6abcdef/"), true);
  assert.equal(isTikTokUrl("https://m.tiktok.com/v/7412345678901234567.html"), true);
  assert.equal(isTikTokUrl("https://www.instagram.com/reel/ABC123/"), false);

  assert.equal(
    extractTikTokIdFromUrl("https://www.tiktok.com/@user/video/7412345678901234567?is_from_webapp=1"),
    "7412345678901234567"
  );
  assert.equal(
    extractTikTokIdFromUrl("https://www.tiktok.com/@user/photo/7499999999999999999"),
    "7499999999999999999"
  );
  assert.equal(extractTikTokIdFromUrl("https://vt.tiktok.com/ZSY123456/"), null);

  assert.equal(normalizeTikWmUrl("/video/media/hdplay/123.mp4"), "https://www.tikwm.com/video/media/hdplay/123.mp4");
  assert.equal(normalizeTikWmUrl("//cdn.tikwm.com/play.mp4"), "https://cdn.tikwm.com/play.mp4");
  assert.equal(normalizeTikWmUrl("https://v16.tiktokcdn.com/abc.mp4"), "https://v16.tiktokcdn.com/abc.mp4");
});

test("buildYtDlpArgs enables parallel fragments, H.264 priority, and removes broken TikTok api_hostname", () => {
  const ttArgs = buildYtDlpArgs({
    targetUrl: "https://www.tiktok.com/@u/video/7412345678901234567",
    outTemplate: "/tmp/media_1.%(ext)s",
    mode: "video",
    platform: "tiktok",
    hasFfmpeg: true,
    hasAria2: true,
    hasCookies: true,
    cookiesPath: "/tmp/cookies.txt",
  });

  assert.ok(ttArgs.includes("--concurrent-fragments"));
  assert.ok(ttArgs.includes("12"));
  assert.ok(ttArgs.includes("--http-chunk-size"));
  assert.ok(ttArgs.includes("10485760"));
  assert.ok(ttArgs.includes("--cookies"));
  assert.ok(ttArgs.includes("/tmp/cookies.txt"));
  assert.ok(ttArgs.includes("aria2c"));
  assert.ok(
    ttArgs.some((a) => a.includes("vcodec:h264")),
    "Should prioritize H.264 codec to avoid slow HEVC FFmpeg transcoding"
  );
  assert.equal(
    ttArgs.some((a) => a.includes("api16-normal-c-useast1a.tiktokv.com")),
    false,
    "Must NOT include the dead TikTok api_hostname from the broken Python bot"
  );
});

test("raceFirstSuccess returns fastest valid route and aborts slower routes immediately", async () => {
  let slowAborted = false;
  const startedAt = Date.now();

  const winner = await raceFirstSuccess<string>(
    [
      async (signal) => {
        signal.addEventListener("abort", () => {
          slowAborted = true;
        });
        await new Promise((r) => setTimeout(r, 800));
        return "slow-route";
      },
      async () => {
        await new Promise((r) => setTimeout(r, 10));
        return null; // failed fast route
      },
      async () => {
        await new Promise((r) => setTimeout(r, 25));
        return "fast-route";
      },
    ],
    2000
  );

  const elapsed = Date.now() - startedAt;
  assert.equal(winner, "fast-route");
  assert.equal(slowAborted, true);
  assert.ok(elapsed < 400, `Expected fast completion (<400ms), got ${elapsed}ms`);
});

test("SimpleCookieJar and AsyncSemaphore enforce cookies and concurrency limits", async () => {
  const jar = new SimpleCookieJar();
  jar.set("ttwid", "abc123");
  jar.set("tt_chain_token", "xyz789");
  assert.equal(jar.toHeader(), "ttwid=abc123; tt_chain_token=xyz789");

  const sem = new AsyncSemaphore(2);
  let active = 0;
  let peak = 0;
  await Promise.all(
    Array.from({ length: 6 }, () =>
      sem.run(async () => {
        active += 1;
        peak = Math.max(peak, active);
        await new Promise((r) => setTimeout(r, 15));
        active -= 1;
      })
    )
  );
  assert.equal(peak, 2);
});

test("Binary header validator rejects HTML pages and accepts real MP4/JPEG/PNG headers", () => {
  const htmlBuf = Buffer.from("<!DOCTYPE html><html><body>Access Denied</body></html>");
  assert.equal(isValidMediaBinaryHeader(htmlBuf, "video"), false);
  assert.equal(isValidMediaBinaryHeader(htmlBuf, "image"), false);

  const mp4Buf = Buffer.from([0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70, 0x6d, 0x70, 0x34, 0x32]);
  assert.equal(isValidMediaBinaryHeader(mp4Buf, "video"), true);

  const jpgBuf = Buffer.from([
    0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
  ]);
  assert.equal(isValidMediaBinaryHeader(jpgBuf, "image"), true);
});

test("Telegram HTML entity conversion and caption overflow splitting work identically to original bot", () => {
  const htmlOut = convertTextAndEntitiesToHtml("هلا @البوت", [
    { type: "bold", offset: 0, length: 3 },
  ]);
  assert.equal(htmlOut, "<b>هلا</b> @البوت");

  const longDesc = "وصف طويل جداً ".repeat(80);
  const formatted = formatMediaCaptionWithDescription({
    badge: "",
    title: "فيديو تجريبي",
    description: longDesc,
    platformName: "تيك توك",
    authorDisplay: "@saloum",
    botUname: "SaloumBot",
  });
  assert.ok(formatted.fullCaption.includes("تيك توك"));
  assert.ok(formatted.fullCaption.includes("@SaloumBot"));
  assert.ok(formatted.overflowDesc.length > 620);
});

test("BotDatabase initializes all 7 original tables, caches settings, and persists CRUD", async () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "saloum_db_test_"));
  const dbPath = path.join(tmpDir, "test_downloader_bot_pro.db");
  const testDb = new BotDatabase(dbPath);

  try {
    await testDb.init();

    // Default settings & 21 UI keys initialized
    assert.equal(testDb.getSetting("bot_enabled", "0"), "1");
    assert.equal(testDb.getUiConfig("btn_help_guide").btn_label, "المنصات والمميزات");

    // Register user & ban/unban
    testDb.registerUser({ id: 999001, first_name: "سلوم", username: "saloum_test" });
    assert.equal(testDb.isUserBanned(999001), false);
    testDb.setUserBanned(999001, true);
    assert.equal(testDb.isUserBanned(999001), true);
    testDb.setUserBanned(999001, false);
    assert.equal(testDb.isUserBanned(999001), false);

    // Media cache save & retrieve
    testDb.saveCachedMedia(
      "https://www.tiktok.com/@u/video/123",
      "video",
      "video",
      "FILE_ID_123",
      "عنوان",
      "وصف",
      "author"
    );
    const cached = testDb.getCachedMedia("https://www.tiktok.com/@u/video/123", "video");
    assert.equal(cached?.file_id, "FILE_ID_123");

    // UI config update & reset
    testDb.updateUiConfig("btn_help_guide", { btn_label: "مساعدة سريعة" });
    assert.equal(testDb.getUiConfig("btn_help_guide").btn_label, "مساعدة سريعة");
    testDb.resetAllUiConfigs();
    assert.equal(testDb.getUiConfig("btn_help_guide").btn_label, "المنصات والمميزات");

    // Force channel CRUD
    testDb.upsertForceChannel("-100123456", "قناة تجريبية", "https://t.me/test");
    assert.equal(testDb.getForceChannels().length, 1);
    testDb.deleteForceChannel("-100123456");
    assert.equal(testDb.getForceChannels().length, 0);

    const stats = testDb.getDashboardStats();
    assert.equal(stats.total_users, 1);
    assert.equal(stats.cached_items, 1);
  } finally {
    testDb.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});
